--   Updated : April 11th 2026
--   Made by: @OverZuka™

--[[

WIP THIS IS IN ALPHA


                                                        ＺＵＫｖ２　ＣＯＲＥ -   

                      Ａ　Ｌｕａ５．１＋　ｂｙｔｅｃｏｄｅ　ｄｉｓａｓｓｅｍｂｌｅｒ

         For　Ｌｕａｕ，　Ｌｕａ５．１，　Ｌｕａ５．２，　Ｌｕａ５．３，　Ｌｕａ５．４




  Usage (CLI):
    lua zukv2.lua <bytecode_file> [options]

  Options:
    --mode disasm       disassembly (default)
    --clean             enable clean / prettified output
    --no-globals        suppress used-globals header
    --timeout N         set decompiler timeout in seconds (default 10)
    --float-precision N float formatting precision (default 7)
    --show-debug        show proto debug metadata
    --show-lines        show instruction line numbers
    --show-opidx        show instruction indices
    --show-opnames      show raw opcode names
    --show-trivial      show trivial (bookkeeping) ops
    --no-typeinfo       disable type annotation output

  As a module:
    local zuk = require("zukv2")
    local result = zuk.decompile(bytecodeString, options)
    local pretty  = zuk.prettyPrint(result)
    local clean   = zuk.cleanOutput(result)
]]

local formatter = {}
local Dom_Engine = {}
local BR = {}
local Reader = {}

local _LUAU = type(bit32) == "table" and bit32.band ~= nil
local _LUA51 = (not _LUAU) and (_VERSION == "Lua 5.1")
local _LUAJIT = (not _LUAU) and (type(jit) == "table")
local bit32
do
	if type(_G.bit32) == "table" then
		bit32 = _G.bit32
	elseif type(_G.bit) == "table" then
		local b = _G.bit
		bit32 = {
			band = b.band,
			bor = b.bor,
			bxor = b.bxor,
			bnot = function(a)
				return b.bnot(a)
			end,
			lshift = function(a, n)
				return b.lshift(a, n % 32)
			end,
			rshift = function(a, n)
				return b.rshift(a, n % 32)
			end,
			arshift = function(a, n)
				return b.arshift(a, n % 32)
			end,
			btest = function(a, c)
				return b.band(a, c) ~= 0
			end,
			extract = function(v, f, w)
				w = w or 1
				return b.rshift(b.band(v, b.lshift(b.lshift(1, w) - 1, f)), f)
			end,
			replace = function(v, r, f, w)
				w = w or 1
				local mask = b.lshift(b.lshift(1, w) - 1, f)
				return b.bor(b.band(v, b.bnot(mask)), b.band(b.lshift(r, f), mask))
			end,
			lrotate = function(a, n)
				a = b.band(a, 0xFFFFFFFF)
				n = n % 32
				return b.band(b.bor(b.lshift(a, n), b.rshift(a, 32 - n)), 0xFFFFFFFF)
			end,
			rrotate = function(a, n)
				a = b.band(a, 0xFFFFFFFF)
				n = n % 32
				return b.band(b.bor(b.rshift(a, n), b.lshift(a, 32 - n)), 0xFFFFFFFF)
			end,
			countlz = function(a)
				a = b.band(a, 0xFFFFFFFF)
				if a == 0 then
					return 32
				end
				local n = 0
				while b.rshift(a, 31) == 0 do
					a = b.lshift(a, 1)
					n = n + 1
				end
				return n
			end,
			countrz = function(a)
				a = b.band(a, 0xFFFFFFFF)
				if a == 0 then
					return 32
				end
				local n = 0
				while b.band(a, 1) == 0 do
					a = b.rshift(a, 1)
					n = n + 1
				end
				return n
			end,
			byteswap = function(a)
				a = b.band(a, 0xFFFFFFFF)
				return b.bor(
					b.lshift(b.band(a, 0xFF), 24),
					b.lshift(b.band(b.rshift(a, 8), 0xFF), 16),
					b.lshift(b.band(b.rshift(a, 16), 0xFF), 8),
					b.band(b.rshift(a, 24), 0xFF)
				)
			end,
		}
	else
		local function uint32(n)
			n = n % 0x100000000
			if n < 0 then
				n = n + 0x100000000
			end
			return n
		end
		local function lsh(a, n)
			if n >= 32 or n <= -32 then
				return 0
			end
			if n < 0 then
				return math.floor(uint32(a) / 2 ^ -n)
			end
			return uint32(a * 2 ^ n) % 0x100000000
		end
		local function rsh(a, n)
			return lsh(a, -n)
		end
		local function band(a, b)
			local r, p = 0, 1
			a, b = uint32(a), uint32(b)
			for _ = 1, 32 do
				local ab, bb = a % 2, b % 2
				if ab == 1 and bb == 1 then
					r = r + p
				end
				a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
			end
			return r
		end
		local function bor(a, b)
			local r, p = 0, 1
			a, b = uint32(a), uint32(b)
			for _ = 1, 32 do
				if a % 2 == 1 or b % 2 == 1 then
					r = r + p
				end
				a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
			end
			return r
		end
		local function bxor(a, b)
			local r, p = 0, 1
			a, b = uint32(a), uint32(b)
			for _ = 1, 32 do
				if a % 2 ~= b % 2 then
					r = r + p
				end
				a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
			end
			return r
		end
		local function bnot(a)
			return uint32(0xFFFFFFFF - uint32(a) + 1) - 1
		end
		bit32 = {
			band = band,
			bor = bor,
			bxor = bxor,
			bnot = bnot,
			lshift = function(a, n)
				return lsh(uint32(a), n)
			end,
			rshift = function(a, n)
				return rsh(uint32(a), n)
			end,
			arshift = function(a, n)
				a = uint32(a)
				if a >= 0x80000000 then
					a = a - 0x100000000
				end
				local r = math.floor(a / 2 ^ n)
				return uint32(r)
			end,
			btest = function(a, b)
				return band(a, b) ~= 0
			end,
			extract = function(v, f, w)
				w = w or 1
				return band(rsh(uint32(v), f), lsh(1, w) - 1)
			end,
			replace = function(v, r, f, w)
				w = w or 1
				local mask = lsh(lsh(1, w) - 1, f)
				return bor(band(uint32(v), bnot(mask)), band(lsh(r, f), mask))
			end,
			lrotate = function(a, n)
				a = uint32(a)
				n = n % 32
				return band(bor(lsh(a, n), rsh(a, 32 - n)), 0xFFFFFFFF)
			end,
			rrotate = function(a, n)
				a = uint32(a)
				n = n % 32
				return band(bor(rsh(a, n), lsh(a, 32 - n)), 0xFFFFFFFF)
			end,
			countlz = function(a)
				a = uint32(a)
				if a == 0 then
					return 32
				end
				local n = 0
				while a < 0x80000000 do
					a = lsh(a, 1)
					n = n + 1
				end
				return n
			end,
			countrz = function(a)
				a = uint32(a)
				if a == 0 then
					return 32
				end
				local n = 0
				while band(a, 1) == 0 do
					a = rsh(a, 1)
					n = n + 1
				end
				return n
			end,
			byteswap = function(a)
				a = uint32(a)
				return bor(
					lsh(band(a, 0xFF), 24),
					lsh(band(rsh(a, 8), 0xFF), 16),
					lsh(band(rsh(a, 16), 0xFF), 8),
					band(rsh(a, 24), 0xFF)
				)
			end,
		}
	end
end
local function bshr(a, n)
	return bit32.rshift(a, n)
end
local function bshl(a, n)
	return bit32.lshift(a, n)
end
local function band(a, b)
	return bit32.band(a, b)
end
local function bor(a, b)
	return bit32.bor(a, b)
end
local _unpack = table.unpack or unpack
local pprint
do
	local _pprint = { VERSION = "0.1-zukv2" }
	local _depth = 1
	_pprint.defaults = {
		depth_limit = false,
		show_nil = true,
		show_boolean = true,
		show_number = true,
		show_string = true,
		show_table = true,
		show_function = true,
		show_thread = true,
		show_userdata = true,
		show_metatable = true,
		show_all = true,
		use_tostring = true,
		filter_function = nil,
		object_cache = "local",
		indent_size = 2,
		level_width = 80,
		wrap_string = true,
		wrap_array = false,
		string_is_utf8 = true,
		sort_keys = true,
	}
	local TYPES = {
		["nil"] = 1,
		["boolean"] = 2,
		["number"] = 3,
		["string"] = 4,
		["table"] = 5,
		["function"] = 6,
		["thread"] = 7,
		["userdata"] = 8,
	}
	local ESCAPE_MAP = {
		["\a"] = "\\a",
		["\b"] = "\\b",
		["\f"] = "\\f",
		["\n"] = "\\n",
		["\r"] = "\\r",
		["\t"] = "\\t",
		["\v"] = "\\v",
		["\\"] = "\\\\",
	}
	local CACHE_TYPES = { ["table"] = true, ["function"] = true, ["thread"] = true, ["userdata"] = true }
	local function tokenize_string(s)
		local t = {}
		for i = 1, #s do
			local c = s:sub(i, i)
			local b = c:byte()
			local e = ESCAPE_MAP[c]
			if (b >= 0x20 and b < 0x80) or e then
				t[i] = { char = e or c, len = #(e or c) }
			else
				t[i] = { char = string.format("\\x%02x", b), len = 4 }
			end
			if c == '"' then
				t.has_double_quote = true
			elseif c == "'" then
				t.has_single_quote = true
			end
		end
		return t
	end
	local tokenize_utf8_string = tokenize_string
	local function is_plain_key(key)
		return type(key) == "string" and key:match("^[%a_][%a%d_]*$")
	end
	local function str_natural_cmp(lhs, rhs)
		while #lhs > 0 and #rhs > 0 do
			local lmid, lend2 = lhs:find("%d+")
			local rmid, rend2 = rhs:find("%d+")
			if not (lmid and rmid) then
				return lhs < rhs
			end
			local lsub = lhs:sub(1, lmid - 1)
			local rsub = rhs:sub(1, rmid - 1)
			if lsub ~= rsub then
				return lsub < rsub
			end
			local lnum = tonumber(lhs:sub(lmid, lend2))
			local rnum = tonumber(rhs:sub(rmid, rend2))
			if lnum ~= rnum then
				return lnum < rnum
			end
			lhs = lhs:sub(lend2 + 1)
			rhs = rhs:sub(rend2 + 1)
		end
		return lhs < rhs
	end
	local function cmp(lhs, rhs)
		local tl, tr = type(lhs), type(rhs)
		if tl == "number" and tr == "number" then
			return lhs < rhs
		end
		if tl == "string" and tr == "string" then
			return str_natural_cmp(lhs, rhs)
		end
		if tl == tr then
			return str_natural_cmp(tostring(lhs), tostring(rhs))
		end
		return (TYPES[tl] or 9) < (TYPES[tr] or 9)
	end
	local function cache_apperance(obj, cache, option)
		if not cache.visited_tables then
			cache.visited_tables = setmetatable({}, { __mode = "k" })
		end
		local t = type(obj)
		if (not TYPES[t] and not option.show_table) or (TYPES[t] and not option["show_" .. t]) then
			return
		end
		if CACHE_TYPES[t] or TYPES[t] == nil then
			if not cache[t] then
				cache[t] = setmetatable({}, { __mode = "k" })
				cache[t]._cnt = 0
			end
			if not cache[t][obj] then
				cache[t]._cnt = cache[t]._cnt + 1
				cache[t][obj] = cache[t]._cnt
			end
		end
		if t == "table" or TYPES[t] == nil then
			if cache.visited_tables[obj] == false then
				return
			elseif cache.visited_tables[obj] == nil then
				cache.visited_tables[obj] = 1
			else
				cache.visited_tables[obj] = cache.visited_tables[obj] + 1
				return
			end
			for k, v in pairs(obj) do
				cache_apperance(k, cache, option)
				cache_apperance(v, cache, option)
			end
			local mt = getmetatable(obj)
			if mt and option.show_metatable then
				cache_apperance(mt, cache, option)
			end
		end
	end
	local function make_option(option)
		if option == nil then
			option = {}
		end
		for k, v in pairs(_pprint.defaults) do
			if option[k] == nil then
				option[k] = v
			end
			if option.show_all then
				for t2, _ in pairs(TYPES) do
					option["show_" .. t2] = true
				end
				option.show_metatable = true
			end
		end
		return option
	end
	function _pprint.setup(option)
		_pprint.defaults = make_option(option)
	end
	function _pprint.pformat(obj, option, printer)
		option = make_option(option)
		local buf = {}
		local function default_printer(s)
			table.insert(buf, s)
		end
		printer = printer or default_printer
		local cache
		if option.object_cache == "global" then
			cache = _pprint._cache or {}
			_pprint._cache = nil
		elseif option.object_cache == "local" then
			cache = {}
		end
		local last = ""
		local status = { indent = "", len = 0, printed_something = false }
		local function wrapped_printer(s)
			status.printed_something = true
			printer(last)
			last = s
		end
		local function _indent(d)
			status.indent = string.rep(" ", d + #status.indent)
		end
		local function _n(d)
			if not status.printed_something then
				return
			end
			wrapped_printer("\n")
			wrapped_printer(status.indent)
			if d then
				_indent(d)
			end
			status.len = 0
			return true
		end
		local function _p(s, nowrap)
			status.len = status.len + #s
			if not nowrap and status.len > option.level_width then
				_n()
				wrapped_printer(s)
				status.len = #s
			else
				wrapped_printer(s)
			end
		end
		local formatter = {}
		local function format(v)
			local f = formatter[type(v)] or formatter.table
			if option.filter_function and option.filter_function(v, nil, nil) then
				return ""
			end
			return f(v)
		end
		local function tostring_formatter(v)
			return tostring(v)
		end
		local function number_formatter(n)
			return n == math.huge and "[[math.huge]]" or tostring(n)
		end
		local function nop_formatter(v)
			return ""
		end
		local function make_fixed_formatter(t2, has_cache)
			if has_cache then
				return function(v)
					return string.format("[[%s %d]]", t2, cache[t2][v])
				end
			else
				return function(v)
					return "[[" .. t2 .. "]]"
				end
			end
		end
		local function string_formatter(s, force_long_quote)
			local tokens = option.string_is_utf8 and tokenize_utf8_string(s) or tokenize_string(s)
			local string_len = 0
			local escape_quotes = tokens.has_double_quote and tokens.has_single_quote
			for _, token in ipairs(tokens) do
				string_len = string_len + (escape_quotes and token.char == '"' and 2 or token.len)
			end
			local quote_len = 2
			local long_quote_dashes = 0
			local function compute_long_quote_dashes()
				while s:find("%]" .. string.rep("=", long_quote_dashes) .. "%]") do
					long_quote_dashes = long_quote_dashes + 1
				end
			end
			if force_long_quote then
				compute_long_quote_dashes()
				quote_len = 2 + long_quote_dashes
			end
			if quote_len + string_len + status.len > option.level_width then
				_n()
				if option.wrap_string and string_len + quote_len > option.level_width then
					if not force_long_quote then
						compute_long_quote_dashes()
						quote_len = 2 + long_quote_dashes
					end
					local dashes = string.rep("=", long_quote_dashes)
					_p("[" .. dashes .. "[", true)
					local line_len, line = 0, ""
					for _, token in ipairs(tokens) do
						if line_len + token.len + status.len > option.level_width then
							_n()
							_p(line, true)
							line_len = token.len
							line = token.char
						else
							line_len = line_len + token.len
							line = line .. token.char
						end
					end
					return line .. "]" .. dashes .. "]"
				end
			end
			if tokens.has_double_quote and tokens.has_single_quote and not force_long_quote then
				for i2, token in ipairs(tokens) do
					if token.char == '"' then
						tokens[i2].char = '\\"'
					end
				end
			end
			local flat = {}
			for _, token in ipairs(tokens) do
				table.insert(flat, token.char)
			end
			local concat = table.concat(flat)
			if force_long_quote then
				local dashes = string.rep("=", long_quote_dashes)
				return "[" .. dashes .. "[" .. concat .. "]" .. dashes .. "]"
			elseif tokens.has_single_quote then
				return '"' .. concat .. '"'
			else
				return "'" .. concat .. "'"
			end
		end
		local function table_formatter(t2)
			if option.use_tostring then
				local mt = getmetatable(t2)
				if mt and mt.__tostring then
					return string_formatter(tostring(t2), true)
				end
			end
			local print_header_ix = nil
			local ttype = type(t2)
			if option.object_cache then
				local cache_state = cache.visited_tables[t2]
				local tix = cache[ttype] and cache[ttype][t2]
				if cache_state == false then
					return string_formatter(string.format("%s %d", ttype, tix), true)
				elseif cache_state and cache_state > 1 then
					print_header_ix = tix
					cache.visited_tables[t2] = false
				end
			end
			local limit = tonumber(option.depth_limit)
			if limit and _depth > limit then
				if print_header_ix then
					return string.format("[[%s %d]]...", ttype, print_header_ix)
				end
				return string_formatter(tostring(t2), true)
			end
			local tlen = #t2
			local wrapped = false
			_p("{")
			_indent(option.indent_size)
			_p(string.rep(" ", option.indent_size - 1))
			if print_header_ix then
				_p(string.format(" ", ttype, print_header_ix))
			end
			for ix = 1, tlen do
				local v = t2[ix]
				if
					formatter[type(v)] ~= nop_formatter
					and not (option.filter_function and option.filter_function(v, ix, t2))
				then
					if option.wrap_array then
						wrapped = _n()
					end
					_depth = _depth + 1
					_p(format(v) .. ", ")
					_depth = _depth - 1
				end
			end
			local function is_hash_key(k)
				if type(k) ~= "number" then
					return true
				end
				local numkey = math.floor(tonumber(k))
				if numkey ~= k or numkey > tlen or numkey <= 0 then
					return true
				end
			end
			local function print_kv(k, v)
				if
					formatter[type(v)] == nop_formatter
					or formatter[type(k)] == nop_formatter
					or (option.filter_function and option.filter_function(v, k, t2))
				then
					return
				end
				wrapped = _n()
				if is_plain_key(k) then
					_p(k, true)
				else
					_p("[")
					local fmtk = format(k)
					if fmtk:match("%[%[") then
						_p(" " .. fmtk .. " ", true)
					else
						_p(fmtk, true)
					end
					_p("]")
				end
				_p(" = ", true)
				_depth = _depth + 1
				_p(format(v), true)
				_depth = _depth - 1
				_p(",", true)
			end
			if option.sort_keys then
				local keys = {}
				for k, _ in pairs(t2) do
					if is_hash_key(k) then
						table.insert(keys, k)
					end
				end
				table.sort(keys, cmp)
				for _, k in ipairs(keys) do
					print_kv(k, t2[k])
				end
			else
				for k, v in pairs(t2) do
					if is_hash_key(k) then
						print_kv(k, v)
					end
				end
			end
			if option.show_metatable then
				local mt = getmetatable(t2)
				if mt then
					print_kv("__metatable", mt)
				end
			end
			_indent(-option.indent_size)
			last = last:gsub("^ +$", ""):gsub(",%s*$", " ")
			if wrapped then
				_n()
			end
			_p("}")
			return ""
		end
		formatter["nil"] = option.show_nil and tostring_formatter or nop_formatter
		formatter["boolean"] = option.show_boolean and tostring_formatter or nop_formatter
		formatter["number"] = option.show_number and number_formatter or nop_formatter
		formatter["function"] = option.show_function and make_fixed_formatter("function", option.object_cache)
			or nop_formatter
		formatter["thread"] = option.show_thread and make_fixed_formatter("thread", option.object_cache)
			or nop_formatter
		formatter["userdata"] = option.show_userdata and make_fixed_formatter("userdata", option.object_cache)
			or nop_formatter
		formatter["string"] = option.show_string and string_formatter or nop_formatter
		formatter["table"] = option.show_table and table_formatter or nop_formatter
		if option.object_cache then
			cache_apperance(obj, cache, option)
		end
		_p(format(obj))
		printer(last)
		if option.object_cache == "global" then
			_pprint._cache = cache
		end
		return table.concat(buf)
	end
	function _pprint.pprint(...)
		local args = { ... }
		local len = select("#", ...)
		for ix = 1, len do
			local v = args[ix]
			if type(v) == "string" then
				print(v)
			else
				print(_pprint.pformat(v))
			end
		end
	end
	setmetatable(_pprint, {
		__call = function(_, ...)
			_pprint.pprint(...)
		end,
	})
	pprint = _pprint
end
local BytecodeReader
do
	local function _BR_oob(need, pos, len)
		error(string.format("BytecodeReader: EndOfStream — need %d byte(s) at offset %d (len %d)", need, pos, len), 3)
	end
	local BR = {}
	BR.__index = function(self, k)
		if k == "Position" then
			return self._pos - 1
		end
		return BR[k]
	end
	BR.__newindex = function(self, k, v)
		if k == "Position" then
			local p = math.floor(v) + 1
			if p < 1 or p > rawget(self, "Length") + 1 then
				error(string.format("BytecodeReader: Position %d out of range [0, %d]", v, rawget(self, "Length")), 2)
			end
			rawset(self, "_pos", p)
		else
			rawset(self, k, v)
		end
	end
	function BR.new(bytes)
		assert(type(bytes) == "string", "BytecodeReader.new: bytes must be a string")
		local self = setmetatable({}, BR)
		self.Stream = bytes
		self.Length = #bytes
		self._pos = 1
		return self
	end
	local function _guard(self, n)
		if self._pos + n - 1 > self.Length then
			_BR_oob(n, self._pos - 1, self.Length)
		end
	end
	function BR:ReadBoolean()
		_guard(self, 1)
		local b = string.byte(self.Stream, self._pos)
		self._pos = self._pos + 1
		if b == 0 then
			return false
		elseif b == 1 then
			return true
		else
			error(string.format("BytecodeReader:ReadBoolean — non-boolean: 0x%02X", b), 2)
		end
	end
	function BR:ReadByte()
		_guard(self, 1)
		local b = string.byte(self.Stream, self._pos)
		self._pos = self._pos + 1
		return b
	end
	function BR:ReadBytes(count)
		_guard(self, count)
		local t = {}
		for i = 1, count do
			t[i] = string.byte(self.Stream, self._pos)
			self._pos = self._pos + 1
		end
		return t
	end
	function BR:ReadInt16()
		_guard(self, 2)
		local a, b2 = string.byte(self.Stream, self._pos, self._pos + 1)
		self._pos = self._pos + 2
		local v = bor(a, bshl(b2, 8))
		if v >= 0x8000 then
			v = v - 0x10000
		end
		return v
	end
	function BR:ReadUInt16()
		_guard(self, 2)
		local a, b2 = string.byte(self.Stream, self._pos, self._pos + 1)
		self._pos = self._pos + 2
		return bor(a, bshl(b2, 8))
	end
	function BR:ReadInt32()
		_guard(self, 4)
		local a, b2, c, d = string.byte(self.Stream, self._pos, self._pos + 3)
		self._pos = self._pos + 4
		local v = bor(a, bor(bshl(b2, 8), bor(bshl(c, 16), bshl(d, 24))))
		if v >= 0x80000000 then
			v = v - 0x100000000
		end
		return v
	end
	function BR:ReadUInt32()
		_guard(self, 4)
		local a, b2, c, d = string.byte(self.Stream, self._pos, self._pos + 3)
		self._pos = self._pos + 4
		return bor(a, bor(bshl(b2, 8), bor(bshl(c, 16), bshl(d, 24))))
	end
	function BR:ReadUInt32Compressed()
		local result, shift = 0, 0
		repeat
			_guard(self, 1)
			local b2 = string.byte(self.Stream, self._pos)
			self._pos = self._pos + 1
			result = bor(result, bshl(band(b2, 0x7F), shift))
			shift = shift + 7
			if band(b2, 0x80) == 0 then
				break
			end
		until shift >= 35
		return result
	end
	function BR:ReadInt32Compressed()
		local v = self:ReadUInt32Compressed()
		if v >= 0x80000000 then
			v = v - 0x100000000
		end
		return v
	end
	function BR:ReadSingle()
		_guard(self, 4)
		local a, b2, c, d = string.byte(self.Stream, self._pos, self._pos + 3)
		self._pos = self._pos + 4
		local bits = bor(a, bor(bshl(b2, 8), bor(bshl(c, 16), bshl(d, 24))))
		local sign = bshr(bits, 31) == 1 and -1 or 1
		local exp = band(bshr(bits, 23), 0xFF)
		local frac = band(bits, 0x7FFFFF)
		if exp == 0 then
			return sign * (frac / 0x800000) * 2 ^ -126
		elseif exp == 255 then
			return frac == 0 and sign * math.huge or (0 / 0)
		else
			return sign * (1 + frac / 0x800000) * 2 ^ (exp - 127)
		end
	end
	function BR:ReadDouble()
		_guard(self, 8)
		local bytes = { string.byte(self.Stream, self._pos, self._pos + 7) }
		self._pos = self._pos + 8
		local lo = bor(bytes[1], bor(bshl(bytes[2], 8), bor(bshl(bytes[3], 16), bshl(bytes[4], 24))))
		local hi = bor(bytes[5], bor(bshl(bytes[6], 8), bor(bshl(bytes[7], 16), bshl(bytes[8], 24))))
		if lo < 0 then
			lo = lo + 0x100000000
		end
		if hi < 0 then
			hi = hi + 0x100000000
		end
		local sign = bshr(hi, 31) == 1 and -1 or 1
		local exp = band(bshr(hi, 20), 0x7FF)
		local frac = band(hi, 0x000FFFFF) * (2 ^ 32) + lo
		if exp == 0 then
			return sign * (frac / 2 ^ 52) * 2 ^ -1022
		elseif exp == 0x7FF then
			return frac == 0 and sign * math.huge or (0 / 0)
		else
			return sign * (1 + frac / 2 ^ 52) * 2 ^ (exp - 1023)
		end
	end
	function BR:ReadU64()
		_guard(self, 8)
		local bytes = { string.byte(self.Stream, self._pos, self._pos + 7) }
		self._pos = self._pos + 8
		local lo = bor(bytes[1], bor(bshl(bytes[2], 8), bor(bshl(bytes[3], 16), bshl(bytes[4], 24))))
		local hi = bor(bytes[5], bor(bshl(bytes[6], 8), bor(bshl(bytes[7], 16), bshl(bytes[8], 24))))
		if lo < 0 then
			lo = lo + 0x100000000
		end
		if hi < 0 then
			hi = hi + 0x100000000
		end
		return hi * (2 ^ 32) + lo
	end
	function BR:ReadASCII(length)
		_guard(self, length)
		local s = string.sub(self.Stream, self._pos, self._pos + length - 1)
		self._pos = self._pos + length
		return s
	end
	function BR:Peek()
		if self._pos > self.Length then
			return -1
		end
		return string.byte(self.Stream, self._pos)
	end
	BytecodeReader = BR
end
local Reader = {}
Reader.__index = Reader
-- Detect Roblox's native buffer API for faster bytecode parsing.
-- When available, we wrap the string in a buffer once and use buffer.*
-- read functions (readu8, readu32, readf64 etc.) which are significantly
-- faster than repeated string.byte calls inside the executor environment.
local _bufferAPI = type(buffer) == "userdata" and buffer or
	(type(_G.buffer) == "userdata" and _G.buffer) or nil
-- We need at minimum: fromstring, readu8, readu32, readf32, readf64, readi8, readi32
if _bufferAPI then
	local _bf = _bufferAPI
	if type(_bf.fromstring) ~= "function"
		or type(_bf.readu8) ~= "function"
		or type(_bf.readu32) ~= "function"
	then
		_bufferAPI = nil
	end
end

function Reader.new(bytes)
	local self = setmetatable({ _bytes = bytes, _pos = 1, _len = #bytes }, Reader)
	if _bufferAPI then
		-- Pre-convert once; all subsequent reads use offset-based buffer ops
		local ok, buf = pcall(_bufferAPI.fromstring, bytes)
		if ok and buf then
			self._buf = buf
		end
	end
	return self
end
function Reader:len()
	return self._len
end
local function _checkbounds(self, n)
	if self._pos + n - 1 > self._len then
		error(string.format("Reader OOB: need %d byte(s) at offset %d (buf len %d)", n, self._pos - 1, self._len), 3)
	end
end
function Reader:nextByte()
	_checkbounds(self, 1)
	local b
	if self._buf then
		b = _bufferAPI.readu8(self._buf, self._pos - 1)
	else
		b = string.byte(self._bytes, self._pos)
	end
	self._pos = self._pos + 1
	return b
end
function Reader:nextSignedByte()
	if self._buf and type(_bufferAPI.readi8) == "function" then
		_checkbounds(self, 1)
		local b = _bufferAPI.readi8(self._buf, self._pos - 1)
		self._pos = self._pos + 1
		return b
	end
	local b = self:nextByte()
	if b >= 128 then
		return b - 256
	end
	return b
end
function Reader:nextBytes(count)
	local t = {}
	for i = 1, count do
		t[i] = self:nextByte()
	end
	return t
end
function Reader:nextChar()
	return string.char(self:nextByte())
end
function Reader:nextUInt32()
	_checkbounds(self, 4)
	local v
	if self._buf then
		-- buffer.readu32 reads little-endian u32 natively — matches Luau bytecode layout
		v = _bufferAPI.readu32(self._buf, self._pos - 1)
	else
		local a, b, c, d = string.byte(self._bytes, self._pos, self._pos + 3)
		v = bor(a, bor(bshl(b, 8), bor(bshl(c, 16), bshl(d, 24))))
	end
	self._pos = self._pos + 4
	return v
end
function Reader:nextInt32()
	local v = self:nextUInt32()
	if v >= 0x80000000 then
		return v - 0x100000000
	end
	return v
end
function Reader:nextFloat()
	_checkbounds(self, 4)
	if self._buf and type(_bufferAPI.readf32) == "function" then
		local v = _bufferAPI.readf32(self._buf, self._pos - 1)
		self._pos = self._pos + 4
		return v
	end
	local a, b, c, d = string.byte(self._bytes, self._pos, self._pos + 3)
	self._pos = self._pos + 4
	local bits = bor(a, bor(bshl(b, 8), bor(bshl(c, 16), bshl(d, 24))))
	local sign = bshr(bits, 31) == 1 and -1 or 1
	local exp = band(bshr(bits, 23), 0xFF)
	local frac = band(bits, 0x7FFFFF)
	local value
	if exp == 0 then
		value = sign * (frac / 0x800000) * 2 ^ -126
	elseif exp == 255 then
		value = frac == 0 and (sign * math.huge) or (0 / 0)
	else
		value = sign * (1 + frac / 0x800000) * 2 ^ (exp - 127)
	end
	return value
end
function Reader:nextVarInt()
	local result = 0
	for i = 0, 4 do
		local b = self:nextByte()
		result = bor(result, bshl(band(b, 0x7F), i * 7))
		if band(b, 0x80) == 0 then
			break
		end
	end
	return result
end
function Reader:nextString(slen)
	slen = slen or self:nextVarInt()
	if slen == 0 then
		return ""
	end
	_checkbounds(self, slen)
	local s = string.sub(self._bytes, self._pos, self._pos + slen - 1)
	self._pos = self._pos + slen
	return s
end
function Reader:nextDouble()
	_checkbounds(self, 8)
	if self._buf and type(_bufferAPI.readf64) == "function" then
		local v = _bufferAPI.readf64(self._buf, self._pos - 1)
		self._pos = self._pos + 8
		return v
	end
	local bytes = { string.byte(self._bytes, self._pos, self._pos + 7) }
	self._pos = self._pos + 8
	local lo = bor(bytes[1], bor(bshl(bytes[2], 8), bor(bshl(bytes[3], 16), bshl(bytes[4], 24))))
	local hi = bor(bytes[5], bor(bshl(bytes[6], 8), bor(bshl(bytes[7], 16), bshl(bytes[8], 24))))
	if lo < 0 then
		lo = lo + 0x100000000
	end
	if hi < 0 then
		hi = hi + 0x100000000
	end
	local sign = (bshr(hi, 31) == 1) and -1 or 1
	local exp = band(bshr(hi, 20), 0x7FF)
	local frac_hi = band(hi, 0x000FFFFF)
	local frac = frac_hi * (2 ^ 32) + lo
	if exp == 0 then
		return sign * (frac / (2 ^ 52)) * 2 ^ -1022
	elseif exp == 0x7FF then
		return frac == 0 and sign * math.huge or (0 / 0)
	else
		return sign * (1 + frac / (2 ^ 52)) * 2 ^ (exp - 1023)
	end
end
local FLOAT_PRECISION = 7
local function Reader_Set(fp)
	FLOAT_PRECISION = fp
end
local Strings = {
	SUCCESS = "%s",
	TIMEOUT = "-- DECOMPILER TIMEOUT",
	COMPILATION_FAILURE = "-- SCRIPT FAILED TO COMPILE, ERROR:\n%s",
	UNSUPPORTED_LBC_VERSION = "-- PASSED BYTECODE IS TOO OLD AND IS NOT SUPPORTED",
	USED_GLOBALS = "-- USED GLOBALS: %s.\n",
	DECOMPILER_REMARK = "-- DECOMPILER REMARK: %s\n",
}
local CASE_MULTIPLIER = 227
local Luau = {
	OpCode = {
		{ name = "NOP", type = "none" },
		{ name = "BREAK", type = "none" },
		{ name = "LOADNIL", type = "A" },
		{ name = "LOADB", type = "ABC" },
		{ name = "LOADN", type = "AsD" },
		{ name = "LOADK", type = "AD" },
		{ name = "MOVE", type = "AB" },
		{ name = "GETGLOBAL", type = "AC", aux = true },
		{ name = "SETGLOBAL", type = "AC", aux = true },
		{ name = "GETUPVAL", type = "AB" },
		{ name = "SETUPVAL", type = "AB" },
		{ name = "CLOSEUPVALS", type = "A" },
		{ name = "GETIMPORT", type = "AD", aux = true },
		{ name = "GETTABLE", type = "ABC" },
		{ name = "SETTABLE", type = "ABC" },
		{ name = "GETTABLEKS", type = "ABC", aux = true },
		{ name = "SETTABLEKS", type = "ABC", aux = true },
		{ name = "GETTABLEN", type = "ABC" },
		{ name = "SETTABLEN", type = "ABC" },
		{ name = "NEWCLOSURE", type = "AD" },
		{ name = "NAMECALL", type = "ABC", aux = true },
		{ name = "CALL", type = "ABC" },
		{ name = "RETURN", type = "AB" },
		{ name = "JUMP", type = "sD" },
		{ name = "JUMPBACK", type = "sD" },
		{ name = "JUMPIF", type = "AsD" },
		{ name = "JUMPIFNOT", type = "AsD" },
		{ name = "JUMPIFEQ", type = "AsD", aux = true },
		{ name = "JUMPIFLE", type = "AsD", aux = true },
		{ name = "JUMPIFLT", type = "AsD", aux = true },
		{ name = "JUMPIFNOTEQ", type = "AsD", aux = true },
		{ name = "JUMPIFNOTLE", type = "AsD", aux = true },
		{ name = "JUMPIFNOTLT", type = "AsD", aux = true },
		{ name = "ADD", type = "ABC" },
		{ name = "SUB", type = "ABC" },
		{ name = "MUL", type = "ABC" },
		{ name = "DIV", type = "ABC" },
		{ name = "MOD", type = "ABC" },
		{ name = "POW", type = "ABC" },
		{ name = "ADDK", type = "ABC" },
		{ name = "SUBK", type = "ABC" },
		{ name = "MULK", type = "ABC" },
		{ name = "DIVK", type = "ABC" },
		{ name = "MODK", type = "ABC" },
		{ name = "POWK", type = "ABC" },
		{ name = "AND", type = "ABC" },
		{ name = "OR", type = "ABC" },
		{ name = "ANDK", type = "ABC" },
		{ name = "ORK", type = "ABC" },
		{ name = "CONCAT", type = "ABC" },
		{ name = "NOT", type = "AB" },
		{ name = "MINUS", type = "AB" },
		{ name = "LENGTH", type = "AB" },
		{ name = "NEWTABLE", type = "AB", aux = true },
		{ name = "DUPTABLE", type = "AD" },
		{ name = "SETLIST", type = "ABC", aux = true },
		{ name = "FORNPREP", type = "AsD" },
		{ name = "FORNLOOP", type = "AsD" },
		{ name = "FORGLOOP", type = "AsD", aux = true },
		{ name = "FORGPREP_INEXT", type = "A" },
		{ name = "FASTCALL3", type = "ABC", aux = true },
		{ name = "FORGPREP_NEXT", type = "A" },
		{ name = "NATIVECALL", type = "none" },
		{ name = "GETVARARGS", type = "AB" },
		{ name = "DUPCLOSURE", type = "AD" },
		{ name = "PREPVARARGS", type = "A" },
		{ name = "LOADKX", type = "A", aux = true },
		{ name = "JUMPX", type = "E" },
		{ name = "FASTCALL", type = "AC" },
		{ name = "COVERAGE", type = "E" },
		{ name = "CAPTURE", type = "AB" },
		{ name = "SUBRK", type = "ABC" },
		{ name = "DIVRK", type = "ABC" },
		{ name = "FASTCALL1", type = "ABC" },
		{ name = "FASTCALL2", type = "ABC", aux = true },
		{ name = "FASTCALL2K", type = "ABC", aux = true },
		{ name = "FORGPREP", type = "AsD" },
		{ name = "JUMPXEQKNIL", type = "AsD", aux = true },
		{ name = "JUMPXEQKB", type = "AsD", aux = true },
		{ name = "JUMPXEQKN", type = "AsD", aux = true },
		{ name = "JUMPXEQKS", type = "AsD", aux = true },
		{ name = "IDIV", type = "ABC" },
		{ name = "IDIVK", type = "ABC" },
		{ name = "_COUNT", type = "none" },
	},
	BytecodeTag = {
		LBC_VERSION_MIN = 3,
		LBC_VERSION_MAX = 6,
		LBC_TYPE_VERSION_MIN = 1,
		LBC_TYPE_VERSION_MAX = 3,
		LBC_CONSTANT_NIL = 0,
		LBC_CONSTANT_BOOLEAN = 1,
		LBC_CONSTANT_NUMBER = 2,
		LBC_CONSTANT_STRING = 3,
		LBC_CONSTANT_IMPORT = 4,
		LBC_CONSTANT_TABLE = 5,
		LBC_CONSTANT_CLOSURE = 6,
		LBC_CONSTANT_VECTOR = 7,
	},
	BytecodeType = {
		LBC_TYPE_NIL = 0,
		LBC_TYPE_BOOLEAN = 1,
		LBC_TYPE_NUMBER = 2,
		LBC_TYPE_STRING = 3,
		LBC_TYPE_TABLE = 4,
		LBC_TYPE_FUNCTION = 5,
		LBC_TYPE_THREAD = 6,
		LBC_TYPE_USERDATA = 7,
		LBC_TYPE_VECTOR = 8,
		LBC_TYPE_BUFFER = 9,
		LBC_TYPE_ANY = 15,
		LBC_TYPE_TAGGED_USERDATA_BASE = 64,
		LBC_TYPE_TAGGED_USERDATA_END = 64 + 32,
		LBC_TYPE_OPTIONAL_BIT = 0,
	},
	CaptureType = { LCT_VAL = 0, LCT_REF = 1, LCT_UPVAL = 2 },
	BuiltinFunction = {
		LBF_NONE = 0,
		LBF_ASSERT = 1,
		LBF_MATH_ABS = 2,
		LBF_MATH_ACOS = 3,
		LBF_MATH_ASIN = 4,
		LBF_MATH_ATAN2 = 5,
		LBF_MATH_ATAN = 6,
		LBF_MATH_CEIL = 7,
		LBF_MATH_COSH = 8,
		LBF_MATH_COS = 9,
		LBF_MATH_DEG = 10,
		LBF_MATH_EXP = 11,
		LBF_MATH_FLOOR = 12,
		LBF_MATH_FMOD = 13,
		LBF_MATH_FREXP = 14,
		LBF_MATH_LDEXP = 15,
		LBF_MATH_LOG10 = 16,
		LBF_MATH_LOG = 17,
		LBF_MATH_MAX = 18,
		LBF_MATH_MIN = 19,
		LBF_MATH_MODF = 20,
		LBF_MATH_POW = 21,
		LBF_MATH_RAD = 22,
		LBF_MATH_SINH = 23,
		LBF_MATH_SIN = 24,
		LBF_MATH_SQRT = 25,
		LBF_MATH_TANH = 26,
		LBF_MATH_TAN = 27,
		LBF_BIT32_ARSHIFT = 28,
		LBF_BIT32_BAND = 29,
		LBF_BIT32_BNOT = 30,
		LBF_BIT32_BOR = 31,
		LBF_BIT32_BXOR = 32,
		LBF_BIT32_BTEST = 33,
		LBF_BIT32_EXTRACT = 34,
		LBF_BIT32_LROTATE = 35,
		LBF_BIT32_LSHIFT = 36,
		LBF_BIT32_REPLACE = 37,
		LBF_BIT32_RROTATE = 38,
		LBF_BIT32_RSHIFT = 39,
		LBF_TYPE = 40,
		LBF_STRING_BYTE = 41,
		LBF_STRING_CHAR = 42,
		LBF_STRING_LEN = 43,
		LBF_TYPEOF = 44,
		LBF_STRING_SUB = 45,
		LBF_MATH_CLAMP = 46,
		LBF_MATH_SIGN = 47,
		LBF_MATH_ROUND = 48,
		LBF_RAWSET = 49,
		LBF_RAWGET = 50,
		LBF_RAWEQUAL = 51,
		LBF_TABLE_INSERT = 52,
		LBF_TABLE_UNPACK = 53,
		LBF_VECTOR = 54,
		LBF_BIT32_COUNTLZ = 55,
		LBF_BIT32_COUNTRZ = 56,
		LBF_SELECT_VARARG = 57,
		LBF_RAWLEN = 58,
		LBF_BIT32_EXTRACTK = 59,
		LBF_GETMETATABLE = 60,
		LBF_SETMETATABLE = 61,
		LBF_TONUMBER = 62,
		LBF_TOSTRING = 63,
		LBF_BIT32_BYTESWAP = 64,
		LBF_BUFFER_READI8 = 65,
		LBF_BUFFER_READU8 = 66,
		LBF_BUFFER_WRITEU8 = 67,
		LBF_BUFFER_READI16 = 68,
		LBF_BUFFER_READU16 = 69,
		LBF_BUFFER_WRITEU16 = 70,
		LBF_BUFFER_READI32 = 71,
		LBF_BUFFER_READU32 = 72,
		LBF_BUFFER_WRITEU32 = 73,
		LBF_BUFFER_READF32 = 74,
		LBF_BUFFER_WRITEF32 = 75,
		LBF_BUFFER_READF64 = 76,
		LBF_BUFFER_WRITEF64 = 77,
		LBF_VECTOR_MAGNITUDE = 78,
		LBF_VECTOR_NORMALIZE = 79,
		LBF_VECTOR_CROSS = 80,
		LBF_VECTOR_DOT = 81,
		LBF_VECTOR_FLOOR = 82,
		LBF_VECTOR_CEIL = 83,
		LBF_VECTOR_ABS = 84,
		LBF_VECTOR_SIGN = 85,
		LBF_VECTOR_CLAMP = 86,
		LBF_VECTOR_MIN = 87,
		LBF_VECTOR_MAX = 88,
		LBF_MATH_LERP = 89,
	},
	ProtoFlag = {
		LPF_NATIVE_MODULE = bit32.lshift(1, 0),
		LPF_NATIVE_COLD = bit32.lshift(1, 1),
		LPF_NATIVE_FUNCTION = bit32.lshift(1, 2),
	},
}
Luau.BytecodeType.LBC_TYPE_OPTIONAL_BIT = bit32.lshift(1, 7)
Luau.BytecodeType.LBC_TYPE_INVALID = 256
function Luau:INSN_OP(i)
	return band(i, 0xFF)
end
function Luau:INSN_A(i)
	return band(bshr(i, 8), 0xFF)
end
function Luau:INSN_B(i)
	return band(bshr(i, 16), 0xFF)
end
function Luau:INSN_C(i)
	return band(bshr(i, 24), 0xFF)
end
function Luau:INSN_D(i)
	return bshr(i, 16)
end
function Luau:INSN_sD(i)
	local D = self:INSN_D(i)
	return (D > 0x7FFF and D <= 0xFFFF) and (-(0xFFFF - D) - 1) or D
end
function Luau:INSN_E(i)
	return bshr(i, 8)
end
function Luau:GetBaseTypeString(t, checkOpt)
	local BT = self.BytecodeType
	local tag = band(t, band(bit32.bnot(BT.LBC_TYPE_OPTIONAL_BIT), 0xFF))
	local names = {
		[BT.LBC_TYPE_NIL] = "nil",
		[BT.LBC_TYPE_BOOLEAN] = "boolean",
		[BT.LBC_TYPE_NUMBER] = "number",
		[BT.LBC_TYPE_STRING] = "string",
		[BT.LBC_TYPE_TABLE] = "table",
		[BT.LBC_TYPE_FUNCTION] = "function",
		[BT.LBC_TYPE_THREAD] = "thread",
		[BT.LBC_TYPE_USERDATA] = "userdata",
		[BT.LBC_TYPE_VECTOR] = "Vector3",
		[BT.LBC_TYPE_BUFFER] = "buffer",
		[BT.LBC_TYPE_ANY] = "any",
	}
	local r = names[tag] or "unknown"
	if checkOpt then
		r = r .. (band(t, BT.LBC_TYPE_OPTIONAL_BIT) == 0 and "" or "?")
	end
	return r
end
function Luau:GetBuiltinInfo(bfid)
	local BF = self.BuiltinFunction
	local map = {
		[BF.LBF_NONE] = "none",
		[BF.LBF_ASSERT] = "assert",
		[BF.LBF_TYPE] = "type",
		[BF.LBF_TYPEOF] = "typeof",
		[BF.LBF_RAWSET] = "rawset",
		[BF.LBF_RAWGET] = "rawget",
		[BF.LBF_RAWEQUAL] = "rawequal",
		[BF.LBF_RAWLEN] = "rawlen",
		[BF.LBF_TABLE_UNPACK] = "unpack",
		[BF.LBF_SELECT_VARARG] = "select",
		[BF.LBF_GETMETATABLE] = "getmetatable",
		[BF.LBF_SETMETATABLE] = "setmetatable",
		[BF.LBF_TONUMBER] = "tonumber",
		[BF.LBF_TOSTRING] = "tostring",
		[BF.LBF_MATH_ABS] = "math.abs",
		[BF.LBF_MATH_ACOS] = "math.acos",
		[BF.LBF_MATH_ASIN] = "math.asin",
		[BF.LBF_MATH_ATAN2] = "math.atan2",
		[BF.LBF_MATH_ATAN] = "math.atan",
		[BF.LBF_MATH_CEIL] = "math.ceil",
		[BF.LBF_MATH_COSH] = "math.cosh",
		[BF.LBF_MATH_COS] = "math.cos",
		[BF.LBF_MATH_DEG] = "math.deg",
		[BF.LBF_MATH_EXP] = "math.exp",
		[BF.LBF_MATH_FLOOR] = "math.floor",
		[BF.LBF_MATH_FMOD] = "math.fmod",
		[BF.LBF_MATH_FREXP] = "math.frexp",
		[BF.LBF_MATH_LDEXP] = "math.ldexp",
		[BF.LBF_MATH_LOG10] = "math.log10",
		[BF.LBF_MATH_LOG] = "math.log",
		[BF.LBF_MATH_MAX] = "math.max",
		[BF.LBF_MATH_MIN] = "math.min",
		[BF.LBF_MATH_MODF] = "math.modf",
		[BF.LBF_MATH_POW] = "math.pow",
		[BF.LBF_MATH_RAD] = "math.rad",
		[BF.LBF_MATH_SINH] = "math.sinh",
		[BF.LBF_MATH_SIN] = "math.sin",
		[BF.LBF_MATH_SQRT] = "math.sqrt",
		[BF.LBF_MATH_TANH] = "math.tanh",
		[BF.LBF_MATH_TAN] = "math.tan",
		[BF.LBF_MATH_CLAMP] = "math.clamp",
		[BF.LBF_MATH_SIGN] = "math.sign",
		[BF.LBF_MATH_ROUND] = "math.round",
		[BF.LBF_BIT32_ARSHIFT] = "bit32.arshift",
		[BF.LBF_BIT32_BAND] = "bit32.band",
		[BF.LBF_BIT32_BNOT] = "bit32.bnot",
		[BF.LBF_BIT32_BOR] = "bit32.bor",
		[BF.LBF_BIT32_BXOR] = "bit32.bxor",
		[BF.LBF_BIT32_BTEST] = "bit32.btest",
		[BF.LBF_BIT32_EXTRACT] = "bit32.extract",
		[BF.LBF_BIT32_EXTRACTK] = "bit32.extract",
		[BF.LBF_BIT32_LROTATE] = "bit32.lrotate",
		[BF.LBF_BIT32_LSHIFT] = "bit32.lshift",
		[BF.LBF_BIT32_REPLACE] = "bit32.replace",
		[BF.LBF_BIT32_RROTATE] = "bit32.rrotate",
		[BF.LBF_BIT32_RSHIFT] = "bit32.rshift",
		[BF.LBF_BIT32_COUNTLZ] = "bit32.countlz",
		[BF.LBF_BIT32_COUNTRZ] = "bit32.countrz",
		[BF.LBF_BIT32_BYTESWAP] = "bit32.byteswap",
		[BF.LBF_STRING_BYTE] = "string.byte",
		[BF.LBF_STRING_CHAR] = "string.char",
		[BF.LBF_STRING_LEN] = "string.len",
		[BF.LBF_STRING_SUB] = "string.sub",
		[BF.LBF_TABLE_INSERT] = "table.insert",
		[BF.LBF_VECTOR] = "Vector3.new",
		[BF.LBF_BUFFER_READI8] = "buffer.readi8",
		[BF.LBF_BUFFER_READU8] = "buffer.readu8",
		[BF.LBF_BUFFER_WRITEU8] = "buffer.writeu8",
		[BF.LBF_BUFFER_READI16] = "buffer.readi16",
		[BF.LBF_BUFFER_READU16] = "buffer.readu16",
		[BF.LBF_BUFFER_WRITEU16] = "buffer.writeu16",
		[BF.LBF_BUFFER_READI32] = "buffer.readi32",
		[BF.LBF_BUFFER_READU32] = "buffer.readu32",
		[BF.LBF_BUFFER_WRITEU32] = "buffer.writeu32",
		[BF.LBF_BUFFER_READF32] = "buffer.readf32",
		[BF.LBF_BUFFER_WRITEF32] = "buffer.writef32",
		[BF.LBF_BUFFER_READF64] = "buffer.readf64",
		[BF.LBF_BUFFER_WRITEF64] = "buffer.writef64",
		[BF.LBF_VECTOR_MAGNITUDE] = "vector.magnitude",
		[BF.LBF_VECTOR_NORMALIZE] = "vector.normalize",
		[BF.LBF_VECTOR_CROSS] = "vector.cross",
		[BF.LBF_VECTOR_DOT] = "vector.dot",
		[BF.LBF_VECTOR_FLOOR] = "vector.floor",
		[BF.LBF_VECTOR_CEIL] = "vector.ceil",
		[BF.LBF_VECTOR_ABS] = "vector.abs",
		[BF.LBF_VECTOR_SIGN] = "vector.sign",
		[BF.LBF_VECTOR_CLAMP] = "vector.clamp",
		[BF.LBF_VECTOR_MIN] = "vector.min",
		[BF.LBF_VECTOR_MAX] = "vector.max",
		[BF.LBF_MATH_LERP] = "math.lerp",
	}
	return map[bfid] or ("builtin#" .. tostring(bfid))
end
do
	local raw = Luau.OpCode
	local encoded = {}
	for i, v in ipairs(raw) do
		local case = band((i - 1) * CASE_MULTIPLIER, 0xFF)
		encoded[case] = v
	end
	Luau.OpCode = encoded
end
local DEFAULT_OPTIONS = {
	EnabledRemarks = { ColdRemark = false, InlineRemark = false },
	DecompilerTimeout = 10,
	DecompilerMode = "disasm",
	ReaderFloatPrecision = 7,
	ShowDebugInformation = false,
	ShowInstructionLines = false,
	ShowOperationIndex = true,
	ShowOperationNames = true,
	ShowTrivialOperations = true,
	UseTypeInfo = true,
	pprint = true,
	ListUsedGlobals = true,
	ReturnElapsedTime = false,
	CleanMode = false,
}
local LuauOpCode = Luau.OpCode
local LuauBytecodeTag = Luau.BytecodeTag
local LuauBytecodeType = Luau.BytecodeType
local LuauCaptureType = Luau.CaptureType
local LuauProtoFlag = Luau.ProtoFlag
local function toBoolean(v)
	return v ~= 0
end
local function toEscapedString(v)
	if type(v) == "string" then
		return string.format("%q", v)
	end
	return tostring(v)
end
local function formatIndexString(key)
	if type(key) == "string" and key:match("^[%a_][%w_]*$") then
		return "." .. key
	end
	return "[" .. toEscapedString(key) .. "]"
end
local function padLeft(v, ch, n)
	local s = tostring(v)
	return string.rep(ch, math.max(0, n - #s)) .. s
end
local function padRight(v, ch, n)
	local s = tostring(v)
	return s .. string.rep(ch, math.max(0, n - #s))
end
local ROBLOX_GLOBALS = {
	"game",
	"workspace",
	"script",
	"plugin",
	"settings",
	"shared",
	"UserSettings",
	"print",
	"warn",
	"error",
	"assert",
	"pcall",
	"xpcall",
	"require",
	"select",
	"pairs",
	"ipairs",
	"next",
	"unpack",
	"type",
	"typeof",
	"tostring",
	"tonumber",
	"setmetatable",
	"getmetatable",
	"rawset",
	"rawget",
	"rawequal",
	"rawlen",
	"math",
	"table",
	"string",
	"bit32",
	"coroutine",
	"os",
	"utf8",
	"task",
	"buffer",
	"Instance",
	"Enum",
	"Vector3",
	"Vector2",
	"CFrame",
	"Color3",
	"BrickColor",
	"UDim",
	"UDim2",
	"Ray",
	"Axes",
	"Faces",
	"NumberRange",
	"NumberSequence",
	"ColorSequence",
	"TweenInfo",
	"RaycastParams",
	"OverlapParams",
	"tick",
	"time",
	"wait",
	"delay",
	"spawn",
	"_G",
	"_VERSION",
}
local function isGlobal(key)
	for _, v in ipairs(ROBLOX_GLOBALS) do
		if v == key then
			return true
		end
	end
	return false
end
local function Decompile(bytecode, options)
	local bytecodeVersion, typeEncodingVersion
	Reader_Set(options.ReaderFloatPrecision)
	local reader = Reader.new(bytecode)
	local function disassemble()
		if bytecodeVersion >= 4 then
			typeEncodingVersion = reader:nextByte()
		end
		local stringTable = {}
		local function readStringTable()
			local n = reader:nextVarInt()
			for i = 1, n do
				stringTable[i] = reader:nextString()
			end
		end
		local userdataTypes = {}
		local function readUserdataTypes()
			while true do
				local idx = reader:nextByte()
				if idx == 0 then
					break
				end
				userdataTypes[idx] = reader:nextVarInt()
			end
		end
		local protoTable = {}
		local function readProtoTable()
			local n = reader:nextVarInt()
			for i = 1, n do
				local protoId = i - 1
				local proto = {
					id = protoId,
					instructions = {},
					constants = {},
					captures = {},
					innerProtos = {},
					instructionLineInfo = {},
				}
				protoTable[protoId] = proto
				proto.maxStackSize = reader:nextByte()
				proto.numParams = reader:nextByte()
				proto.numUpvalues = reader:nextByte()
				proto.isVarArg = toBoolean(reader:nextByte())
				if bytecodeVersion >= 4 then
					proto.flags = reader:nextByte()
					local resultTypedParams, resultTypedUpvalues, resultTypedLocals = {}, {}, {}
					local allTypeInfoSize = reader:nextVarInt()
					local hasTypeInfo = allTypeInfoSize > 0
					proto.hasTypeInfo = hasTypeInfo
					if hasTypeInfo then
						local totalTypedParams = allTypeInfoSize
						local totalTypedUpvalues = 0
						local totalTypedLocals = 0
						if typeEncodingVersion and typeEncodingVersion > 1 then
							totalTypedParams = reader:nextVarInt()
							totalTypedUpvalues = reader:nextVarInt()
							totalTypedLocals = reader:nextVarInt()
						end
						if totalTypedParams > 0 then
							resultTypedParams = reader:nextBytes(totalTypedParams)
							table.remove(resultTypedParams, 1)
							table.remove(resultTypedParams, 1)
						end
						for j = 1, totalTypedUpvalues do
							resultTypedUpvalues[j] = { type = reader:nextByte() }
						end
						for j = 1, totalTypedLocals do
							local lt = reader:nextByte()
							local lr = reader:nextByte()
							local lsp = reader:nextVarInt() + 1
							local lep = reader:nextVarInt() + lsp - 1
							resultTypedLocals[j] = { type = lt, register = lr, startPC = lsp }
						end
					end
					proto.typedParams = resultTypedParams
					proto.typedUpvalues = resultTypedUpvalues
					proto.typedLocals = resultTypedLocals
				end
				proto.sizeInstructions = reader:nextVarInt()
				for j = 1, proto.sizeInstructions do
					proto.instructions[j] = reader:nextUInt32()
				end
				proto.sizeConstants = reader:nextVarInt()
				for j = 1, proto.sizeConstants do
					local constType = reader:nextByte()
					local constValue
					local BT = LuauBytecodeTag
					if constType == BT.LBC_CONSTANT_BOOLEAN then
						constValue = toBoolean(reader:nextByte())
					elseif constType == BT.LBC_CONSTANT_NUMBER then
						constValue = reader:nextDouble()
					elseif constType == BT.LBC_CONSTANT_STRING then
						constValue = stringTable[reader:nextVarInt()]
					elseif constType == BT.LBC_CONSTANT_IMPORT then
						local id = reader:nextUInt32()
						local idxCount = bshr(id, 30)
						local ci1 = band(bshr(id, 20), 0x3FF)
						local ci2 = band(bshr(id, 10), 0x3FF)
						local ci3 = band(id, 0x3FF)
						local tag = ""
						local function kv(idx)
							return proto.constants[idx + 1]
						end
						if idxCount == 1 then
							tag = tostring(kv(ci1) and kv(ci1).value or "")
						elseif idxCount == 2 then
							tag = tostring(kv(ci1) and kv(ci1).value or "")
								.. ".."
								.. tostring(kv(ci2) and kv(ci2).value or "")
						elseif idxCount == 3 then
							tag = tostring(kv(ci1) and kv(ci1).value or "")
								.. "."
								.. tostring(kv(ci2) and kv(ci2).value or "")
								.. "."
								.. tostring(kv(ci3) and kv(ci3).value or "")
						end
						constValue = tag
					elseif constType == BT.LBC_CONSTANT_TABLE then
						local sz = reader:nextVarInt()
						local keys = {}
						for k = 1, sz do
							keys[k] = reader:nextVarInt() + 1
						end
						constValue = { size = sz, keys = keys }
					elseif constType == BT.LBC_CONSTANT_CLOSURE then
						constValue = reader:nextVarInt() + 1
					elseif constType == BT.LBC_CONSTANT_VECTOR then
						local x, y, z, w =
							reader:nextFloat(), reader:nextFloat(), reader:nextFloat(), reader:nextFloat()
						constValue = w == 0 and ("Vector3.new(" .. x .. "," .. y .. "," .. z .. ")")
							or ("vector.create(" .. x .. "," .. y .. "," .. z .. "," .. w .. ")")
					end
					proto.constants[j] = { type = constType, value = constValue }
				end
				proto.sizeInnerProtos = reader:nextVarInt()
				for j = 1, proto.sizeInnerProtos do
					proto.innerProtos[j] = protoTable[reader:nextVarInt()]
				end
				proto.lineDefined = reader:nextVarInt()
				local nameId = reader:nextVarInt()
				proto.name = stringTable[nameId]
				local hasLineInfo = toBoolean(reader:nextByte())
				proto.hasLineInfo = hasLineInfo
				if hasLineInfo then
					local lgap = reader:nextByte()
					local baselineSize = bshr(proto.sizeInstructions - 1, lgap) + 1
					local smallLineInfo, absLineInfo = {}, {}
					local lastOffset, lastLine = 0, 0
					for j = 1, proto.sizeInstructions do
						local b = reader:nextSignedByte()
						lastOffset = lastOffset + b
						smallLineInfo[j] = lastOffset
					end
					for j = 1, baselineSize do
						local lc = lastLine + reader:nextInt32()
						absLineInfo[j - 1] = lc
						lastLine = lc
					end
					local resultLineInfo = {}
					for j, line in ipairs(smallLineInfo) do
						local absIdx = bshr(j - 1, lgap)
						local absLine = absLineInfo[absIdx]
						local rl = line + absLine
						if lgap <= 1 and (-line == absLine) then
							rl = rl + (absLineInfo[absIdx + 1] or 0)
						end
						if rl <= 0 then
							rl = rl + 0x100
						end
						resultLineInfo[j] = rl
					end
					proto.lineInfoSize = lgap
					proto.instructionLineInfo = resultLineInfo
				end
				local hasDebugInfo = toBoolean(reader:nextByte())
				proto.hasDebugInfo = hasDebugInfo
				if hasDebugInfo then
					local totalLocals = reader:nextVarInt()
					local debugLocals = {}
					for j = 1, totalLocals do
						debugLocals[j] = {
							name = stringTable[reader:nextVarInt()],
							startPC = reader:nextVarInt(),
							endPC = reader:nextVarInt(),
							register = reader:nextByte(),
						}
					end
					proto.debugLocals = debugLocals
					local totalUpvals = reader:nextVarInt()
					local debugUpvalues = {}
					for j = 1, totalUpvals do
						debugUpvalues[j] = { name = stringTable[reader:nextVarInt()] }
					end
					proto.debugUpvalues = debugUpvalues
				end
			end
		end
		readStringTable()
		if bytecodeVersion and bytecodeVersion > 5 then
			readUserdataTypes()
		end
		readProtoTable()
		local mainProtoId = reader:nextVarInt()
		return mainProtoId, protoTable
	end
	local function organize()
		local mainProtoId, protoTable = disassemble()
		local mainProto = protoTable[mainProtoId]
		mainProto.main = true
		local registerActions = {}
		local function baseProto(proto)
			local protoRegisterActions = {}
			registerActions[proto.id] = { proto = proto, actions = protoRegisterActions }
			local instructions = proto.instructions
			local innerProtos = proto.innerProtos
			local constants = proto.constants
			local captures = proto.captures
			local flags = proto.flags
			local function collectCaptures(baseIdx, p)
				local nup = p.numUpvalues
				if nup > 0 then
					local _c = p.captures
					for j = 1, nup do
						local cap = instructions[baseIdx + j]
						local ctype = Luau:INSN_A(cap)
						local sreg = Luau:INSN_B(cap)
						if ctype == LuauCaptureType.LCT_VAL or ctype == LuauCaptureType.LCT_REF then
							_c[j - 1] = sreg
						elseif ctype == LuauCaptureType.LCT_UPVAL then
							_c[j - 1] = captures[sreg]
						end
					end
				end
			end
			local function writeFlags()
				if type(flags) == "table" then
					return
				end
				local rawFlags = type(flags) == "number" and flags or 0
				local df = {}
				if proto.main then
					df.native = toBoolean(band(rawFlags, LuauProtoFlag.LPF_NATIVE_MODULE))
				else
					df.native = toBoolean(band(rawFlags, LuauProtoFlag.LPF_NATIVE_FUNCTION))
					df.cold = toBoolean(band(rawFlags, LuauProtoFlag.LPF_NATIVE_COLD))
				end
				flags = df
				proto.flags = df
			end
			local function writeInstructions()
				local auxSkip = false
				local function reg(act, regs, extra, hide)
					table.insert(protoRegisterActions, {
						usedRegisters = regs or {},
						extraData = extra,
						opCode = act,
						hide = hide,
					})
				end
				for idx, instruction in ipairs(instructions) do
					repeat
						if auxSkip then
							auxSkip = false
							break
						end
						local oci = LuauOpCode[Luau:INSN_OP(instruction)]
						if not oci then
							break
						end
						-- FASTCALL3 was added in Luau bytecode version 6.
						-- On v5 bytecode the same encoded slot is unused/reserved,
						-- so silently hide it rather than emitting garbage output.
						if oci.name == "FASTCALL3" and bytecodeVersion and bytecodeVersion < 6 then
							if oci.aux then
								auxSkip = true
								reg(oci, nil, nil, true)
							end
							reg(oci, nil, nil, true)
							break
						end
						local opn = oci.name
						local opt = oci.type
						local isAux = oci.aux == true
						local A, B, C, sD, D, E, aux
						if opt == "A" then
							A = Luau:INSN_A(instruction)
						elseif opt == "E" then
							E = Luau:INSN_E(instruction)
						elseif opt == "AB" then
							A = Luau:INSN_A(instruction)
							B = Luau:INSN_B(instruction)
						elseif opt == "AC" then
							A = Luau:INSN_A(instruction)
							C = Luau:INSN_C(instruction)
						elseif opt == "ABC" then
							A = Luau:INSN_A(instruction)
							B = Luau:INSN_B(instruction)
							C = Luau:INSN_C(instruction)
						elseif opt == "AD" then
							A = Luau:INSN_A(instruction)
							D = Luau:INSN_D(instruction)
						elseif opt == "AsD" then
							A = Luau:INSN_A(instruction)
							sD = Luau:INSN_sD(instruction)
						elseif opt == "sD" then
							sD = Luau:INSN_sD(instruction)
						end
						if isAux then
							auxSkip = true
							reg(oci, nil, nil, true)
							aux = instructions[idx + 1]
						end
						local st = not options.ShowTrivialOperations
						if opn == "NOP" or opn == "BREAK" or opn == "NATIVECALL" then
							reg(oci, nil, nil, st)
						elseif opn == "LOADNIL" then
							reg(oci, { A })
						elseif opn == "LOADB" then
							reg(oci, { A }, { B, C })
						elseif opn == "LOADN" then
							reg(oci, { A }, { sD })
						elseif opn == "LOADK" then
							reg(oci, { A }, { D })
						elseif opn == "MOVE" then
							reg(oci, { A, B })
						elseif opn == "GETGLOBAL" or opn == "SETGLOBAL" then
							reg(oci, { A }, { aux })
						elseif opn == "GETUPVAL" or opn == "SETUPVAL" then
							reg(oci, { A }, { B })
						elseif opn == "CLOSEUPVALS" then
							reg(oci, { A }, nil, st)
						elseif opn == "GETIMPORT" then
							reg(oci, { A }, { D, aux })
						elseif opn == "GETTABLE" or opn == "SETTABLE" then
							reg(oci, { A, B, C })
						elseif opn == "GETTABLEKS" or opn == "SETTABLEKS" then
							reg(oci, { A, B }, { C, aux })
						elseif opn == "GETTABLEN" or opn == "SETTABLEN" then
							reg(oci, { A, B }, { C })
						elseif opn == "NEWCLOSURE" then
							reg(oci, { A }, { D })
							local p2 = innerProtos[D + 1]
							if p2 then
								collectCaptures(idx, p2)
								baseProto(p2)
							end
						elseif opn == "DUPCLOSURE" then
							reg(oci, { A }, { D })
							local c = constants[D + 1]
							if c then
								local p2 = protoTable[c.value - 1]
								if p2 then
									collectCaptures(idx, p2)
									baseProto(p2)
								end
							end
						elseif opn == "NAMECALL" then
							reg(oci, { A, B }, { C, aux }, st)
						elseif opn == "CALL" then
							reg(oci, { A }, { B, C })
						elseif opn == "RETURN" then
							reg(oci, { A }, { B })
						elseif opn == "JUMP" or opn == "JUMPBACK" then
							reg(oci, {}, { sD })
						elseif opn == "JUMPIF" or opn == "JUMPIFNOT" then
							reg(oci, { A }, { sD })
						elseif
							opn == "JUMPIFEQ"
							or opn == "JUMPIFLE"
							or opn == "JUMPIFLT"
							or opn == "JUMPIFNOTEQ"
							or opn == "JUMPIFNOTLE"
							or opn == "JUMPIFNOTLT"
						then
							reg(oci, { A, aux }, { sD })
						elseif
							opn == "ADD"
							or opn == "SUB"
							or opn == "MUL"
							or opn == "DIV"
							or opn == "MOD"
							or opn == "POW"
						then
							reg(oci, { A, B, C })
						elseif
							opn == "ADDK"
							or opn == "SUBK"
							or opn == "MULK"
							or opn == "DIVK"
							or opn == "MODK"
							or opn == "POWK"
						then
							reg(oci, { A, B }, { C })
						elseif opn == "AND" or opn == "OR" then
							reg(oci, { A, B, C })
						elseif opn == "ANDK" or opn == "ORK" then
							reg(oci, { A, B }, { C })
						elseif opn == "CONCAT" then
							local regs = { A }
							for r = B, C do
								table.insert(regs, r)
							end
							reg(oci, regs)
						elseif opn == "NOT" or opn == "MINUS" or opn == "LENGTH" then
							reg(oci, { A, B })
						elseif opn == "NEWTABLE" then
							reg(oci, { A }, { B, aux })
						elseif opn == "DUPTABLE" then
							reg(oci, { A }, { D })
						elseif opn == "SETLIST" then
							if C ~= 0 then
								local regs = { A, B }
								for k = 1, C - 2 do
									table.insert(regs, A + k)
								end
								reg(oci, regs, { aux, C })
							else
								reg(oci, { A, B }, { aux, C })
							end
						elseif opn == "FORNPREP" then
							reg(oci, { A, A + 1, A + 2 }, { sD })
						elseif opn == "FORNLOOP" then
							reg(oci, { A }, { sD })
						elseif opn == "FORGLOOP" then
							local nv = band(aux or 0, 0xFF)
							local regs = {}
							for k = 1, nv do
								table.insert(regs, A + k)
							end
							reg(oci, regs, { sD, aux })
						elseif opn == "FORGPREP_INEXT" or opn == "FORGPREP_NEXT" then
							reg(oci, { A, A + 1 })
						elseif opn == "FORGPREP" then
							reg(oci, { A }, { sD })
						elseif opn == "GETVARARGS" then
							if B ~= 0 then
								local regs = { A }
								for k = 0, B - 1 do
									table.insert(regs, A + k)
								end
								reg(oci, regs, { B })
							else
								reg(oci, { A }, { B })
							end
						elseif opn == "PREPVARARGS" then
							reg(oci, {}, { A }, st)
						elseif opn == "LOADKX" then
							reg(oci, { A }, { aux })
						elseif opn == "JUMPX" then
							reg(oci, {}, { E })
						elseif opn == "COVERAGE" then
							reg(oci, {}, { E }, st)
						elseif
							opn == "JUMPXEQKNIL"
							or opn == "JUMPXEQKB"
							or opn == "JUMPXEQKN"
							or opn == "JUMPXEQKS"
						then
							reg(oci, { A }, { sD, aux })
						elseif opn == "CAPTURE" then
							reg(oci, nil, nil, st)
						elseif opn == "SUBRK" or opn == "DIVRK" then
							reg(oci, { A, C }, { B })
						elseif opn == "IDIV" then
							reg(oci, { A, B, C })
						elseif opn == "IDIVK" then
							reg(oci, { A, B }, { C })
						elseif opn == "FASTCALL" then
							reg(oci, {}, { A, C }, st)
						elseif opn == "FASTCALL1" then
							reg(oci, { B }, { A, C }, st)
						elseif opn == "FASTCALL2" then
							local r2 = band(aux or 0, 0xFF)
							reg(oci, { B, r2 }, { A, C }, st)
						elseif opn == "FASTCALL2K" then
							reg(oci, { B }, { A, C, aux }, st)
						elseif opn == "FASTCALL3" then
							local r2 = band(aux or 0, 0xFF)
							local r3 = bshr(r2, 8)
							reg(oci, { B, r2, r3 }, { A, C }, st)
						end
					until true
				end
			end
			writeFlags()
			writeInstructions()
		end
		baseProto(mainProto)
		return mainProtoId, registerActions, protoTable
	end
	local function finalize(mainProtoId, registerActions, protoTable)
		local finalResult = ""
		local totalParameters = 0
		local usedGlobals = {}
		local usedGlobalsSet = {}
		local function isValidGlobal(key)
			if usedGlobalsSet[key] then
				return false
			end
			return not isGlobal(key)
		end
		local function processResult(res)
			local embed = ""
			if options.ListUsedGlobals and #usedGlobals > 0 then
				embed = string.format(Strings.USED_GLOBALS, table.concat(usedGlobals, ", "))
			end
			return embed .. res
		end
		if options.DecompilerMode == "disasm" then
			local resultParts = {}
			local function emit(s)
				resultParts[#resultParts + 1] = s
			end
			local function writeActions(protoActions)
				local actions = protoActions.actions
				local proto = protoActions.proto
				local lineInfo = proto.instructionLineInfo
				local inner = proto.innerProtos
				local consts = proto.constants
				local caps = proto.captures
				local pflags = proto.flags
				local numParams = proto.numParams
				local jumpMarkers = {}
				local function makeJump(idx)
					idx = idx - 1
					jumpMarkers[idx] = (jumpMarkers[idx] or 0) + 1
				end
				totalParameters = totalParameters + numParams
				if proto.main and pflags and pflags.native then
					emit("--!native\n")
				end
				local function buildRegNames(instrIdx)
					local names = {}
					if proto.debugLocals then
						for _, dl in ipairs(proto.debugLocals) do
							if instrIdx >= dl.startPC and instrIdx <= dl.endPC then
								names[dl.register] = dl.name
							end
						end
					end
					return names
				end
				local function fmtUpv(r)
					if r == nil then
						return "upv_unknown"
					end
					local du = proto.debugUpvalues
					if du then
						local entry = du[r + 1]
						if entry and entry.name and entry.name ~= "" then
							return entry.name
						end
					end
					local capturedReg = caps[r]
					if capturedReg ~= nil and proto.debugLocals then
						for _, dl in ipairs(proto.debugLocals) do
							if dl.register == capturedReg and dl.name and dl.name ~= "" then
								return dl.name
							end
						end
					end
					return "upv_" .. tostring(r)
				end
				local regNameCache = {}
				-- regCalleeMap[r] = global/import name staged into r by GETGLOBAL/GETIMPORT.
				-- Read only by the CALL handler to recover the callee name when the staging
				-- instruction was suppressed.  Never touched by fmtReg.
				local regCalleeMap = {}

				local function fmtReg(r, instrIdx)
					-- 1. Debug local name live at this instruction
					if instrIdx and proto.debugLocals then
						local cached = regNameCache[instrIdx]
						if not cached then
							cached = buildRegNames(instrIdx)
							regNameCache[instrIdx] = cached
						end
						if cached[r] and cached[r] ~= "" then
							return cached[r]
						end
					end
					-- 2. Parameter slot — fall back to pN, never use debug locals here
					--    (debug locals at startPC==0 often carry the *global* name that was
					--     assigned to that param slot, which is wrong for display)
					local pr = r + 1
					if pr <= numParams then
						return "p" .. ((totalParameters - numParams) + pr)
					end
					-- 3. Plain register name
					return "v" .. (r - numParams)
				end

				local function paramName(j)
					-- j is 1-based; use the same pN scheme as fmtReg for consistency
					local r = j - 1
					local pr = r + 1
					return "p" .. ((totalParameters - numParams) + pr)
				end

				-- Returns true only when the very next visible instruction is a CALL
				-- whose base register equals regIdx.  Strict: any other visible op first
				-- means the register has another use and must not be suppressed.
				local function isDirectCallBase(regIdx, fromIdx)
					for k = fromIdx + 1, #actions do
						local a = actions[k]
						if a and not a.hide and a.opCode then
							local nop = a.opCode.name
							return nop == "CALL" and a.usedRegisters and a.usedRegisters[1] == regIdx
						end
					end
					return false
				end
				local function fmtConst(k)
					if not k then
						return "nil"
					end
					if k.type == LuauBytecodeTag.LBC_CONSTANT_VECTOR then
						return tostring(k.value)
					end
					if type(tonumber(k.value)) == "number" then
						return tostring(tonumber(string.format("%0." .. options.ReaderFloatPrecision .. "f", k.value)))
					end
					local s = toEscapedString(k.value)
					if k.type == LuauBytecodeTag.LBC_CONSTANT_IMPORT then
						s = s:gsub("%.%.+", "."):gsub("^%.", ""):gsub("%.$", "")
					end
					return s
				end
				local function fmtProto(p)
					local body = ""
					if p.flags and p.flags.native then
						if p.flags.cold and options.EnabledRemarks and options.EnabledRemarks.ColdRemark then
							body = body
								.. string.format(
									Strings.DECOMPILER_REMARK,
									"This function is marked cold and is not compiled natively"
								)
						end
						body = body .. "@native "
					end
					if p.name then
						body = "local function " .. p.name
					else
						body = "function"
					end
					body = body .. "("
					for j = 1, p.numParams do
						local pb = paramName(j)
						if p.hasTypeInfo and options.UseTypeInfo and p.typedParams and p.typedParams[j] then
							pb = pb .. ": " .. Luau:GetBaseTypeString(p.typedParams[j], true)
						end
						if j ~= p.numParams then
							pb = pb .. ", "
						end
						body = body .. pb
					end
					if p.isVarArg then
						body = body .. ((p.numParams > 0) and ", ..." or "...")
					end
					body = body .. ")\n"
					if options.ShowDebugInformation then
						body = body .. "-- proto pool id: " .. p.id .. "\n"
						body = body .. "-- num upvalues: " .. p.numUpvalues .. "\n"
						body = body .. "-- num inner protos: " .. (p.sizeInnerProtos or 0) .. "\n"
						body = body .. "-- size instructions: " .. (p.sizeInstructions or 0) .. "\n"
						body = body .. "-- size constants: " .. (p.sizeConstants or 0) .. "\n"
						body = body .. "-- lineinfo gap: " .. (p.lineInfoSize or "n/a") .. "\n"
						body = body .. "-- max stack size: " .. p.maxStackSize .. "\n"
						body = body .. "-- is typed: " .. tostring(p.hasTypeInfo) .. "\n"
					end
					return body
				end
				local function writeProto(reg, p)
					local body = fmtProto(p)
					if p.name then
						emit("\n" .. body)
						writeActions(registerActions[p.id])
						if not options.CleanMode then
							emit("end\n" .. fmtReg(reg) .. " = " .. p.name)
						else
							emit("end")
						end
					else
						emit(fmtReg(reg) .. " = " .. body)
						writeActions(registerActions[p.id])
						emit("end")
					end
				end
				local CLEAN_SUPPRESS = {
					CLOSEUPVALS = true,
					PREPVARARGS = true,
					COVERAGE = true,
					CAPTURE = true,
					FASTCALL = true,
					FASTCALL1 = true,
					FASTCALL2 = true,
					FASTCALL2K = true,
					FASTCALL3 = true,
					JUMPX = true,
					NOP = true,
					JUMPBACK = true,
				}
				for i, action in ipairs(actions) do
					repeat
						if action.hide then
							break
						end
						local ur = action.usedRegisters
						local ed = action.extraData
						local oci = action.opCode
						if not oci then
							break
						end
						local opn = oci.name
						if options.CleanMode and CLEAN_SUPPRESS[opn] then
							break
						end
						if options.CleanMode and opn == "RETURN" then
							local b = ed and ed[1] or 0
							if b == 1 then
								break
							end
						end
						if
							options.CleanMode
							and opn == "MOVE"
							and i > 1
							and actions[i - 1]
							and (
								actions[i - 1].opCode.name == "NEWCLOSURE"
								or actions[i - 1].opCode.name == "DUPCLOSURE"
							)
						then
							break
						end
						local function R(r)
							return fmtReg(r, i)
						end
						local function handleJumps()
							local n = jumpMarkers[i]
							if n then
								jumpMarkers[i] = nil
								for _ = 1, n do
									emit("end\n")
								end
							end
						end
						if not options.CleanMode then
							if options.ShowOperationIndex then
								emit("[" .. padLeft(i, "0", 3) .. "] ")
							end
							if options.ShowInstructionLines and lineInfo and lineInfo[i] then
								emit(":" .. padLeft(lineInfo[i], "0", 3) .. ":")
							end
							if options.ShowOperationNames then
								emit(padRight(opn, " ", 15))
							end
						end
						if opn == "LOADNIL" then
							regCalleeMap[ur[1]] = nil
							emit(R(ur[1]) .. " = nil")
						elseif opn == "LOADB" then
							-- FIX2: Ternary-aware LOADB — no more 'false + 1' artifact
							local _lbVal = toBoolean(ed[1])
							local _lbSkip = ed[2]
							local _lbNext = actions[i + 1]
							regCalleeMap[ur[1]] = nil
							if _lbSkip > 0 then
								if _lbNext and _lbNext.opCode and _lbNext.opCode.name == "LOADB" then
									emit(R(ur[1]) .. " = " .. tostring(_lbVal) .. " -- [Ternary Branch]")
								else
									emit(R(ur[1]) .. " = " .. tostring(_lbVal) .. " -- skips " .. _lbSkip)
								end
							else
								emit(R(ur[1]) .. " = " .. tostring(_lbVal))
							end
						elseif opn == "LOADN" then
							regCalleeMap[ur[1]] = nil
							emit(R(ur[1]) .. " = " .. ed[1])
						elseif opn == "LOADK" then
							regCalleeMap[ur[1]] = nil
							emit(R(ur[1]) .. " = " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "MOVE" then
							-- Propagate callee map entry in case a global was MOVEd before being called
							regCalleeMap[ur[1]] = regCalleeMap[ur[2]]
							emit(R(ur[1]) .. " = " .. R(ur[2]))
						elseif opn == "GETGLOBAL" then
							local gk = tostring(consts[ed[1] + 1] and consts[ed[1] + 1].value or "")
							-- Fallback: if constant lookup failed, use register debug name or placeholder
							if gk == "" then
								local dbg = proto.debugLocals and buildRegNames(i) or {}
								gk = (dbg[ur[1]] and dbg[ur[1]] ~= "") and dbg[ur[1]] or "_global_?"
							end
							if options.ListUsedGlobals and isValidGlobal(gk) then
								table.insert(usedGlobals, gk)
								usedGlobalsSet[gk] = true
							end
							regCalleeMap[ur[1]] = gk
							emit(R(ur[1]) .. " = " .. gk)
						elseif opn == "SETGLOBAL" then
							local gk = tostring(consts[ed[1] + 1] and consts[ed[1] + 1].value or "")
							if options.ListUsedGlobals and isValidGlobal(gk) then
								table.insert(usedGlobals, gk)
								usedGlobalsSet[gk] = true
							end
							emit(gk .. " = " .. R(ur[1]))
						elseif opn == "GETUPVAL" then
							emit(R(ur[1]) .. " = " .. fmtUpv(caps[ed[1]]))
						elseif opn == "SETUPVAL" then
							emit(fmtUpv(caps[ed[1]]) .. " = " .. R(ur[1]))
						elseif opn == "CLOSEUPVALS" then
							emit("-- clear captures from back until: " .. ur[1])
						elseif opn == "GETIMPORT" then
							-- FIX2: Roblox service/DataModel naming with workspace alias
							local imp = tostring(consts[ed[1] + 1] and consts[ed[1] + 1].value or "")
							imp = imp:gsub("%.%.+", "."):gsub("^%.", ""):gsub("%.$", "")
							-- Fallback: if consts lookup gave "", decode path directly from the AUX import ID
							if imp == "" and ed[2] then
								local importId = ed[2]
								local idxCount = bshr(importId, 30)
								local ci1 = band(bshr(importId, 20), 0x3FF)
								local ci2 = band(bshr(importId, 10), 0x3FF)
								local ci3 = band(importId, 0x3FF)
								local function kv2(idx)
									local c = consts[idx + 1]
									return (c and c.value ~= nil) and tostring(c.value) or "?"
								end
								if idxCount == 1 then
									imp = kv2(ci1)
								elseif idxCount == 2 then
									imp = kv2(ci1) .. "." .. kv2(ci2)
								elseif idxCount == 3 then
									imp = kv2(ci1) .. "." .. kv2(ci2) .. "." .. kv2(ci3)
								else
									imp = "_import_?"
								end
							end
							imp = imp:gsub("%.%.+", "."):gsub("^%.", ""):gsub("%.$", "")
							local totalIdx = bshr(ed[2] or 0, 30)
							if totalIdx == 1 and options.ListUsedGlobals and isValidGlobal(imp) then
								table.insert(usedGlobals, imp)
								usedGlobalsSet[imp] = true
							end
							local _knownSvcs = {
								Players = true,
								ReplicatedStorage = true,
								RunService = true,
								UserInputService = true,
								HttpService = true,
								ServerStorage = true,
								ServerScriptService = true,
								StarterGui = true,
								StarterPack = true,
								StarterPlayer = true,
								Lighting = true,
								TweenService = true,
								CollectionService = true,
								ContentProvider = true,
								MarketplaceService = true,
								SoundService = true,
								PathfindingService = true,
							}
							local impStr
							if imp == "Workspace" or imp == "workspace" then
								impStr = "workspace"
							elseif totalIdx == 1 and _knownSvcs[imp] then
								impStr = 'game:GetService("' .. imp .. '")'
							else
								impStr = imp
							end
							regCalleeMap[ur[1]] = impStr
							emit(R(ur[1]) .. " = " .. impStr)
						elseif opn == "GETTABLE" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. "[" .. R(ur[3]) .. "]")
						elseif opn == "SETTABLE" then
							emit(R(ur[2]) .. "[" .. R(ur[3]) .. "] = " .. R(ur[1]))
						elseif opn == "GETTABLEKS" then
							local key = consts[ed[2] + 1] and consts[ed[2] + 1].value
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. formatIndexString(key))
						elseif opn == "SETTABLEKS" then
							local key = consts[ed[2] + 1] and consts[ed[2] + 1].value
							emit(R(ur[2]) .. formatIndexString(key) .. " = " .. R(ur[1]))
						elseif opn == "GETTABLEN" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. "[" .. (ed[1] + 1) .. "]")
						elseif opn == "SETTABLEN" then
							emit(R(ur[2]) .. "[" .. (ed[1] + 1) .. "] = " .. R(ur[1]))
						elseif opn == "NEWCLOSURE" then
							local p2 = inner[ed[1] + 1]
							if p2 then
								writeProto(ur[1], p2)
							end
						elseif opn == "DUPCLOSURE" then
							local c = consts[ed[1] + 1]
							if c then
								local p2 = protoTable[c.value - 1]
								if p2 then
									writeProto(ur[1], p2)
								end
							end
						elseif opn == "NAMECALL" then
							local method = tostring(consts[ed[2] + 1] and consts[ed[2] + 1].value or "")
							emit("-- :" .. method)
						elseif opn == "CALL" then
							local baseR = ur[1]
							local nArgs = ed[1] - 1
							local nRes = ed[2] - 1
							local nmMethod = ""
							local argOff = 0
							local prev = actions[i - 1]
							if prev and prev.opCode and prev.opCode.name == "NAMECALL" then
								nmMethod = ":"
									.. tostring(
										consts[prev.extraData[2] + 1] and consts[prev.extraData[2] + 1].value or ""
									)
								nArgs = nArgs - 1
								argOff = argOff + 1
							end
							-- Recover callee name from suppressed GETGLOBAL/GETIMPORT if available
							local _cm = regCalleeMap[baseR]
							local callee = (_cm and _cm ~= "") and _cm or R(baseR)
							regCalleeMap[baseR] = nil
							-- Build result LHS: results land in baseR..baseR+nRes-1
							local callBody = ""
							if nRes == -1 then
								callBody = "... = "
							elseif nRes > 0 then
								local parts = {}
								for k = 0, nRes - 1 do
									parts[#parts + 1] = R(baseR + k)
								end
								callBody = table.concat(parts, ", ") .. " = "
							end
							-- Build call expression
							callBody = callBody .. callee .. nmMethod .. "("
							if nArgs == -1 then
								callBody = callBody .. "..."
							elseif nArgs > 0 then
								local parts = {}
								for k = 1, nArgs do
									parts[#parts + 1] = R(baseR + k + argOff)
								end
								callBody = callBody .. table.concat(parts, ", ")
							end
							callBody = callBody .. ")"
							emit(callBody)
						elseif opn == "RETURN" then
							local baseR = ur[1]
							local tot = ed[1] - 2
							local rb = ""
							if tot == -2 then
								rb = " " .. R(baseR) .. ", ..."
							elseif tot > -1 then
								rb = " "
								for k = 0, tot do
									rb = rb .. R(baseR + k)
									if k ~= tot then
										rb = rb .. ", "
									end
								end
							end
							emit("return" .. rb)
						elseif opn == "JUMP" then
							emit("-- jump to #" .. (i + ed[1]))
						elseif opn == "JUMPBACK" then
							emit("-- jump back to #" .. (i + ed[1] + 1))
						elseif opn == "JUMPIF" then
							-- FIX2: JUMPIF fires when condition is truthy, so we branch into the block on NOT condition
							local ei = i + ed[1]
							makeJump(ei)
							emit("if not " .. R(ur[1]) .. " then -- goto #" .. (ei + 1))
						elseif opn == "JUMPIFNOT" then
							-- FIX2: JUMPIFNOT fires when condition is falsy, so we branch into the block on condition
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " then -- goto #" .. (ei + 1))
						elseif opn == "JUMPIFEQ" then
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " == " .. R(ur[2]) .. " then -- goto #" .. ei)
						elseif opn == "JUMPIFLE" then
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " >= " .. R(ur[2]) .. " then -- goto #" .. ei)
						elseif opn == "JUMPIFLT" then
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " > " .. R(ur[2]) .. " then -- goto #" .. ei)
						elseif opn == "JUMPIFNOTEQ" then
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " ~= " .. R(ur[2]) .. " then -- goto #" .. ei)
						elseif opn == "JUMPIFNOTLE" then
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " <= " .. R(ur[2]) .. " then -- goto #" .. ei)
						elseif opn == "JUMPIFNOTLT" then
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " < " .. R(ur[2]) .. " then -- goto #" .. ei)
						elseif opn == "ADD" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " + " .. R(ur[3]))
						elseif opn == "SUB" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " - " .. R(ur[3]))
						elseif opn == "MUL" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " * " .. R(ur[3]))
						elseif opn == "DIV" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " / " .. R(ur[3]))
						elseif opn == "MOD" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " % " .. R(ur[3]))
						elseif opn == "POW" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " ^ " .. R(ur[3]))
						elseif opn == "ADDK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " + " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "SUBK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " - " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "MULK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " * " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "DIVK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " / " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "MODK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " % " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "POWK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " ^ " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "AND" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " and " .. R(ur[3]))
						elseif opn == "OR" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " or " .. R(ur[3]))
						elseif opn == "ANDK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " and " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "ORK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " or " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "CONCAT" then
							local tgt = table.remove(ur, 1)
							local cb = ""
							for k, r in ipairs(ur) do
								cb = cb .. fmtReg(r)
								if k ~= #ur then
									cb = cb .. " .. "
								end
							end
							emit(R(tgt) .. " = " .. cb)
						elseif opn == "NOT" then
							emit(R(ur[1]) .. " = not " .. R(ur[2]))
						elseif opn == "MINUS" then
							emit(R(ur[1]) .. " = -" .. R(ur[2]))
						elseif opn == "LENGTH" then
							emit(R(ur[1]) .. " = #" .. R(ur[2]))
						elseif opn == "NEWTABLE" then
    local arrayHint = ed and ed[2] or 0
    emit(R(ur[1]) .. " = " .. (arrayHint > 0 and "table.create(" .. arrayHint .. ")" or "{}"))
						elseif opn == "DUPTABLE" then
							local cv = consts[ed[1] + 1]
							if cv and type(cv.value) == "table" then
								local tb = "{"
								for k = 1, cv.value.size do
									tb = tb .. fmtConst(consts[cv.value.keys[k]])
									if k ~= cv.value.size then
										tb = tb .. ", "
									end
								end
								emit(R(ur[1]) .. " = {} -- " .. tb .. "}")
							else
								emit(R(ur[1]) .. " = {}")
							end
						elseif opn == "SETLIST" then
							local tgt = ur[1]
							local src = ur[2]
							local si = ed[1]
							local vc = ed[2]
							if vc == 0 then
								emit(R(tgt) .. "[" .. si .. "] = [...]")
							else
								local tot2 = #ur - 1
								local cb = ""
								for k = 1, tot2 do
									cb = cb .. R(ur[k]) .. "[" .. (si + k - 1) .. "] = " .. R(src + k - 1)
									if k ~= tot2 then
										cb = cb .. "\n"
									end
								end
								emit(cb)
							end
						elseif opn == "FORNPREP" then
							emit(
								"for "
									.. R(ur[3])
									.. " = "
									.. R(ur[3])
									.. ", "
									.. R(ur[1])
									.. ", "
									.. R(ur[2])
									.. " do -- end at #"
									.. (i + ed[1])
							)
						elseif opn == "FORNLOOP" then
							emit("end -- iterate + jump to #" .. (i + ed[1]))
						elseif opn == "FORGLOOP" then
							-- ed[2] is aux; low byte is the number of iteration variables
							local nv = band(ed[2] or 0, 0xFF)
							local baseR = ur[1] ~= nil and ur[1] or 0
							-- For clarity, list the iteration variables exactly like the disassembler:
							-- var(A+3), var(A+4), ... var(A+2+nv)
							local varList = {}
							for j = 1, nv do
								varList[j] = R(baseR + 2 + j)
							end
							local varStr = nv > 0 and (" -- vars: " .. table.concat(varList, ", ")) or ""
							emit("end -- iterate + jump to #" .. (i + ed[1]) .. varStr)
						elseif opn == "FORGPREP_INEXT" then
							local tr = ur[1] + 1
							emit("for " .. R(tr + 2) .. ", " .. R(tr + 3) .. " in ipairs(" .. R(tr) .. ") do")
						elseif opn == "FORGPREP_NEXT" then
							local tr = ur[1] + 1
							emit("for " .. R(tr + 2) .. ", " .. R(tr + 3) .. " in pairs(" .. R(tr) .. ") do")
						elseif opn == "FORGPREP" then
							local ei = i + ed[1] + 2
							local ea = actions[ei]
							local vb = ""
							if ea and ea.usedRegisters and #ea.usedRegisters > 0 then
								for k, r in ipairs(ea.usedRegisters) do
									vb = vb .. fmtReg(r, ei)
									if k ~= #ea.usedRegisters then
										vb = vb .. ", "
									end
								end
							else
								local baseReg = ur[1]
								local nVars = 2
								if ea and ea.extraData and ea.extraData[2] then
									nVars = math.max(1, band(ea.extraData[2], 0xFF))
								end
								local parts = {}
								for k = 1, nVars do
									parts[k] = fmtReg(baseReg + 2 + (k - 1), i)
								end
								vb = table.concat(parts, ", ")
							end
							emit("for " .. vb .. " in " .. R(ur[1]) .. " do -- end at #" .. ei)
						elseif opn == "GETVARARGS" then
							local vc2 = ed[1] - 1
							local rb = ""
							if vc2 == -1 then
								rb = R(ur[1])
							else
								for k = 1, vc2 do
									rb = rb .. R(ur[k])
									if k ~= vc2 then
										rb = rb .. ", "
									end
								end
							end
							emit(rb .. " = ...")
						elseif opn == "PREPVARARGS" then
							emit("-- ... ; number of fixed args: " .. ed[1])
						elseif opn == "LOADKX" then
							emit(R(ur[1]) .. " = " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "JUMPX" then
							emit("-- jump to #" .. (i + ed[1]))
						elseif opn == "COVERAGE" then
							emit("-- coverage (" .. ed[1] .. ")")
						elseif opn == "JUMPXEQKNIL" then
							local rev = bshr(ed[2] or 0, 0x1F) ~= 1
							local sign = rev and "~=" or "=="
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " " .. sign .. " nil then -- goto #" .. ei)
						elseif opn == "JUMPXEQKB" then
							local val = tostring(toBoolean(band(ed[2] or 0, 1)))
							local rev = bshr(ed[2] or 0, 0x1F) ~= 1
							local sign = rev and "~=" or "=="
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " " .. sign .. " " .. val .. " then -- goto #" .. ei)
						elseif opn == "JUMPXEQKN" or opn == "JUMPXEQKS" then
							local cidx = band(ed[2] or 0, 0xFFFFFF)
							local val = fmtConst(consts[cidx + 1])
							local rev = bshr(ed[2] or 0, 0x1F) ~= 1
							local sign = rev and "~=" or "=="
							local ei = i + ed[1]
							makeJump(ei)
							emit("if " .. R(ur[1]) .. " " .. sign .. " " .. val .. " then -- goto #" .. ei)
						elseif opn == "CAPTURE" then
							emit("-- upvalue capture")
						elseif opn == "SUBRK" then
							emit(R(ur[1]) .. " = " .. fmtConst(consts[ed[1] + 1]) .. " - " .. R(ur[2]))
						elseif opn == "DIVRK" then
							emit(R(ur[1]) .. " = " .. fmtConst(consts[ed[1] + 1]) .. " / " .. R(ur[2]))
						elseif opn == "IDIV" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " // " .. R(ur[3]))
						elseif opn == "IDIVK" then
							emit(R(ur[1]) .. " = " .. R(ur[2]) .. " // " .. fmtConst(consts[ed[1] + 1]))
						elseif opn == "FASTCALL" then
							emit("-- FASTCALL; " .. Luau:GetBuiltinInfo(ed[1]) .. "()")
						elseif opn == "FASTCALL1" then
							emit("-- FASTCALL1; " .. Luau:GetBuiltinInfo(ed[1]) .. "(" .. R(ur[1]) .. ")")
						elseif opn == "FASTCALL2" then
							emit(
								"-- FASTCALL2; "
									.. Luau:GetBuiltinInfo(ed[1])
									.. "("
									.. R(ur[1])
									.. ", "
									.. R(ur[2])
									.. ")"
							)
						elseif opn == "FASTCALL2K" then
							emit(
								"-- FASTCALL2K; "
									.. Luau:GetBuiltinInfo(ed[1])
									.. "("
									.. R(ur[1])
									.. ", "
									.. fmtConst(consts[(ed[3] or 0) + 1])
									.. ")"
							)
						elseif opn == "FASTCALL3" then
							emit(
								"-- FASTCALL3; "
									.. Luau:GetBuiltinInfo(ed[1])
									.. "("
									.. R(ur[1])
									.. ", "
									.. R(ur[2])
									.. ", "
									.. R(ur[3])
									.. ")"
							)
						end
						emit("\n")
						handleJumps()
					until true
				end
			end
			writeActions(registerActions[mainProtoId])
			finalResult = processResult(table.concat(resultParts))
		else
			finalResult = processResult("-- mode not supported")
		end
		return finalResult
	end
	local function manager(proceed, issue)
		if proceed then
			local startTime = os.clock()
			local ok, res = pcall(function()
				return finalize(organize())
			end)
			local result = ok and res or ("-- RUNTIME ERROR:\n-- " .. tostring(res))
			if (os.clock() - startTime) >= options.DecompilerTimeout then
				return Strings.TIMEOUT
			end
			return string.format(Strings.SUCCESS, result)
		else
			if issue == "COMPILATION_FAILURE" then
				local len = reader:len() - 1
				return string.format(Strings.COMPILATION_FAILURE, reader:nextString(len))
			elseif issue == "UNSUPPORTED_LBC_VERSION" then
				return Strings.UNSUPPORTED_LBC_VERSION
			end
		end
	end
	bytecodeVersion = reader:nextByte()
	if bytecodeVersion == 0 then
		return manager(false, "COMPILATION_FAILURE")
	elseif
		bytecodeVersion >= LuauBytecodeTag.LBC_VERSION_MIN and bytecodeVersion <= LuauBytecodeTag.LBC_VERSION_MAX
	then
		return manager(true)
	else
		return manager(false, "UNSUPPORTED_LBC_VERSION")
	end
end
local function prettyPrint(text)
	local result = {}
	local depth = 0
	local DEDENT_BEFORE = { ["end"] = true, ["until"] = true }
	local INDENT_AFTER = { ["then"] = true, ["do"] = true, ["repeat"] = true }
	local DEDENT_THEN_INDENT = { ["else"] = true, ["elseif"] = true }
	local function stripStrings(s)
		s = s:gsub('"[^"]*"', '""')
		s = s:gsub("'[^']*'", "''")
		s = s:gsub("%-%-.*$", "")
		return s
	end
	local function firstWord(s)
		return (stripStrings(s):match("^%s*([%a_][%w_]*)")) or ""
	end
	local function containsOpener(s)
		local clean = stripStrings(s)
		local fw = clean:match("^%s*([%a_][%w_]*)")
		if fw == "elseif" or fw == "else" then
			return false
		end
		for w in clean:gmatch("[%a_][%w_]*") do
			if INDENT_AFTER[w] then
				return true
			end
			if w == "function" then
				return true
			end
		end
		return false
	end
	for line in (text .. "\n"):gmatch("[^\n]*\n") do
		local bare = line:gsub("\n$", "")
		if bare == "" then
			result[#result + 1] = "\n"
		else
			local expr = bare:match("^%[%d+%]%s*:?%d*:?%s*%u[%u_]*%s+(.*)") or bare
			local kw = firstWord(expr)
			if DEDENT_THEN_INDENT[kw] then
				depth = math.max(0, depth - 1)
				result[#result + 1] = string.rep("    ", depth) .. bare .. "\n"
				depth = depth + 1
			elseif DEDENT_BEFORE[kw] then
				depth = math.max(0, depth - 1)
				result[#result + 1] = string.rep("    ", depth) .. bare .. "\n"
			else
				result[#result + 1] = string.rep("    ", depth) .. bare .. "\n"
				if containsOpener(expr) then
					depth = depth + 1
				end
			end
		end
	end
	return table.concat(result)
end
local function cleanOutput(text)
	local rawLines = {}
	for line in (text .. "\n"):gmatch("[^\n]*\n") do
		rawLines[#rawLines + 1] = line:gsub("\n$", "")
	end
	local function escpat(s)
		return s:gsub("([%(%)%.%%%+%-%*%?%[%^%$])", "%%%1")
	end
	local function nextNonBlank(start)
		local j = start
		while j <= #rawLines and (rawLines[j] == nil or rawLines[j]:match("^%s*$")) do
			j = j + 1
		end
		return j
	end
	local function tryCollapse(i)
		local line = rawLines[i]
		if line == nil then
			return false
		end
		local reg, lit = line:match('^%s*(v%d+) = (".-")%s*$')
		if not reg then
			reg, lit = line:match("^%s*(v%d+) = (%-?%d+%.?%d*)%s*$")
		end
		if not reg then
			reg, lit = line:match("^%s*(v%d+) = (true)%s*$")
		end
		if not reg then
			reg, lit = line:match("^%s*(v%d+) = (false)%s*$")
		end
		if not reg then
			reg, lit = line:match("^%s*(v%d+) = (nil)%s*$")
		end
		if not reg then
			reg, lit = line:match("^%s*(v%d+) = ([%a_][%w_%.]+)%s*$")
		end
		if not reg then
			return false
		end
		local ep = escpat(reg)
		-- Scan ahead up to 12 lines for the single use of this register.
		-- Stop early if any line writes to this register (that would be a re-def).
		local limit = math.min(#rawLines, i + 12)
		for j = i + 1, limit do
			local scanLine = rawLines[j]
			if scanLine == nil then -- already collapsed away, skip
			elseif scanLine:match("^%s*$") then -- blank, skip
			else
				-- If this line re-assigns the register, stop — can't fold past a write
				if scanLine:match("^%s*" .. ep .. "%s*=") then
					return false
				end
				local count = 0
				for _ in scanLine:gmatch(ep) do
					count = count + 1
				end
				if count == 1 then
					-- Found exactly one use — fold the literal in
					rawLines[j] = scanLine:gsub(ep, lit, 1)
					rawLines[i] = nil
					return true
				elseif count > 1 then
					-- Used more than once on this line — can't safely inline
					return false
				end
				-- count == 0: register not mentioned on this line, keep scanning
			end
		end
		return false
	end
	for _ = 1, 8 do
		for i = 1, #rawLines do
			tryCollapse(i)
		end
	end
	local function tryFoldField(i)
		local line = rawLines[i]
		if not line then
			return false
		end
		local lreg, src, field = line:match("^%s*(v%d+) = (v%d+)%.([%a_][%w_]*)%s*$")
		if not lreg then
			lreg, src, field = line:match("^%s*(v%d+) = (v%d+)%[(.-)%]%s*$")
			if lreg then
				field = "[" .. field .. "]"
			else
				return false
			end
		else
			field = "." .. field
		end
		local j = nextNonBlank(i + 1)
		if j > #rawLines then
			return false
		end
		local nextLine = rawLines[j]
		local epReg = escpat(lreg)
		local epSrc = escpat(src)
		local count = 0
		for _ in nextLine:gmatch(epReg) do
			count = count + 1
		end
		if count ~= 1 then
			return false
		end
		if nextLine:match("^%s*" .. epReg .. "%s*=") then
			return false
		end
		for k = i + 1, j - 1 do
			local midLine = rawLines[k]
			if midLine and midLine:match("^%s*" .. epSrc .. "%s*=") then
				return false
			end
		end
		if src:match("^upv_") then
			return false
		end
		rawLines[j] = nextLine:gsub(epReg, src .. field, 1)
		rawLines[i] = nil
		return true
	end
	for _ = 1, 6 do
		for i = 1, #rawLines do
			tryFoldField(i)
		end
	end
	local pass2 = {}
	for idx = 1, #rawLines do
		local line = rawLines[idx]
		if line ~= nil then
			local stripped = line:match("^%s*(.-)%s*$")
			if not stripped:match("^%-%- goto #%d+$") and not stripped:match("^%-%- jump") then
				line = line:gsub("%s*%-%- goto #%d+$", "")
				line = line:gsub("%s*%-%- end at #%d+$", "")
				line = line:gsub("%s*%-%- iterate %+ jump to #%d+$", "")
				pass2[#pass2 + 1] = line
			end
		end
	end
	local pass3 = {}
	local i = 1
	while i <= #pass2 do
		local line = pass2[i]
		local nxt = pass2[i + 1]
		local s = line and line:match("^%s*(.-)%s*$") or ""
		local isNilInit = s:match("^v%d+ = nil") ~= nil
		local nextIsFor = nxt and nxt:match("^%s*for%s+v%d+") ~= nil
		if isNilInit and nextIsFor then
			i = i + 1
		else
			pass3[#pass3 + 1] = line
			i = i + 1
		end
	end
	local seen = {}
	local pass4 = {}
	for _, line in ipairs(pass3) do
		local reg = line:match("^%s*(v%d+)%s*=")
		if reg and not seen[reg] then
			seen[reg] = true
			line = line:gsub("^(%s*)(v%d+%s*=)", "%1local %2", 1)
		end
		pass4[#pass4 + 1] = line
	end
	local final = {}
	local lastBlank = false
	for _, line in ipairs(pass4) do
		local isBlank = line:match("^%s*$") ~= nil
		if not (isBlank and lastBlank) then
			lastBlank = isBlank
			final[#final + 1] = line
		end
	end
	return table.concat(final, "\n")
end
local B64_ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B64_MAP = {}
for i = 1, #B64_ALPHA do
	B64_MAP[string.sub(B64_ALPHA, i, i)] = i - 1
end
B64_MAP["="] = 0
local function base64Decode(s)
	s = s:gsub("%s+", "")
	if #s == 0 then
		return ""
	end
	if s:find("[^A-Za-z0-9+/=]") then
		return nil, "invalid base64 characters"
	end
	if #s % 4 ~= 0 then
		return nil, "invalid base64 length"
	end
	local out = {}
	for i = 1, #s, 4 do
		local c1 = B64_MAP[s:sub(i, i)] or 0
		local c2 = B64_MAP[s:sub(i + 1, i + 1)] or 0
		local c3 = B64_MAP[s:sub(i + 2, i + 2)] or 0
		local c4 = B64_MAP[s:sub(i + 3, i + 3)] or 0
		local n = bor(bshl(c1, 18), bor(bshl(c2, 12), bor(bshl(c3, 6), c4)))
		out[#out + 1] = string.char(band(bshr(n, 16), 0xFF))
		if s:sub(i + 2, i + 2) ~= "=" then
			out[#out + 1] = string.char(band(bshr(n, 8), 0xFF))
		end
		if s:sub(i + 3, i + 3) ~= "=" then
			out[#out + 1] = string.char(band(n, 0xFF))
		end
	end
	return table.concat(out)
end
local function xorDecode(data, key)
	if type(key) == "number" then
		key = string.char(band(key, 0xFF))
	end
	if type(key) ~= "string" or #key == 0 then
		return nil, "xor key must be a non-empty string or a number"
	end
	local klen = #key
	local kbytes = {}
	for i = 1, klen do
		kbytes[i] = string.byte(key, i)
	end
	local out = {}
	for i = 1, #data do
		local db = string.byte(data, i)
		local kb = kbytes[((i - 1) % klen) + 1]
		out[i] = string.char(bit32.bxor(band(db, 0xFF), kb))
	end
	return table.concat(out)
end
local function xorByte(a, b)
	return bit32.bxor(a, b)
end
xorDecode = function(data, key)
	if type(key) == "number" then
		key = string.char(band(key, 0xFF))
	end
	if type(key) ~= "string" or #key == 0 then
		return nil, "xor key must be a non-empty string or a number"
	end
	local klen = #key
	local kbytes = {}
	for i = 1, klen do
		kbytes[i] = string.byte(key, i)
	end
	local out = {}
	for i = 1, #data do
		local db = string.byte(data, i)
		local kb = kbytes[((i - 1) % klen) + 1]
		out[i] = string.char(xorByte(db, kb))
	end
	return table.concat(out)
end
local LBC_VERSION_MIN = 3
local LBC_VERSION_MAX = 6
local function isValidLBC(data)
	if #data < 4 then
		return false
	end
	local v = string.byte(data, 1)
	return v >= LBC_VERSION_MIN and v <= LBC_VERSION_MAX
end
local function looksLikeBase64(s)
	if #s < 4 then
		return false
	end
	local clean = s:gsub("%s+", "")
	return #clean % 4 == 0 and not clean:find("[^A-Za-z0-9+/=]")
end
local function looksLikeHex(s)
	local clean = s:gsub("%s+", "")
	return #clean % 2 == 0 and not clean:find("[^0-9a-fA-F]") and #clean >= 8
end
local function hexDecode(s)
	s = s:gsub("%s+", "")
	local out = {}
	for i = 1, #s, 2 do
		out[#out + 1] = string.char(tonumber(s:sub(i, i + 1), 16))
	end
	return table.concat(out)
end
local function autoDecode(data, xorKey)
	local log = {}
	if isValidLBC(data) then
		if xorKey then
			local xd, err = xorDecode(data, xorKey)
			if xd and isValidLBC(xd) then
				log[#log + 1] = "applied XOR key on raw input"
				return xd, table.concat(log, " → ")
			end
		end
		log[#log + 1] = "raw LBC (no encoding)"
		return data, table.concat(log, " → ")
	end
	if looksLikeBase64(data) then
		local decoded, err = base64Decode(data)
		if decoded then
			log[#log + 1] = "base64"
			if isValidLBC(decoded) then
				return decoded, table.concat(log, " → ")
			end
			if xorKey then
				local xd = xorDecode(decoded, xorKey)
				if xd and isValidLBC(xd) then
					log[#log + 1] = "XOR"
					return xd, table.concat(log, " → ")
				end
			end
			if not xorKey then
				for k = 1, 255 do
					local xd = xorDecode(decoded, k)
					if xd and isValidLBC(xd) then
						log[#log + 1] = string.format("XOR(auto-detected key=0x%02X)", k)
						return xd, table.concat(log, " → ")
					end
				end
			end
			return decoded, table.concat(log, " → ") .. " (decoded but unrecognised)"
		end
	end
	if looksLikeHex(data) then
		local decoded = hexDecode(data)
		log[#log + 1] = "hex"
		if xorKey then
			local xd = xorDecode(decoded, xorKey)
			if xd and isValidLBC(xd) then
				log[#log + 1] = "XOR"
				return xd, table.concat(log, " → ")
			end
		end
		if isValidLBC(decoded) then
			return decoded, table.concat(log, " → ")
		end
		return decoded, table.concat(log, " → ") .. " (decoded but unrecognised)"
	end
	if xorKey then
		local xd, err = xorDecode(data, xorKey)
		if xd and isValidLBC(xd) then
			log[#log + 1] = "XOR"
			return xd, table.concat(log, " → ")
		end
	end
	log[#log + 1] = "unknown encoding (passed raw)"
	return data, table.concat(log, " → ")
end
local M = {}
M.base64Decode = base64Decode
M.xorDecode = xorDecode
M.hexDecode = hexDecode
M.autoDecode = autoDecode
function M.decompile(bytecode, opts)
	local options = {}
	for k, v in pairs(DEFAULT_OPTIONS) do
		options[k] = v
	end
	if opts then
		for k, v in pairs(opts) do
			options[k] = v
		end
	end
	return Decompile(bytecode, options)
end
M.prettyPrint = prettyPrint
M.cleanOutput = cleanOutput
M.DEFAULT_OPTIONS = DEFAULT_OPTIONS
M.pprint = pprint
M.BytecodeReader = BytecodeReader
local SSA_Engine = {}
function SSA_Engine.CalculateDominanceFrontier(blocks, idoms)
	local df = {}
	for _, b in ipairs(blocks) do
		df[b.id] = {}
	end
	local predecessors = {}
	for _, b in ipairs(blocks) do
		predecessors[b.id] = {}
	end
	for _, b in ipairs(blocks) do
		for _, succ in ipairs(b.successors) do
			table.insert(predecessors[succ.id], b)
		end
	end
	for _, b in ipairs(blocks) do
		local preds = predecessors[b.id]
		if #preds >= 2 then
			for _, p in ipairs(preds) do
				local runner = p
				while runner.id ~= idoms[b.id] do
					df[runner.id][b.id] = true
					local nextId = idoms[runner.id]
					if not nextId then
						break
					end
					for _, target in ipairs(blocks) do
						if target.id == nextId then
							runner = target
							break
						end
					end
				end
			end
		end
	end
	return df
end
function SSA_Engine.GetDefUse(block)
	local defs, uses = {}, {}
	local function markDef(reg)
		defs[reg] = true
	end
	local function markUse(reg)
		if not defs[reg] then
			uses[reg] = true
		end
	end
	for _, instr in ipairs(block.instructions) do
		local op = instr.opName
		if op == "MOVE" then
			markUse(instr.vB)
			markDef(instr.vA)
		elseif op == "ADD" or op == "SUB" or op == "MUL" or op == "DIV" then
			markUse(instr.vB)
			markUse(instr.vC)
			markDef(instr.vA)
		elseif op == "LOADK" or op == "LOADN" or op == "LOADB" then
			markDef(instr.vA)
		elseif op == "GETIMPORT" or op == "GETGLOBAL" then
			markDef(instr.vA)
		elseif op == "CALL" then
			markUse(instr.vA)
			local nArgs = instr.vB - 1
			if nArgs > 0 then
				for k = 1, nArgs do
					markUse(instr.vA + k)
				end
			end
			markDef(instr.vA)
		end
	end
	return defs, uses
end

M.SSA_Engine = SSA_Engine

local LuauDecompiler = {}

local _JumpOpcodes = {
	["JUMP"] = true,
	["JUMPBACK"] = true,
	["JUMPIF"] = true,
	["JUMPIFNOT"] = true,
	["JUMPIFEQ"] = true,
	["JUMPIFLE"] = true,
	["JUMPIFLT"] = true,
	["JUMPIFNOTEQ"] = true,
	["JUMPIFNOTLE"] = true,
	["JUMPIFNOTLT"] = true,
	["FORNPREP"] = true,
	["FORNLOOP"] = true,
	["FORGLOOP"] = true,
	["FORGPREP"] = true,
	["JUMPXEQKNIL"] = true,
	["JUMPXEQKB"] = true,
	["JUMPXEQKN"] = true,
	["JUMPXEQKS"] = true,
}
-- Opcodes that are followed by an AUX instruction word (must skip when computing fallthrough PC)
local _AuxOpcodes = {
	["GETGLOBAL"] = true,
	["SETGLOBAL"] = true,
	["GETIMPORT"] = true,
	["GETTABLEKS"] = true,
	["SETTABLEKS"] = true,
	["NAMECALL"] = true,
	["JUMPIFEQ"] = true,
	["JUMPIFLE"] = true,
	["JUMPIFLT"] = true,
	["JUMPIFNOTEQ"] = true,
	["JUMPIFNOTLE"] = true,
	["JUMPIFNOTLT"] = true,
	["NEWTABLE"] = true,
	["SETLIST"] = true,
	["FORGLOOP"] = true,
	["FASTCALL2"] = true,
	["FASTCALL2K"] = true,
	["FASTCALL3"] = true,
	["JUMPXEQKNIL"] = true,
	["JUMPXEQKB"] = true,
	["JUMPXEQKN"] = true,
	["JUMPXEQKS"] = true,
}

--- Partition proto.instructions into a proper CFG.
-- Each block: { id, startPC, instructions, successors }
-- Correctly handles AUX words, all Luau branch opcodes, and unconditional jumps.
function LuauDecompiler.CreateCFG(proto)
	local instructions = proto.instructions
	local leaders = { [1] = true }
	local jumpTargets = {} -- [instrIdx] = targetPC

	-- Pass 1: identify leaders and record jump targets
	for i = 1, #instructions do
		local instr = instructions[i]
		local opName = instr.opName
		if _JumpOpcodes[opName] then
			local targetPC = i + (instr.sD or 0) + 1
			local fallthroughPC = i + 1
			if _AuxOpcodes[opName] then
				fallthroughPC = i + 2
			end
			leaders[targetPC] = true
			leaders[fallthroughPC] = true
			jumpTargets[i] = targetPC
		end
		if opName == "RETURN" then
			leaders[i + 1] = true
		end
	end

	-- Pass 2: build block objects
	local blocks = {}
	local blockLookup = {} -- [instrPC] = block
	local current = { id = 1, instructions = {}, startPC = 1 }

	for i = 1, #instructions do
		if leaders[i] and i ~= current.startPC then
			table.insert(blocks, current)
			current = { id = #blocks + 1, instructions = {}, startPC = i }
		end
		table.insert(current.instructions, instructions[i])
		blockLookup[i] = current
	end
	table.insert(blocks, current)

	-- Pass 3: link successors
	for idx, block in ipairs(blocks) do
		local lastPC = block.startPC + #block.instructions - 1
		local lastInstr = instructions[lastPC]
		local opName = lastInstr and lastInstr.opName or ""
		block.successors = {}

		if _JumpOpcodes[opName] then
			local targetPC = jumpTargets[lastPC]
			if targetPC and blockLookup[targetPC] then
				table.insert(block.successors, blockLookup[targetPC])
			end
			-- Conditional branches also fall through; unconditional JUMP/JUMPBACK do not
			if opName ~= "JUMP" and opName ~= "JUMPBACK" then
				local nextBlock = blocks[idx + 1]
				if nextBlock then
					table.insert(block.successors, nextBlock)
				end
			end
		elseif opName ~= "RETURN" then
			local nextBlock = blocks[idx + 1]
			if nextBlock then
				table.insert(block.successors, nextBlock)
			end
		end
	end

	return blocks
end

--- Simple single-pass dominator approximation (suitable for small CFGs).
function LuauDecompiler.AnalyzeDominators(blocks)
	local idoms = {}
	local predecessors = {}
	for _, b in ipairs(blocks) do
		predecessors[b.id] = {}
	end
	for _, b in ipairs(blocks) do
		for _, s in ipairs(b.successors) do
			table.insert(predecessors[s.id], b)
		end
	end
	for i = 2, #blocks do
		local preds = predecessors[blocks[i].id]
		if #preds == 1 then
			idoms[blocks[i].id] = preds[1].id
		elseif #preds >= 2 then
			idoms[blocks[i].id] = blocks[1].id
		end
	end
	return idoms
end

--- Naive text decompile from a CFG (best-effort, register-map based).
function LuauDecompiler.Decompile(proto)
	local blocks = LuauDecompiler.CreateCFG(proto)
	local output = {}
	local visited = {}
	local regMap = {}
	local function emit(s, depth)
		table.insert(output, string.rep("    ", depth or 0) .. s)
	end
	local function fv(v)
		return (type(v) == "string") and string.format('"%s"', v) or tostring(v)
	end
	local function processBlock(block, depth)
		if visited[block.id] then
			return
		end
		visited[block.id] = true
		for _, instr in ipairs(block.instructions) do
			local op = instr.opName
			local A, B, C = instr.vA, instr.vB, instr.vC
			if op == "MOVE" then
				regMap[A] = regMap[B]
				emit(string.format("var_%d = %s", A, regMap[B] or "var_" .. B), depth)
			elseif op == "LOADK" then
				local val = proto.constants[instr.vD + 1]
				regMap[A] = fv(val)
				emit(string.format("var_%d = %s", A, regMap[A]), depth)
			elseif op == "LOADN" then
				regMap[A] = tostring(instr.sD)
				emit(string.format("var_%d = %s", A, regMap[A]), depth)
			elseif op == "GETGLOBAL" then
				local name = proto.constants[instr.aux + 1]
				regMap[A] = name
				emit(string.format("var_%d = %s", A, name), depth)
			elseif op == "ADD" then
				emit(string.format("var_%d = %s + %s", A, regMap[B] or "var_" .. B, regMap[C] or "var_" .. C), depth)
			elseif op == "CALL" then
				local args = {}
				for j = 1, B - 1 do
					table.insert(args, regMap[A + j] or "var_" .. (A + j))
				end
				emit(string.format("var_%d(%s)", A, table.concat(args, ", ")), depth)
			elseif op == "JUMPIFNOT" then
				emit(string.format("if var_%d then", A), depth)
				if block.successors[2] then
					processBlock(block.successors[2], depth + 1)
				end
				emit("end", depth)
				if block.successors[1] then
					processBlock(block.successors[1], depth)
				end
				return
			elseif op == "RETURN" then
				if B > 1 then
					emit(string.format("return var_%d", A), depth)
				else
					emit("return", depth)
				end
			end
		end
		if #block.successors == 1 then
			processBlock(block.successors[1], depth)
		end
	end
	processBlock(blocks[1], 0)
	return table.concat(output, "\n")
end

M.LuauDecompiler = LuauDecompiler

-- ── Dominator Engine (full iterative dataflow) ────────────────────────────────
local Dom_Engine = {}

local function _Dom_Intersect(d1, d2)
	if not d1 then
		return d2
	end
	if not d2 then
		return d1
	end
	local out = {}
	for node in pairs(d1) do
		if d2[node] then
			out[node] = true
		end
	end
	return out
end

--- Full iterative dominator analysis.
-- Returns idoms (immediate dominator map) and dominators (full dominator sets).
function Dom_Engine.Analyze(blocks)
	local entry = blocks[1]
	local doms = {}
	doms[entry.id] = { [entry.id] = true }
	local allIds = {}
	for _, b in ipairs(blocks) do
		allIds[b.id] = true
	end
	for i = 2, #blocks do
		local b = blocks[i]
		doms[b.id] = {}
		for id in pairs(allIds) do
			doms[b.id][id] = true
		end
	end
	local preds = {}
	for _, b in ipairs(blocks) do
		preds[b.id] = {}
	end
	for _, b in ipairs(blocks) do
		for _, succ in ipairs(b.successors) do
			table.insert(preds[succ.id], b)
		end
	end
	local changed = true
	while changed do
		changed = false
		for i = 2, #blocks do
			local b = blocks[i]
			local new_d = nil
			for _, p in ipairs(preds[b.id]) do
				new_d = _Dom_Intersect(new_d, doms[p.id])
			end
			new_d = new_d or {}
			new_d[b.id] = true
			local co, cn = 0, 0
			for _ in pairs(doms[b.id]) do
				co = co + 1
			end
			for _ in pairs(new_d) do
				cn = cn + 1
			end
			if co ~= cn then
				doms[b.id] = new_d
				changed = true
			end
		end
	end
	local idoms = {}
	for _, b in ipairs(blocks) do
		if b.id ~= entry.id then
			local candidates = {}
			for did in pairs(doms[b.id]) do
				if did ~= b.id then
					table.insert(candidates, did)
				end
			end
			for _, d_id in ipairs(candidates) do
				local is_idom = true
				for _, o_id in ipairs(candidates) do
					if d_id ~= o_id and not doms[d_id][o_id] then
						is_idom = false
						break
					end
				end
				if is_idom then
					idoms[b.id] = d_id
					break
				end
			end
		end
	end
	return idoms, doms
end

M.Dom_Engine = Dom_Engine
local _isMain = false
do
	local ok, info = false, nil
	if debug and type(debug.getinfo) == "function" then
		ok, info = pcall(debug.getinfo, 2, "S")
		if not (ok and info and info.what == "main") then
			ok, info = pcall(debug.getinfo, 1, "S")
		end
	end
	if ok and info and info.what == "main" then
		local src = (info.source or ""):gsub("^@", "")
		local a0 = type(arg) == "table" and tostring(arg[0] or "") or ""
		if src ~= "" and src == a0 then
			_isMain = true
		elseif src == "" or src:sub(1, 1) == "=" then
			_isMain = type(arg) == "table"
		end
	elseif type(arg) == "table" and not (ok and info) then
		_isMain = true
	end
end
if _isMain and type(io) == "table" and type(os) == "table" then
	local args = arg or {}
	local filepath = nil
	local opts = {}
	local xorKey = nil
	local forceDec = nil
	local showDecLog = false
	local i = 1
	while i <= #args do
		local a = args[i]
		if a == "--mode" then
			i = i + 1
			opts.DecompilerMode = args[i]
		elseif a == "--clean" then
			opts.CleanMode = true
		elseif a == "--no-globals" then
			opts.ListUsedGlobals = false
		elseif a == "--timeout" then
			i = i + 1
			opts.DecompilerTimeout = tonumber(args[i]) or 10
		elseif a == "--float-precision" then
			i = i + 1
			opts.ReaderFloatPrecision = tonumber(args[i]) or 7
		elseif a == "--show-debug" then
			opts.ShowDebugInformation = true
		elseif a == "--show-lines" then
			opts.ShowInstructionLines = true
		elseif a == "--show-opidx" then
			opts.ShowOperationIndex = true
		elseif a == "--show-opnames" then
			opts.ShowOperationNames = true
		elseif a == "--show-trivial" then
			opts.ShowTrivialOperations = true
		elseif a == "--no-typeinfo" then
			opts.UseTypeInfo = false
		elseif a == "--xor" then
			i = i + 1
			local raw = args[i] or ""
			local num = tonumber(raw)
			xorKey = num and string.char(band(num, 0xFF)) or raw
		elseif a == "--b64" then
			forceDec = "b64"
		elseif a == "--hex" then
			forceDec = "hex"
		elseif a == "--auto" then
			forceDec = "auto"
		elseif a == "--decode-log" then
			showDecLog = true
		elseif a == "--help" or a == "-h" then
			print("Usage: lua zukv2.lua <bytecode_file> [options]")
			print("")
			print("Decompiler options:")
			print("  --mode disasm       disassembly mode (default)")
			print("  --clean             pretty + clean output")
			print("  --no-globals        suppress used-globals header")
			print("  --timeout N         decompiler timeout in seconds (default 10)")
			print("  --float-precision N float formatting precision (default 7)")
			print("  --show-debug        show proto debug metadata")
			print("  --show-lines        show instruction line numbers")
			print("  --show-opidx        show instruction indices")
			print("  --show-opnames      show raw opcode names")
			print("  --show-trivial      show trivial (bookkeeping) ops")
			print("  --no-typeinfo       disable type annotation output")
			print("")
			print("Decode options (applied before decompiling):")
			print("  --auto              auto-detect encoding (base64 / hex / xor)")
			print("  --b64               force base64 decode first")
			print("  --hex               force hex decode first")
			print("  --xor <key>         XOR decode with key (string or 0xNN byte)")
			print("                      can be combined with --b64/--hex/--auto")
			print("  --decode-log        print what decode steps were applied")
			os.exit(0)
		elseif not filepath then
			filepath = a
		end
		i = i + 1
	end
	if not filepath then
		io.stderr:write("Usage: lua zukv2.lua <bytecode_file> [options]\n")
		os.exit(1)
	end
	local f, err = io.open(filepath, "rb")
	if not f then
		io.stderr:write("Error opening file: " .. tostring(err) .. "\n")
		os.exit(1)
	end
	local bytecode = f:read("*a")
	f:close()
	do
		local decLog = nil
		if forceDec == "b64" then
			local decoded, derr = base64Decode(bytecode)
			if not decoded then
				io.stderr:write("base64 decode failed: " .. tostring(derr) .. "\n")
				os.exit(1)
			end
			bytecode = decoded
			decLog = "base64"
			if xorKey then
				local xd, xerr = xorDecode(bytecode, xorKey)
				if not xd then
					io.stderr:write("XOR decode failed: " .. tostring(xerr) .. "\n")
					os.exit(1)
				end
				bytecode = xd
				decLog = decLog .. " → XOR"
			end
		elseif forceDec == "hex" then
			if not looksLikeHex(bytecode) then
				io.stderr:write("warning: input doesn't look like hex, attempting anyway\n")
			end
			bytecode = hexDecode(bytecode)
			decLog = "hex"
			if xorKey then
				local xd, xerr = xorDecode(bytecode, xorKey)
				if not xd then
					io.stderr:write("XOR decode failed: " .. tostring(xerr) .. "\n")
					os.exit(1)
				end
				bytecode = xd
				decLog = decLog .. " → XOR"
			end
		elseif forceDec == "auto" or xorKey then
			local decoded, dlog = autoDecode(bytecode, xorKey)
			bytecode = decoded
			decLog = dlog
		end
		if showDecLog and decLog then
			io.stderr:write("[decode] " .. decLog .. "\n")
		end
	end
	local result = M.decompile(bytecode, opts)
	if opts.CleanMode then
		result = prettyPrint(result)
		result = cleanOutput(result)
	end
	io.write(result)
end
function M.fancyHeader(result, opts)
    opts = opts or {}
    local lines = {}
    lines[#lines+1] = "-- ZUKv2 Disassembler"
    lines[#lines+1] = "-- Luau Bytecode Version: " .. (opts.luauVersion or "?")
    if opts.typeVersion then
        lines[#lines+1] = "-- Type Encoding Version: " .. opts.typeVersion
    end
    if opts.elapsed then
        lines[#lines+1] = string.format("-- Elapsed: %.4fs", opts.elapsed)
    end
    lines[#lines+1] = ""
    return table.concat(lines, "\n") .. (result or "")
end
return M
