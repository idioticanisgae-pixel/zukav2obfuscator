return {
["Fast"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "ByteAddr";
    PrettyPrint   =false;
    Seed          = 0;
    Steps = {
        { Name = "InvertedExecution"; Settings = { ChunkSize = 1; RandomiseIds = true; JunkChunks = 3 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
		{ Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
		{ Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };       
		{ Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};
["Light"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 12; MaxInterval = 22; GlobalScanCount = 7 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "SplitStrings";         Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 0.8; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.5; InternalTreshold = 0.15 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.25 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};
["Default"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vn";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 25; GlobalScanCount = 8 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 6 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.4 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.5; LocalWrapperCount = 2; LocalWrapperArgCount = 8;  } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.65; InjectionsPerBlock = 2 } };
		{ Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
	    { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.30 } };
        { Name = "WrapInFunction";       Settings = {} };
        -- DCE strips write-only junk locals and folds identity arithmetic
        -- before the final compressor pass, reducing output size.
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
    };
    Hercules = nil;
};
["HttpGet"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
       -- { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "InvertedExecution";    Settings = { ChunkSize = 2; RandomiseIds = true; JunkChunks = 2 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.40 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
		        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.7; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 1; MinAbsValue = 1;
        } };
		        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };

        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.2; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.60 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
		{ Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
    };
    Hercules = nil;
};
["Strings"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "rblx";
    PrettyPrint   = true;
    Seed          = 0;
    Steps = {
        { Name = "EncryptStrings"; Settings = {} };
        { Name = "LocalsToTable"; Settings = {} };
    };
    Hercules = nil;
};
["Byte"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vn";
    PrettyPrint   = false,
    Seed          = 0;
    Steps = {       
		{ Name = "VmifyBC";        Settings = { XorKey = 0; ShuffleOpcodes = true } };
    };
    Hercules = nil;
};
["Luraph"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vn";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
       -- { Name = "ExecutorGuard";        Settings = { BlockStudio = true; CheckCallerGuard = true; PersistentMonitor = true; MinInterval = 10; MaxInterval = 22; GlobalScanCount = 8 } };
        { Name = "InvertedExecution";    Settings = { ChunkSize = 2; RandomiseIds = true; JunkChunks = 2 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.40 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
		        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.7; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "ConstantsObfuscator";  Settings = {
            ObfuscateNumbers = true; ObfuscateStrings = true;
            MockStringChance = 1; MinAbsValue = 1;
        } };
		        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };

        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.2; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.60 } };
        { Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
		{ Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
    };
	
    Hercules = nil;
	};
-- FIX: IntegrityHash moved BEFORE EncryptStrings/DynamicXOR.
-- Original Heavy preset had it running after EncryptStrings, which meant
-- it was hashing ciphertext instead of plaintext — the check was useless.
["Heavy"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vn";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "InvertedExecution";    Settings = { ChunkSize = 2; RandomiseIds = true; JunkChunks = 2 } };
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        -- IntegrityHash MUST come before EncryptStrings and DynamicXOR
        -- so it hashes plaintext literals, not ciphertext.
        { Name = "IntegrityHash";        Settings = { SampleSize = 16; UseFakeExec = true } };
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = true; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 1; LocalWrapperCount = 3; LocalWrapperArgCount = 12;
        } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 1; InternalTreshold = 0.3 } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "JunkStatements";       Settings = {
            InjectionCount = 2; Treshold = 0.85; TableWriteRatio = 0.5;
            ChainLength = 4; TableWriteCount = 3;
        } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "FakeLoopWrap";         Settings = { Treshold = 0.35 } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
        { Name = "ZukaZalgo";            Settings = { Treshold = 1; UseNumericKeys = true } };
    };
    Hercules = nil;
};
["Medium"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Vnlight";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "EncryptStrings";       Settings = {} };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
       { Name = "DynamicXOR";           Settings = { Treshold = 0.5 } };
        { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.4; LocalWrapperCount = 2; LocalWrapperArgCount = 6;
        } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "NumbersToExpressions"; Settings = { Treshold = 0.8; InternalTreshold = 0.2 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "WrapInFunction";       Settings = {} };
    };
    Hercules = nil;
};
-- New preset: lean, correct anti-reverse stack with no false-positive risks.
-- Uses only the fixed steps. Safe on Synapse X, Solara, Wave, Fluxus.
["Luarmor"] = {
    LuaVersion    = "Lua51";
    VarNamePrefix = "";
    NameGenerator = "Dynamic";
    PrettyPrint   = false;
    Seed          = 0;
    Steps = {
        { Name = "PcallSilencer";        Settings = { Mode = "forward"; MaxDepth = 5 } };
        { Name = "EncryptStrings";       Settings = {} };
		{ Name = "SplitStrings";         Settings = {} };
        { Name = "AntiTamper";           Settings = { UseDebug = false } };
        { Name = "Vmify";                Settings = { OptimizationLevel = 2 } };
        { Name = "DynamicXOR";           Settings = { Treshold = 0.40 } };
		{ Name = "DynamicJumps";         Settings = { Threshold = 0.80; PoolSize = 64; MinStatements = 2 } };
        { Name = "DynamicDecrypt";       Settings = { Threshold = 0.7; Rounds = 4 } };
		 { Name = "ConstantArray";        Settings = {
            Treshold = 1; StringsOnly = false; Shuffle = true; Rotate = true;
            LocalWrapperTreshold = 0.7; LocalWrapperCount = 2; LocalWrapperArgCount = 8;
        } };
        { Name = "OpaquePredicates";     Settings = { Treshold = 0.85; InjectionsPerBlock = 2 } };
        { Name = "StatementFlattener";   Settings = { FlattenIf = true; FlattenFunctions = true; Threshold = 0.60 } };
        { Name = "AntiDump";             Settings = { GCInterval = 50 } };
        { Name = "VirtualGlobals";       Settings = { Treshold = 1; UseNumericKeys = true } };
        { Name = "WrapInFunction";       Settings = {} };
        { Name = "Compressor";           Settings = { MinLength = 10 } };
		{ Name = "DeadCodeEliminator";   Settings = { EliminateJunkLocals = true; FoldIdentities = true; EliminateDeadIf = true; EliminateEmptyDo = true } };
     	{ Name = "ZukaZalgo";            Settings = { Treshold = 1; UseNumericKeys = true } };

    };
    Hercules = nil;
};
}
