-- namegenerators/ticker.lua
-- Ticker — by ZukaTech
--
-- Names styled after stock market tickers, financial instrument codes,
-- and Bloomberg terminal identifiers. Looks like a quant/finance codebase.
--
-- Visually:  AAPL_Q, MSFT_3, BRK_A2, GS_XF, JPM_0C
--
-- Why it works:
--   - Ticker-style ALL_CAPS names look like legitimate constant tables
--   - Mixed with numeric suffixes it passes as financial data keys
--   - Completely unlike obfuscated code — looks like domain constants
--   - The 2-5 uppercase char pattern is extremely wide namespace

local util = require("ZukaTech.util")

-- Core letter pool — biased toward chars that make real-looking tickers
local LETTERS = {
    "A","B","C","D","E","F","G","H","I","J","K","L","M",
    "N","O","P","Q","R","S","T","U","V","W","X","Y","Z",
}

-- Suffix styles — financial instrument qualifiers
local SUFFIXES = {
    -- letter qualifiers
    "A","B","C","D","E","F","X","Y","Z","Q","W",
    -- numeric qualifiers
    "0","1","2","3","4","5","6","7","8","9",
    -- alphanumeric combos
    "A0","B1","C2","XF","QR","WS","ZZ","AB","CD",
}

-- Separator
local SEP = "_"

local MIN_TICKER_LEN = 2
local MAX_TICKER_LEN = 5

local seed  = 0
local order = {}

local function prng(n)
    n = (n * 2246822519 + seed) % 0x100000000
    local r, b, x, y = 0, 1, n, math.floor(n / 65536)
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then r = r + b end
        x = math.floor(x / 2); y = math.floor(y / 2); b = b * 2
    end
    return r
end

local function generateName(id, scope)
    -- Build 2-5 char uppercase ticker body
    local tlen   = MIN_TICKER_LEN + (prng(id * 3) % (MAX_TICKER_LEN - MIN_TICKER_LEN + 1))
    local ticker = ""
    for i = 0, tlen - 1 do
        local idx = (prng(id * 7 + i * 13) % #LETTERS) + 1
        ticker = ticker .. LETTERS[order[idx]]
    end

    -- Suffix (makes names unique past the first 26^5 combinations)
    local sfx = SUFFIXES[(prng(id * 11) % #SUFFIXES) + 1]

    -- Tier overflow: once every SUFFIXES-cycle, append tier counter
    local tier = math.floor(id / (#LETTERS ^ MIN_TICKER_LEN))
    if tier > 0 then
        sfx = sfx .. tostring(tier % 100)
    end

    return ticker .. SEP .. sfx
end

local function prepare(ast)
    seed  = math.random(0, 0xFFFFFF)
    order = {}
    for i = 1, #LETTERS do order[i] = i end
    util.shuffle(order)
    util.shuffle(SUFFIXES)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
