return {
	Mangled         = require("ZukaTech.namegenerators.mangled");
	MangledShuffled = require("ZukaTech.namegenerators.mangled_shuffled");
	Il              = require("ZukaTech.namegenerators.il");
	Number          = require("ZukaTech.namegenerators.number");
	Confuse         = require("ZukaTech.namegenerators.confuse");
	Unicode         = require("ZukaTech.namegenerators.unicode");
	Keywords        = require("ZukaTech.namegenerators.keywords");
	Hex             = require("ZukaTech.namegenerators.hex");
	Ghost           = require("ZukaTech.namegenerators.ghost");
	ZukaWeave       = require("ZukaTech.namegenerators.zukaweave");
	Mirage          = require("ZukaTech.namegenerators.mirage");
	ZukaZalgo       = require("ZukaTech.namegenerators.zukazalgo");
	Braille         = require("ZukaTech.namegenerators.braille");
	Runic           = require("ZukaTech.namegenerators.runic");
	Noise           = require("ZukaTech.namegenerators.noise");
	Phantom         = require("ZukaTech.namegenerators.phantom");
	Sigil           = require("ZukaTech.namegenerators.sigil");
	SegAddr         = require("ZukaTech.namegenerators.segaddr");
	Kawaii          = require("ZukaTech.namegenerators.kawaii");
	Boronide        = require("ZukaTech.namegenerators.boronide");
	DecEsc          = require("ZukaTech.namegenerators.decesc");
	RegAsm          = require("ZukaTech.namegenerators.regasm");
	Zuka            = require("ZukaTech.namegenerators.Zuka");
	Rblx            = require("ZukaTech.namegenerators.Rblx");
	Func            = require("ZukaTech.namegenerators.funcs");
	Luraph          = require("ZukaTech.namegenerators.luraph");
	Dynamic         = require("ZukaTech.namegenerators.Dynamic");
	-- v1-v100 randomised pool generator
	Vn              = require("ZukaTech.namegenerators.vn");
        Vnlight              = require("ZukaTech.namegenerators.vnlight");
       Nato     = require("ZukaTech.namegenerators.nato");
        ByteAddr = require("ZukaTech.namegenerators.byteaddr");
         Ticker   = require("ZukaTech.namegenerators.ticker");
}