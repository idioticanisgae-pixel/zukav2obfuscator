-- Obfuscation Step: Statement Flattener
--
-- Ports the StatementObfuscator technique from NewThingsToAdd into the
-- Zuraph pipeline.
--
-- What it does (two transforms, both configurable):
--
--   1. IF → WHILE  (FlattenIf)
--      Simple if-statements without elseif/else are converted to
--      while <condition> do … break end.
--      This makes the control flow graph look like a loop to naive
--      decompilers that don't model break semantics properly.
--
--   2. Function body → opcode-dispatched state machine  (FlattenFunctions)
--      Each statement in a local-function body is assigned a random
--      "opcode" integer.  The body is replaced with:
--
--        local state = <firstOpcode>
--        local <all locals declared in the body>
--        while <random float> do   -- always true
--          if     state == <op1> then state = <op2>; <stmt1>
--          elseif state == <op2> then state = <op3>; <stmt2>
--          …
--          end
--        end
--
--      This is exactly the technique used by high-end VM-based obfuscators
--      (like the StatementObfuscator in NewThingsToAdd) and makes control
--      flow analysis extremely expensive for automated tools.
--
-- Both passes work entirely on the Zuraph AST using visitast + Parser:parse
-- for snippet injection, no NodeFactory required.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")
local visitast = require("ZukaTech.visitast")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local StatementFlattener       = Step:extend()
StatementFlattener.Description = "Converts if-statements to while-break loops and flattens local-function bodies into opcode-dispatched state machines."
StatementFlattener.Name        = "Statement Flattener"

StatementFlattener.SettingsDescriptor = {
    FlattenIf = {
        type    = "boolean",
        default = true,
    },
    FlattenFunctions = {
        type    = "boolean",
        default = true,
    },
    -- Probability (0-1) that a given if/function is flattened
    Threshold = {
        type    = "number",
        default = 0.9,
        min     = 0,
        max     = 1,
    },
}

-- ── Shared parser instance ──────────────────────────────────────────────────
local _parser = nil
local function getParser()
    if not _parser then
        _parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    end
    return _parser
end

local function parseSnippet(src)
    local ok, result = pcall(function()
        return getParser():parse(src)
    end)
    if not ok or not result then return nil end
    return result.body and result.body.statements
end

-- ── Helpers ─────────────────────────────────────────────────────────────────
local function randOp()
    return math.random(2, 2^22)
end

-- Serialize a statement list back to source so we can embed it in a snippet.
-- We do this by leaning on the pipeline unparser when available, but since we
-- don't have it here we use a simpler approach: we directly manipulate the AST
-- node lists instead of round-tripping through source text.

-- Deep-copy a node table (shallow fields only — enough for statement relocation)
local function shallowCopy(t)
    local c = {}
    for k, v in pairs(t) do c[k] = v end
    return c
end

-- ── IF → WHILE transform ────────────────────────────────────────────────────
-- Replaces:   if <cond> then <body> end
-- With:       while <cond> do <body> break end
-- (Only simple if-statements — no elseif / else)
local function flattenIfNode(node)
    if node.kind ~= AstKind.IfStatement then return end
    -- Only handle simple if with no elseif and no else
    if node.elseifs and #node.elseifs > 0 then return end
    if node.elseBody then return end

    -- Mutate in-place: change to WhileStatement
    local body = node.body
    -- Append a break at the end (so it exits after one iteration)
    local hasReturn = body and body.statements and
        body.statements[#body.statements] and
        body.statements[#body.statements].kind == AstKind.ReturnStatement
    if not hasReturn then
        local breakNode = { kind = AstKind.BreakStatement }
        if body and body.statements then
            table.insert(body.statements, breakNode)
        end
    end

    node.kind      = AstKind.WhileStatement
    node.condition = node.condition  -- keep same condition
    node.body      = body
    -- Clear if-specific fields
    node.elseifs   = nil
    node.elseBody  = nil
end

-- ── Function body → state-machine transform ────────────────────────────────
-- Only applied to LocalFunction nodes.
local function flattenFunctionNode(node)
    if node.kind ~= AstKind.LocalFunction then return end
    local stmts = node.body and node.body.statements
    if not stmts or #stmts == 0 then return end

    -- Assign opcodes to each statement
    local opcodes = {}
    for i = 1, #stmts do
        opcodes[i] = {
            op   = randOp(),
            next = nil,
            stmt = stmts[i],
        }
    end
    -- Wire up next-opcode pointers
    for i = 1, #opcodes do
        opcodes[i].next = opcodes[i + 1] and opcodes[i + 1].op or randOp()
    end

    -- Collect local variable names declared at the top level of the function
    -- so we can hoist them before the state machine
    local hoistedLocals = {}
    local hoistedSet    = {}
    for _, entry in ipairs(opcodes) do
        local s = entry.stmt
        if s.kind == AstKind.LocalVariableDeclaration then
            for _, name in ipairs(s.variables or {}) do
                local id = type(name) == "table" and (name.name or name.value) or name
                if id and not hoistedSet[id] then
                    hoistedSet[id] = true
                    table.insert(hoistedLocals, id)
                end
            end
        elseif s.kind == AstKind.LocalFunction then
            local id = s.name
            if id and not hoistedSet[id] then
                hoistedSet[id] = true
                table.insert(hoistedLocals, id)
            end
        end
    end

    -- Build the new statement list:
    --   local state = firstOp
    --   [local <hoisted> ]
    --   while <rand_float_always_true> do
    --     if state == op1 then state = next1; <stmt1>
    --     elseif state == op2 then ...
    --     end
    --   end

    local firstOp = opcodes[1].op

    -- We rebuild the body statements list directly.
    -- stateVar node
    local stateDecl = {
        kind      = AstKind.LocalVariableDeclaration,
        variables = { { kind = AstKind.Identifier, name = "state" } },
        values    = { { kind = AstKind.NumberExpression, value = firstOp } },
    }

    -- hoist declaration (if any locals)
    local hoistDecl = nil
    if #hoistedLocals > 0 then
        local vars = {}
        for _, id in ipairs(hoistedLocals) do
            vars[#vars+1] = { kind = AstKind.Identifier, name = id }
        end
        hoistDecl = {
            kind      = AstKind.LocalVariableDeclaration,
            variables = vars,
            values    = {},
        }
    end

    -- Build if / elseif chain
    -- We build a recursive binary-search tree (like the original) for efficiency,
    -- but for simplicity we just do a linear if/elseif here.
    local function buildIfChain(entries, i)
        if i > #entries then return nil end
        local entry = entries[i]

        -- Convert LocalVariableDeclaration → VariableAssignment for hoisted vars
        local dispatchStmt = entry.stmt
        if dispatchStmt.kind == AstKind.LocalVariableDeclaration then
            dispatchStmt = {
                kind      = AstKind.AssignmentStatement,
                variables = dispatchStmt.variables,
                values    = dispatchStmt.values or {},
            }
        elseif dispatchStmt.kind == AstKind.LocalFunction then
            dispatchStmt = {
                kind       = AstKind.AssignmentStatement,
                variables  = { { kind = AstKind.Identifier, name = dispatchStmt.name } },
                values     = { {
                    kind       = AstKind.FunctionExpression,
                    parameters = dispatchStmt.parameters,
                    isVararg   = dispatchStmt.isVararg,
                    body       = dispatchStmt.body,
                } },
            }
        end

        local stateAssign = {
            kind      = AstKind.AssignmentStatement,
            variables = { { kind = AstKind.Identifier, name = "state" } },
            values    = { { kind = AstKind.NumberExpression, value = entry.next } },
        }

        local ifNode = {
            kind      = AstKind.IfStatement,
            condition = {
                kind     = AstKind.BinaryExpression,
                operator = "==",
                left     = { kind = AstKind.Identifier, name = "state" },
                right    = { kind = AstKind.NumberExpression, value = entry.op },
            },
            body = {
                kind       = AstKind.Block,
                statements = { stateAssign, dispatchStmt },
            },
            elseifs  = {},
            elseBody = nil,
        }

        local rest = buildIfChain(entries, i + 1)
        if rest then
            ifNode.elseBody = {
                kind       = AstKind.Block,
                statements = { rest },
            }
        end

        return ifNode
    end

    local ifChain = buildIfChain(opcodes, 1)

    -- while math.random() … always evaluates to a non-nil/non-false
    local whileNode = {
        kind      = AstKind.WhileStatement,
        condition = { kind = AstKind.NumberExpression, value = math.random() },
        body      = {
            kind       = AstKind.Block,
            statements = ifChain and { ifChain } or {},
        },
    }

    -- Assemble new body
    local newStmts = { stateDecl }
    if hoistDecl then table.insert(newStmts, hoistDecl) end
    table.insert(newStmts, whileNode)

    node.body.statements = newStmts
end

-- ── Step interface ──────────────────────────────────────────────────────────

function StatementFlattener:init(settings) end

function StatementFlattener:apply(ast, pipeline)
    local doIf   = self.FlattenIf
    local doFns  = self.FlattenFunctions
    local thresh = self.Threshold

    visitast(ast, function(node, data)
        if doIf and node.kind == AstKind.IfStatement then
            if math.random() <= thresh then
                flattenIfNode(node)
            end
        elseif doFns and node.kind == AstKind.LocalFunction then
            if math.random() <= thresh then
                flattenFunctionNode(node)
            end
        end
    end)

    return ast
end

return StatementFlattener
