-- ZukaTech/steps/VmifyBC.lua
--
-- Compiles the AST to a custom ZukaTech bytecode blob and wraps it in
-- a self-contained inline VM interpreter (IronBrew2-style structure,
-- fully custom ISA — no shared fingerprints with any public obfuscator).
--
-- Output layout:
--   1. LZW decompressor function (_lzwD)
--   2. XOR decode helper (_xdB)
--   3. Bytecode deserialiser (_ds)
--   4. VM executor (_ex)
--   5. Entry: decode blob → deserialise → execute

local Step      = require("ZukaTech.step")
local Parser    = require("ZukaTech.parser")
local Enums     = require("ZukaTech.enums")
local ISA       = require("ZukaTech.compiler.isa")
local BCFactory = require("ZukaTech.compiler.bytecode_compiler")
local logger    = require("logger")

local LuaVersion = Enums.LuaVersion
local OP         = ISA.OP

local VmifyBC       = Step:extend()
VmifyBC.Description = "Compiles script to a custom ZukaTech bytecode blob + inline VM (IronBrew2-style, custom ISA)."
VmifyBC.Name        = "VmifyBC"

VmifyBC.SettingsDescriptor = {
    XorKey = {
        name = "XorKey", type = "number", default = 0, min = 0, max = 254,
        description = "Bytecode XOR key 1-254 (0 = random per compile)",
    },
    ShuffleOpcodes = {
        name = "ShuffleOpcodes", type = "boolean", default = true,
        description = "Randomly permute opcode wire values each compilation",
    },
}

function VmifyBC:init(settings) end

-- ── LZW compress ──────────────────────────────────────────────────────────────

local C36 = "0123456789abcdefghijklmnopqrstuvwxyz"
local function b36(n)
    if n == 0 then return "0" end
    local s = ""
    while n > 0 do
        s = C36:sub(n%36+1,n%36+1)..s
        n = math.floor(n/36)
    end
    return s
end
local function eCode(n) local s=b36(n); return b36(#s)..s end
local function lzw(inp)
    local d,ds={},256
    for i=0,255 do d[string.char(i)]=i end
    local w,o="",{}
    for i=1,#inp do
        local c=inp:sub(i,i); local wc=w..c
        if d[wc] then w=wc
        else o[#o+1]=eCode(d[w]); d[wc]=ds; ds=ds+1; w=c end
    end
    if w~="" then o[#o+1]=eCode(d[w]) end
    return table.concat(o)
end

-- ── bxor (Lua 5.1) ────────────────────────────────────────────────────────────

local function bx(a,b)
    local r,m=0,1
    while a>0 or b>0 do
        local ra,rb=a%2,b%2
        if ra~=rb then r=r+m end
        a=math.floor(a/2); b=math.floor(b/2); m=m*2
    end
    return r
end
local function xorB(s,k)
    local t={}
    for i=1,#s do t[i]=string.char(bx(s:byte(i),k)%256) end
    return table.concat(t)
end

-- ── long-string embed ─────────────────────────────────────────────────────────

local function longStr(s)
    local lv=0
    while s:find("]"..string.rep("=",lv).."]",1,true) do lv=lv+1 end
    local eq=string.rep("=",lv)
    return "["..eq.."["..s.."]"..eq.."]"
end

-- ── VM source builder ─────────────────────────────────────────────────────────

local function buildVM(xorSeed, decodeMap)
    local xsStr = tostring(xorSeed)

    local dmParts = {}
    for wire, canon in pairs(decodeMap) do
        dmParts[#dmParts+1] = "["..wire.."]="..canon
    end
    local dmLit = "{"..table.concat(dmParts,",").."}"

    local function op(name) return tostring(OP[name]) end

    local L = {}
    local function ln(s) L[#L+1] = s end

    ln("local _sb=string.byte")
    ln("local _ss=string.sub")
    ln("local _fl=math.floor")
    ln("local _up=unpack or table.unpack")
    ln("local _XS="..xsStr)
    ln("local _DM="..dmLit)
    ln("")
    ln("local function _bx(a,b)")
    ln("    local r,m=0,1")
    ln("    while a>0 or b>0 do")
    ln("        local ra,rb=a%2,b%2")
    ln("        if ra~=rb then r=r+m end")
    ln("        a=_fl(a/2);b=_fl(b/2);m=m*2")
    ln("    end")
    ln("    return r%256")
    ln("end")
    ln("")
    -- LCG stream factory mirroring ISA.makeXorStream exactly
    ln("local function _mkS(seed)")
    ln("    local s=seed%4294967296")
    ln("    return function()")
    ln("        s=(s*1664525+1013904223)%4294967296")
    ln("        return s%256")
    ln("    end")
    ln("end")
    ln("")
    -- Per-proto seed derivation mirroring ISA.serialiseProto's protoSeed calc
    ln("local function _pSeed(depth)")
    ln("    local lo=_bx(_XS%256,(_fl(depth*0x9E))%256)")
    ln("    return (lo+_fl(_XS/256)*256)%4294967296")
    ln("end")
    ln("")
    -- _ds: raw bytes for header/counts/constants, LCG stream only for instructions
    ln("local _ds")
    ln("_ds=function(blob)")
    ln("    local pos=1")
    ln("    local function rb()")
    ln("        local v=_sb(blob,pos);pos=pos+1;return v")
    ln("    end")
    ln("    local function r2() return rb()*256+rb() end")
    ln("    local function rC()")
    ln("        local t=rb()")
    ln("        if t==0 then return nil")
    ln("        elseif t==1 then return rb()~=0")
    ln("        elseif t==2 then")
    ln("            local a,b,c,d=rb(),rb(),rb(),rb()")
    ln("            local v=a*16777216+b*65536+c*256+d")
    ln("            if v>=2147483648 then v=v-4294967296 end")
    ln("            return v")
    ln("        elseif t==3 then")
    ln("            local bs={}")
    ln("            for _=1,8 do bs[#bs+1]=rb() end")
    ln("            local lo=bs[1]+bs[2]*256+bs[3]*65536+bs[4]*16777216")
    ln("            local hi=bs[5]+bs[6]*256+bs[7]*65536+bs[8]*16777216")
    ln("            if lo==0 and hi==0 then return 0 end")
    ln("            local sg=_fl(hi/2147483648)")
    ln("            local ex=_fl(hi/1048576)%2048")
    ln("            local mh=hi%1048576")
    ln("            return((-1)^sg)*(2^(ex-1023))*((mh*4294967296+lo)/(2^52)+1)")
    ln("        elseif t==4 then")
    ln("            local ln2=r2()")
    ln("            local sv=_ss(blob,pos,pos+ln2-1);pos=pos+ln2;return sv")
    ln("        end")
    ln("    end")
    ln("    local function rP(depth)")
    ln("        local p={pa=rb(),va=rb()~=0,mr=rb(),K={},I={},P={}}")
    ln("        local nc=r2();for i=1,nc do p.K[i]=rC() end")
    ln("        local ni=r2()")
    ln("        local st=_mkS(_pSeed(depth))")
    ln("        for i=1,ni do")
    ln("            local s1,s2,s3,s4,s5,s6=st(),st(),st(),st(),st(),st()")
    ln("            local b1=_bx(_sb(blob,pos),  s1)")
    ln("            local b2=_bx(_sb(blob,pos+1),s2)")
    ln("            local b3=_bx(_sb(blob,pos+2),s3)")
    ln("            local b4=_bx(_sb(blob,pos+3),s4)")
    ln("            local b5=_bx(_sb(blob,pos+4),s5)")
    ln("            local b6=_bx(_sb(blob,pos+5),s6)")
    ln("            pos=pos+6")
    ln("            p.I[i]={_DM[b1] or b1,b2,b3*256+b4,b5*256+b6}")
    ln("        end")
    ln("        local np=rb();for i=1,np do p.P[i]=rP(depth+1) end")
    ln("        return p")
    ln("    end")
    ln("    return rP(0)")
    ln("end")
    ln("")
    -- Build handlers as a table of closures keyed by canonical opcode.
    -- Handlers mutate Stk directly (table, passed by reference).
    -- For scalar state (PC, running, retVal, retMulti, capC) handlers return
    -- a packed {PC, running, retVal, retMulti, capC} only when they change it;
    -- nil return means no state change needed.
    -- We shuffle handler order each compile so the layout has no fixed fingerprint.

    -- Sentinel: handlers that don't change state return nothing.
    -- Handlers that DO change state return: PC, running, retVal, retMulti, capC
    -- (nil means "keep current value" for each slot)

    local handlers = {
        { op("LOADNIL"),
            "Stk[A]=nil" },
        { op("LOADBOOL"),
            "Stk[A]=(B~=0)" },
        { op("LOADINT"),
            "local v=B*65536+C_",
            "if v>=2147483648 then v=v-4294967296 end",
            "Stk[A]=v" },
        { op("LOADFLOAT"),
            "Stk[A]=K[B+1]" },
        { op("LOADSTR"),
            "Stk[A]=K[B+1]" },
        { op("MOVE"),
            "Stk[A]=Stk[B]" },
        { op("GETGLOBAL"),
            "Stk[A]=env[K[B+1]]" },
        { op("SETGLOBAL"),
            "env[K[B+1]]=Stk[A]" },
        { op("GETTABLE"),
            "Stk[A]=Stk[B][Stk[C_]]" },
        { op("SETTABLE"),
            "Stk[A][Stk[B]]=Stk[C_]" },
        { op("NEWTABLE"),
            "Stk[A]={}" },
        { op("ADD"),  "Stk[A]=Stk[B]+Stk[C_]" },
        { op("SUB"),  "Stk[A]=Stk[B]-Stk[C_]" },
        { op("MUL"),  "Stk[A]=Stk[B]*Stk[C_]" },
        { op("DIV"),  "Stk[A]=Stk[B]/Stk[C_]" },
        { op("MOD"),  "Stk[A]=Stk[B]%Stk[C_]" },
        { op("POW"),  "Stk[A]=Stk[B]^Stk[C_]" },
        { op("CONCAT"), "Stk[A]=Stk[B]..Stk[C_]" },
        { op("LT"),   "Stk[A]=Stk[B]<Stk[C_]" },
        { op("LE"),   "Stk[A]=Stk[B]<=Stk[C_]" },
        { op("EQ"),   "Stk[A]=Stk[B]==Stk[C_]" },
        { op("NE"),   "Stk[A]=(Stk[B]~=Stk[C_])" },
        { op("GT"),   "Stk[A]=Stk[B]>Stk[C_]" },
        { op("GE"),   "Stk[A]=Stk[B]>=Stk[C_]" },
        { op("NOT"),  "Stk[A]=not Stk[B]" },
        { op("UNM"),  "Stk[A]=-Stk[B]" },
        { op("LEN"),  "Stk[A]=#Stk[B]" },
        { op("CALL"),
            "local fn=Stk[A];local ca={}",
            "if B==0 then local _t=Stk[A+1]",
            "    if type(_t)=='table' then for _i=1,#_t do ca[_i]=_t[_i] end",
            "    elseif _t~=nil then ca[1]=_t end",
            "else for i=1,B do ca[i]=Stk[A+i] end end",
            "local _cn=#ca;if _cn>200 then _cn=200 end",
            "local res={fn(_up(ca,1,_cn))}",
            "if C_==0 then for i=1,#res do Stk[A+i-1]=res[i] end",
            "else for i=1,C_ do Stk[A+i-1]=res[i] end end" },
        { op("CALLM"),
            "local fn=Stk[A];local ca={}",
            "if B==0 then local _t=Stk[A+1]",
            "    if type(_t)=='table' then for _i=1,#_t do ca[_i]=_t[_i] end",
            "    elseif _t~=nil then ca[1]=_t end",
            "else for i=1,B do ca[i]=Stk[A+i] end end",
            "local _cn=#ca;if _cn>200 then _cn=200 end",
            "Stk[C_]={fn(_up(ca,1,_cn))}" },
        { op("VCALL"),
            "local fn=Stk[A];local ca={}",
            "if B==0 then local _t=Stk[A+1]",
            "    if type(_t)=='table' then for _i=1,#_t do ca[_i]=_t[_i] end",
            "    elseif _t~=nil then ca[1]=_t end",
            "else for i=1,B do ca[i]=Stk[A+i] end end",
            "local _cn=#ca;if _cn>200 then _cn=200 end",
            "fn(_up(ca,1,_cn))" },
        -- Stateful handlers: return PC, running, retVal, retMulti, capC
        { op("JMP"),
            "return B,nil,nil,nil,nil" },
        { op("JMPT"),
            "if Stk[A] then return B,nil,nil,nil,nil end" },
        { op("JMPF"),
            "if not Stk[A] then return B,nil,nil,nil,nil end" },
        { op("RETURN"),
            "local rv2,rm2",
            "if B==1 then rv2=nil;rm2=false",
            "elseif B==0 then",
            "    local rv={};local i=A",
            "    while i<=proto.mr and Stk[i]~=nil do rv[#rv+1]=Stk[i];i=i+1 end",
            "    rv2=rv;rm2=true",
            "else",
            "    local rv={}",
            "    for i=A,A+B-2 do rv[#rv+1]=Stk[i] end",
            "    rv2=rv;rm2=(#rv>1)",
            "end",
            "return nil,false,rv2,rm2,nil" },
        { op("RETURNM"),
            "local t=Stk[A]",
            "local rv=(type(t)==\"table\") and t or {t}",
            "return nil,false,rv,true,nil" },
        { op("ALLOC_UPVAL"),
            "capC=capC+1",
            "capSlots[capC]={v=Stk[A]}",
            "Stk[A]=capC",
            "return nil,nil,nil,nil,capC" },
        { op("GET_UPVAL"),
            "local _sid=Stk[B]",
            "local _sl=type(_sid)=='number' and capSlots[_sid]",
            "Stk[A]=_sl and _sl.v or nil" },
        { op("SET_UPVAL"),
            "local _sid=Stk[A]",
            "local _sl=type(_sid)=='number' and capSlots[_sid]",
            "if _sl then _sl.v=Stk[B] end" },
        { op("FREE_UPVAL"), "" },
        { op("CLOSURE"),
            "local subP=P[B+1]",
            "local childCap={}",
            "local nPC=PC",
            "for _ci=1,C_ do",
            "    local capInst=I[nPC];nPC=nPC+1",
            "    local parentReg=capInst[3]",
            "    local parentVal=Stk[parentReg]",
            "    if type(parentVal)=='number' and capSlots[parentVal] then",
            "        childCap[_ci]=capSlots[parentVal]",
            "    else childCap[_ci]={v=parentVal} end",
            "end",
            "Stk[A]=_ex(subP,childCap,env)",
            "return nPC,nil,nil,nil,nil" },
        { op("VARARG"),
            "if B==0 then Stk[A]={_up(Varg,1,#Varg)}",
            "else for i=1,B-1 do Stk[A+i-1]=Varg[i] end end" },
    }

    -- Fisher-Yates shuffle
    for i = #handlers, 2, -1 do
        local j = math.random(1, i)
        handlers[i], handlers[j] = handlers[j], handlers[i]
    end

    -- Inject junk handlers interspersed throughout
    local junkCount = math.random(8, 20)
    local junkBodies = {
        {"Stk[A]=Stk[A]"},
        {"local _z=B+C_"},
        {"local _z=A*B"},
        {"local _z=K[1]"},
        {""},
    }
    for _ = 1, junkCount do
        local fakeId = math.random(ISA.OP_COUNT, 254)
        local body = junkBodies[math.random(1, #junkBodies)]
        local h = {tostring(fakeId)}
        for _, bl in ipairs(body) do h[#h+1] = bl end
        local pos = math.random(1, #handlers + 1)
        table.insert(handlers, pos, h)
    end

    -- Forward-declare _ex BEFORE _DT so the CLOSURE handler closes over the variable
    -- reference rather than nil (it gets assigned after _DT is built)
    ln("local _ex")
    ln("")
    -- Emit the dispatch table
    ln("local _DT={}")
    for _, h in ipairs(handlers) do
        local canonId = h[1]
        local bodyLines = {}
        for i = 2, #h do
            if h[i] ~= "" then bodyLines[#bodyLines+1] = "    "..h[i] end
        end
        if #bodyLines == 0 then
            ln("_DT["..canonId.."]=function(Stk,K,I,P,A,B,C_,proto,PC,capSlots,capC,Varg,env) end")
        else
            ln("_DT["..canonId.."]=function(Stk,K,I,P,A,B,C_,proto,PC,capSlots,capC,Varg,env)")
            for _, bl in ipairs(bodyLines) do ln(bl) end
            ln("end")
        end
    end
    ln("")
    -- _ex assignment (forward-declared above _DT)
    ln("_ex=function(proto,capSlots,env)")
    ln("    local K=proto.K;local I=proto.I;local P=proto.P")
    ln("    if not capSlots then capSlots={} end")
    ln("    local capC=0")
    ln("    for k,_ in pairs(capSlots) do if k>capC then capC=k end end")
    ln("    return function(...)")
    ln("        local Stk={};local args={...}")
    ln("        for i=0,proto.pa-1 do Stk[i]=args[i+1] end")
    ln("        local Varg={}")
    ln("        if proto.va then")
    ln("            for i=proto.pa+1,#args do Varg[#Varg+1]=args[i] end")
    ln("        end")
    ln("        local PC=1;local running=true;local retVal=nil;local retMulti=false")
    ln("        while running do")
    ln("            local inst=I[PC]")
    ln("            if not inst then break end")
    ln("            local op_=inst[1];local A=inst[2];local B=inst[3];local C_=inst[4]")
    ln("            PC=PC+1")
    ln("            local _h=_DT[op_]")
    ln("            if _h then")
    ln("                local r1,r2,r3,r4,r5=_h(Stk,K,I,P,A,B,C_,proto,PC,capSlots,capC,Varg,env)")
    ln("                if r1~=nil then PC=r1 end")
    ln("                if r2~=nil then running=r2 end")
    ln("                if r3~=nil or r2==false then retVal=r3 end")
    ln("                if r4~=nil then retMulti=r4 end")
    ln("                if r5~=nil then capC=r5 end")
    ln("            end")
    ln("        end")
    ln("        if retMulti then")
    ln("            local _rn=#retVal;if _rn>200 then _rn=200 end")
    ln("            return _up(retVal,1,_rn)")
    ln("        elseif retVal~=nil then")
    ln("            return retVal")
    ln("        end")
    ln("    end")
    ln("end")
    ln("")

    return table.concat(L, "\n")
end

-- ── apply ─────────────────────────────────────────────────────────────────────

function VmifyBC:apply(ast, pipeline)

    math.randomseed(os.time())
    math.random(); math.random(); math.random()

    local bc = BCFactory.new()
    local ok, proto = pcall(function() return bc:compile(ast) end)
    if not ok then
        logger:warn("[VmifyBC] Compilation failed: "..tostring(proto))
        logger:warn("[VmifyBC] AST unchanged — add a Vmify step as fallback")
        return ast
    end

    local xorSeed = (self.XorKey and self.XorKey > 0) and self.XorKey or math.random(0, 2147483647)
    local encodeMap, decodeMap
    if self.ShuffleOpcodes ~= false then
        encodeMap, decodeMap = ISA.makeOpcodeMap()
    else
        encodeMap, decodeMap = {}, {}
        for i = 0, ISA.OP_COUNT-1 do encodeMap[i]=i; decodeMap[i]=i end
    end
    local function encOp(c) return encodeMap[c] or c end

    local blob    = ISA.serialiseProto(proto, xorSeed, encOp)
    local blobKey = math.random(1, 127)
    local rtSalt  = math.random(1, 126)
    if rtSalt == blobKey then rtSalt = (rtSalt % 126) + 1 end

    local encoded    = xorB(xorB(blob, blobKey), rtSalt)
    local compressed = lzw(encoded)

    logger:info(string.format(
        "[VmifyBC] proto: %d instr, %d consts, %d sub-protos | blob %d B -> 2xor %d B -> lzw %d B",
        #proto.instrs, #proto.consts, #proto.protos,
        #blob, #encoded, #compressed))

    local vmSrc   = buildVM(xorSeed, decodeMap)
    local blobLit = longStr(compressed)
    local bkLit   = tostring(blobKey)
    local saltLit = tostring(rtSalt)

    -- FIX: getfenv fallback for Roblox executors that don't expose _ENV
    -- FIX: _ds and _ex are forward-declared locals in vmSrc, so glue can see them
    local glue = table.concat({
        "local function _lzwD(b)",
        "    local c,d,e,f,g='','',{},256,{}",
        "    for h=0,255 do g[h]=string.char(h) end",
        "    local i=1",
        "    local function k()",
        "        local l=tonumber(string.sub(b,i,i),36);i=i+1",
        "        local m=tonumber(string.sub(b,i,i+l-1),36);i=i+l",
        "        return m",
        "    end",
        "    c=string.char(k());e[1]=c",
        "    while i<=#b do",
        "        local n=k()",
        "        if g[n] then d=g[n] else d=c..string.sub(c,1,1) end",
        "        g[f]=c..string.sub(d,1,1);e[#e+1],c,f=d,d,f+1",
        "    end",
        "    return table.concat(e)",
        "end",
        "local function _xdB(s,k)",
        "    local function _bx2(a,b)",
        "        local r,m=0,1",
        "        while a>0 or b>0 do",
        "            local ra,rb=a%2,b%2",
        "            if ra~=rb then r=r+m end",
        "            a=math.floor(a/2);b=math.floor(b/2);m=m*2",
        "        end",
        "        return r",
        "    end",
        "    local t={}",
        "    for i=1,#s do t[i]=string.char(_bx2(s:byte(i),k)%256) end",
        "    return table.concat(t)",
        "end",
        "local _blob=_xdB(_xdB(_lzwD("..blobLit.."),"..saltLit.."),"..bkLit..")",
        "local _proto=_ds(_blob)",
        -- FIX: getfenv(1) is the correct Lua 5.1 / Roblox executor call; _ENV doesn't exist
        "local _env=getfenv and getfenv(1) or (function() return _ENV end)()",
        "local _fn=_ex(_proto,nil,_env)",
        "_fn(...)",
    }, "\n")

    local fullSrc = vmSrc .. "\n" .. glue

    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok2, newAst = pcall(function() return parser:parse(fullSrc) end)
    if not ok2 then
        logger:warn("[VmifyBC] Re-parse failed: "..tostring(newAst))
        logger:warn("[VmifyBC] Source head: "..fullSrc:sub(1,300))
        return ast
    end

    return newAst
end

return VmifyBC