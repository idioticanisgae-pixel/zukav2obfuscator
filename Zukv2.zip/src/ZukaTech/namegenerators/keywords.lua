-- namegenerators/keywords.lua
-- Generates names that visually resemble Lua/Roblox keywords and builtins
-- Makes deobfuscation mentally exhausting — everything looks like it means something

local util = require("ZukaTech.util")

-- Looks like keywords but aren't — slight mutations of real ones
local bases = {
    -- Lua keyword lookalikes
    "local_",  "true_",   "false_",  "nil_",    "and_",
    "not_",    "or_",     "do_",     "end_",    "if_",
    "then_",   "else_",   "elseif_", "while_",  "for_",
    "in_",     "return_", "break_",  "repeat_", "until_",
    "function_", "table_", "string_", "math_",  "type_",
    -- Roblox / common API lookalikes
    "game_",   "workspace_", "script_", "player_", "char_",
    "part_",   "frame_",     "gui_",    "event_",  "remote_",
    "tween_",  "run_",       "bind_",   "fire_",   "wait_",
    "pcall_",  "pairs_",     "ipairs_", "next_",   "self_",
    "args_",   "inst_",      "serv_",   "conn_",   "obj_",
}

-- Short numeric suffixes to differentiate names
local suffixes = {}
for i = 0, 99 do
    table.insert(suffixes, tostring(i))
end

local order = {}

local function generateName(id, scope)
    local bi = id % #bases
    id = (id - bi) / #bases
    local si = id % #suffixes
    return bases[order[bi + 1]] .. suffixes[si + 1]
end

local function prepare(ast)
    util.shuffle(bases)
    util.shuffle(suffixes)
    -- build a shuffled index order so base selection is non-sequential
    order = {}
    for i = 1, #bases do order[i] = i end
    util.shuffle(order)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
