local util = require("ZukaTech.util")
local MIN_CHARACTERS     = 8
local MAX_INITIAL_OFFSET = 20
local VarDigits      = { "I", "I", "l", "I", "l", "l"}
local VarStartDigits = { "I", "i", "l" }
local offset = 0
local function generateName(id, scope)
    local name = ""
    local n    = id + offset
    local d = n % #VarStartDigits
    n       = (n - d) / #VarStartDigits
    name    = name .. VarStartDigits[d + 1]
    local count = 0
    repeat
        local dd = n % #VarDigits
        n        = (n - dd) / #VarDigits
        name     = name .. VarDigits[dd + 1]
        count    = count + 1
    until n == 0 and count >= MIN_CHARACTERS - 1
    return name
end
local function prepare(ast)
    util.shuffle(VarDigits)
    util.shuffle(VarStartDigits)
    offset = math.random(
        (#VarDigits) ^ MIN_CHARACTERS,
        (#VarDigits) ^ MAX_INITIAL_OFFSET
    )
end
return {
    generateName = generateName,
    prepare      = prepare,
}