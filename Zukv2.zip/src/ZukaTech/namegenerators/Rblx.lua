-- ZukaTech Obfuscator — namegenerators/Rblx.lua
-- Generates plausible Roblox-internal-looking identifiers so obfuscated
-- code reads like legitimate engine/framework code.
--
-- Features:
--   • camelCase, PascalService, snake_case, short var styles
--   • Scope-aware depth thresholds (configurable via CFG)
--   • mixedDepth jitter — breaks systematic patterns
--   • Related-name families — siblings share a common prefix
--   • Per-scope collision tracking — same name valid in sibling scopes
--   • Shuffled word banks per run for variety

local util = require("ZukaTech.util")

-- ────────────────────────────────────────────────
-- Config — tune these to taste
-- ────────────────────────────────────────────────

local CFG = {
	-- Scope level at which style switches camel -> snake
	SNAKE_DEPTH          = 2,
	-- Scope level at which style switches snake -> short
	SHORT_DEPTH          = 4,
	-- 0.0-1.0: chance a deep-scope var gets camel instead of short (jitter)
	MIXED_DEPTH_CHANCE   = 0.15,
	-- 0.0-1.0: chance a camel name uses PascalService style
	SERVICE_STYLE_CHANCE = 0.25,
	-- 0.0-1.0: chance vars in a scope share a family prefix
	FAMILY_CHANCE        = 0.35,
}

-- ────────────────────────────────────────────────
-- Word banks
-- ────────────────────────────────────────────────

local prefixes = {
	"Instance", "Remote", "Script", "Player", "Character",
	"Network", "Render", "Physics", "Replication", "Signal",
	"Module", "Object", "Service", "Core", "Internal",
	"Local", "Server", "Client", "Shared", "Utility",
	"Data", "Cache", "Event", "Task", "Thread",
	"Stream", "Buffer", "Queue", "Stack", "Registry",
}

local middles = {
	"Handler", "Manager", "Controller", "Dispatcher", "Resolver",
	"Loader", "Builder", "Factory", "Provider", "Listener",
	"Tracker", "Monitor", "Scheduler", "Processor", "Executor",
	"Wrapper", "Adapter", "Bridge", "Router", "Validator",
	"Encoder", "Decoder", "Parser", "Formatter", "Serializer",
	"Context", "Config", "State", "Store", "Registry",
}

local suffixes = {
	"Impl", "Base", "Core", "Util", "Helper",
	"Node", "Leaf", "Root", "Sink", "Source",
	"Hook", "Slot", "Port", "Gate", "Frame",
	"Step", "Pass", "Stage", "Phase", "Cycle",
	"Map", "Set", "List", "Pool", "Heap",
}

-- PascalService style — mimics real Roblox service naming
local service_suffixes = {
	"Service", "Controller", "Provider", "Manager",
	"Handler", "System", "Interface", "Module",
}

local snake_parts = {
	"instance", "remote", "script", "player", "character",
	"network", "render", "physics", "signal", "module",
	"object", "service", "core", "server", "client",
	"data", "cache", "event", "task", "thread",
	"handler", "manager", "loader", "factory", "listener",
	"tracker", "scheduler", "processor", "wrapper", "router",
	"impl", "base", "util", "node", "sink",
	"hook", "slot", "port", "gate", "step",
	"map", "pool", "state", "store", "context",
}

local short_bases = { "n", "v", "k", "t", "s", "p", "r", "c", "i", "j" }

-- ────────────────────────────────────────────────
-- Per-run state
-- ────────────────────────────────────────────────

local _globalUsed  = {}   -- prevents any name appearing twice globally
local _scopeUsed   = {}   -- per-scope sets (sibling scopes may reuse names)
local _scopeFamily = {}   -- per-scope family prefix assignment
local _counter     = 0

local function resetState()
	_globalUsed  = {}
	_scopeUsed   = {}
	_scopeFamily = {}
	_counter     = 0
end

-- ────────────────────────────────────────────────
-- Helpers
-- ────────────────────────────────────────────────

local function pick(t, seed)
	return t[(seed % #t) + 1]
end

local function scopeLevel(scope)
	if type(scope) == "table" then
		return tonumber(scope.level or scope.depth or 0) or 0
	elseif type(scope) == "number" then
		return scope
	end
	return 0
end

local function bumpSeed(seed)
	return (seed * 1664525 + 1013904223) % 0x7FFFFFFF
end

local function isUsed(name, scopeKey)
	if _globalUsed[name] then return true end
	if _scopeUsed[scopeKey] and _scopeUsed[scopeKey][name] then return true end
	return false
end

local function markUsed(name, scopeKey)
	_globalUsed[name] = true
	if not _scopeUsed[scopeKey] then _scopeUsed[scopeKey] = {} end
	_scopeUsed[scopeKey][name] = true
end

-- Assigns a family prefix to a scope on first visit, or returns false
local function getFamilyPrefix(scopeKey, seed)
	if _scopeFamily[scopeKey] == nil then
		local roll = (bumpSeed(seed) % 100) / 100.0
		if roll < CFG.FAMILY_CHANCE then
			_scopeFamily[scopeKey] = pick(prefixes, seed)
		else
			_scopeFamily[scopeKey] = false
		end
	end
	return _scopeFamily[scopeKey]
end

-- ────────────────────────────────────────────────
-- Name builders
-- ────────────────────────────────────────────────

local function buildCamel(seed, scopeKey)
	local family = getFamilyPrefix(scopeKey, seed)
	local root   = family or pick(prefixes, seed)

	-- PascalService style: PlayerDataService, NetworkEventController
	local serviceRoll = (bumpSeed(seed) % 100) / 100.0
	if serviceRoll < CFG.SERVICE_STYLE_CHANCE then
		local svcSfx = pick(service_suffixes, bumpSeed(bumpSeed(seed)))
		if seed % 2 == 0 then
			return root .. svcSfx
		else
			return root .. pick(middles, bumpSeed(seed)) .. svcSfx
		end
	end

	-- Standard camelCase
	local style = seed % 3
	if style == 0 then
		return root .. pick(middles, seed + 7)
	elseif style == 1 then
		return root .. pick(suffixes, seed + 11)
	else
		return root .. pick(middles, seed + 5) .. pick(suffixes, seed + 13)
	end
end

local function buildSnake(seed, scopeKey)
	local family = getFamilyPrefix(scopeKey, seed)
	local parts  = (seed % 2) + 2  -- 2 or 3 parts
	local t      = {}

	if family then
		t[1] = string.lower(family)
		for i = 2, parts do
			t[i] = pick(snake_parts, seed + i * 17)
		end
	else
		for i = 1, parts do
			t[i] = pick(snake_parts, seed + i * 17)
		end
	end
	return table.concat(t, "_")
end

local function buildShort(seed)
	_counter = _counter + 1
	return pick(short_bases, seed) .. tostring(_counter)
end

-- ────────────────────────────────────────────────
-- Style selection
-- ────────────────────────────────────────────────

local function chooseStyle(level, seed)
	if level >= CFG.SHORT_DEPTH then
		-- mixedDepth jitter: occasionally surface a camel name at deep scope
		local roll = (bumpSeed(seed) % 100) / 100.0
		if roll < CFG.MIXED_DEPTH_CHANCE then
			return "camel"
		end
		return "short"
	elseif level >= CFG.SNAKE_DEPTH then
		return "snake"
	else
		return "camel"
	end
end

-- ────────────────────────────────────────────────
-- Public: generateName(id, scope, originalName)
-- ────────────────────────────────────────────────

local function generateName(id, scope, originalName)
	local level    = scopeLevel(scope)
	local style    = chooseStyle(level, id)
	local scopeKey = tostring(scope)

	local name
	local seed     = id
	local attempts = 0

	repeat
		if style == "camel" then
			name = buildCamel(seed, scopeKey)
		elseif style == "snake" then
			name = buildSnake(seed, scopeKey)
		else
			name = buildShort(seed)
		end

		if isUsed(name, scopeKey) then
			seed = bumpSeed(seed)
			name = nil
		end

		attempts = attempts + 1
	until name ~= nil or attempts > 128

	-- absolute fallback
	if name == nil then
		name = (originalName or "v") .. tostring(id)
	end

	markUsed(name, scopeKey)
	return name
end

-- ────────────────────────────────────────────────
-- Public: prepare(ast)
-- ────────────────────────────────────────────────

local function prepare(ast)
	resetState()
	util.shuffle(prefixes)
	util.shuffle(middles)
	util.shuffle(suffixes)
	util.shuffle(service_suffixes)
	util.shuffle(snake_parts)
	util.shuffle(short_bases)
end

-- ────────────────────────────────────────────────

return {
	generateName = generateName,
	prepare      = prepare,
}