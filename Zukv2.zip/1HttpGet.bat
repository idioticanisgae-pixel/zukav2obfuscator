@echo off
title zukv2 obfuscator by @overzuka
set /p target=name of script: 

echo.
set /p luau_choice=Enable LuaU? (y/n, default=n): 

set opt=
if /i "%luau_choice%"=="y" (
    set opt=--LuaU
)

echo.
echo Obfuscating: .\lua.exe cli.lua --preset ZuraphMax %opt% %target%
echo ---------------------------------------------------------
.\lua.exe cli.lua --preset HttpGet %opt% %target%
echo ---------------------------------------------------------
echo.
echo Done.
pause