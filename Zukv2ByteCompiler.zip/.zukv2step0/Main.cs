﻿using System;
using System.IO;

namespace zukv2
{
    internal static class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Usage: zukv2.exe <input.lua> <output.lua> [options]");
                Console.WriteLine("  --no-mutate        Disable mutation");
                Console.WriteLine("  --no-superops      Disable super operators");
                Console.WriteLine("  --no-controlflow   Disable control flow obfuscation");
                Console.WriteLine("  --encrypt-strings  Enable string encryption");
                return;
            }

            string input  = args[0];
            string output = args[1];
            string outDir = Path.GetDirectoryName(Path.GetFullPath(output)) ?? ".";

            var settings = new Obfuscator.ObfuscationSettings();

            for (int i = 2; i < args.Length; i++)
            {
                switch (args[i].ToLower())
                {
                    case "--no-mutate":       settings.Mutate         = false; break;
                    case "--no-superops":     settings.SuperOperators = false; break;
                    case "--no-controlflow":  settings.ControlFlow    = false; break;
                    case "--encrypt-strings": settings.EncryptStrings = true;  break;
                    case "--luac":
                        // handled externally via PATH; skip next arg
                        i++;
                        break;
                }
            }

            bool ok = ObfuscatorRunner.Obfuscate(outDir, input, settings, out string error);

            if (ok)
            {
                string result = Path.Combine(outDir, "out.lua");
                if (File.Exists(result))
                    File.Move(result, output, overwrite: true);
                Console.WriteLine($"Done! -> {output}");
            }
            else
            {
                Console.Error.WriteLine("Obfuscation failed:");
                Console.Error.WriteLine(error);
                Environment.Exit(1);
            }
        }
    }
}