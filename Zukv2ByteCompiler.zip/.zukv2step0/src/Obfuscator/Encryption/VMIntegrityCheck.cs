namespace zukv2.Obfuscator.Encryption
{
	public class VMIntegrityCheck
	{
			
	}
}