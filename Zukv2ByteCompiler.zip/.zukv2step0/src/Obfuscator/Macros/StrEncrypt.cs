namespace zukv2.Obfuscator.Macros
{
    public class StrEncrypt
    {
        
    }
}