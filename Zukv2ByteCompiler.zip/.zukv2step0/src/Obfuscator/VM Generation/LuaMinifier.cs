using System;
using System.Text;
using System.Text.RegularExpressions;

namespace zukv2.Obfuscator.VM_Generation
{
    /// <summary>
    /// High-performance Lua/Luau Minifier.
    /// Specifically tuned for VM headers and auto-generated boilerplate.
    /// </summary>
    public static class LuaMinifier
    {
        /// <summary>
        /// Minifies Lua source by removing comments and collapsing non-essential whitespace.
        /// Architecture: Single-pass literal protection followed by optimized regex substitution.
        /// </summary>
        public static string Minify(string src)
        {
            if (string.IsNullOrWhiteSpace(src)) return string.Empty;

            // ── Pass 1: Protect Literals and Strip Comments ─────────────────────
            // We use a StringBuilder to build a "Clean" version where literals are preserved
            // but comments are completely purged.
            var sb = new StringBuilder(src.Length);
            int i = 0;
            while (i < src.Length)
            {
                char c = src[i];

                // Handle String Literals (Double/Single Quotes)
                if (c == '"' || c == '\'')
                {
                    char quote = c;
                    sb.Append(c); i++;
                    while (i < src.Length)
                    {
                        char sc = src[i];
                        sb.Append(sc);
                        // Escape character: skip next char to avoid premature closing of literal
                        if (sc == '\\') { i++; if (i < src.Length) { sb.Append(src[i]); i++; } continue; }
                        if (sc == quote) { i++; break; }
                        i++;
                    }
                    continue;
                }

                // Handle Long Strings and Long Comments: [==[ ... ]==]
                if (c == '[' || (c == '-' && i + 1 < src.Length && src[i + 1] == '-'))
                {
                    bool isComment = (c == '-');
                    int startOffset = isComment ? i + 2 : i;

                    if (startOffset < src.Length && src[startOffset] == '[')
                    {
                        int eqCount = 0;
                        int j = startOffset + 1;
                        while (j < src.Length && src[j] == '=') { eqCount++; j++; }

                        if (j < src.Length && src[j] == '[')
                        {
                            string closing = "]" + new string('=', eqCount) + "]";
                            int end = src.IndexOf(closing, j + 1, StringComparison.Ordinal);
                            if (end >= 0)
                            {
                                if (!isComment) 
                                    sb.Append(src, i, (end + closing.Length) - i);
                                
                                i = end + closing.Length;
                                continue;
                            }
                        }
                    }

                    // If it was a regular line comment (not long)
                    if (isComment)
                    {
                        while (i < src.Length && src[i] != '\n' && src[i] != '\r') i++;
                        continue;
                    }
                }

                sb.Append(c);
                i++;
            }

            string result = sb.ToString();

            // ── Pass 2: Whitespace Normalization ────────────────────────────────
            // Use a single regex to collapse all vertical/horizontal whitespace into a single space.
            result = Regex.Replace(result, @"\s+", " ");

            // ── Pass 3: Symbolic Shrinking ──────────────────────────────────────
            // We use a more aggressive approach for symbols. 
            // Most non-word characters in Lua can safely lose surrounding spaces.
            
            // 1. Remove spaces around operators and delimiters that are never ambiguous.
            // Safe: ( ) { } [ ] , ; 
            result = Regex.Replace(result, @"\s?([\(\)\{\}\[\]\,;])\s?", "$1");

            // 2. Remove spaces around assignment and comparison, but preserve multi-char tokens.
            // We use lookarounds to ensure we don't break >=, <=, ==, ~=
            result = Regex.Replace(result, @"\s*([+\-*/%^#=<>~])\s*", m =>
            {
                string op = m.Groups[1].Value;
                // If it's a minus, we need to be careful with 'x - -y' -> 'x--y' (which is a comment start)
                // However, since comments are already stripped, we are safer, but 'x - -y' is still an issue
                // for the Lua parser. We leave one space if the operator is '-' and the next char is '-'.
                return op;
            });

            // 3. Special handling for Concatenation (..) and Method Calls (:)
            // Avoid mangling decimal points (e.g., '5 . 2' is not valid, but '5.2' is)
            result = Regex.Replace(result, @"\s?\.\.\s?", "..");
            result = Regex.Replace(result, @"\s?:\s?", ":");

            // ── Pass 4: Luau-Specific Fixes ──────────────────────────────────────
            // Ensure compound operators (if used in VM) aren't split
            result = Regex.Replace(result, @"([+\-*/%^]) =", "$1=");

            return result.Trim();
        }
    }
}