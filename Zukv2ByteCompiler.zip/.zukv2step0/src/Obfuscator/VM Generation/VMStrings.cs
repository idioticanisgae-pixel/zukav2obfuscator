namespace zukv2.Obfuscator.VM_Generation
{
    /// <summary>
    /// VM Template Strings. 
    /// Note: Ensure all Lua code is contained within @" " verbatim literals.
    /// </summary>
    public static class VMStrings
    {
        public static string VMP1 = @"
local GB_BYTE = string.byte;
local GB_CHAR = string.char;
local GB_SUB  = string.sub;
local GB_CONCAT = table.concat;
local GB_LDEXP = math.ldexp;
local GB_SEL = select;

local GB_BITXOR = (bit32 and bit32.bxor) or (bit and bit.bxor) or function(a, b)
    local p, c = 1, 0
    while a > 0 and b > 0 do
        local ra, rb = a % 2, b % 2
        if ra ~= rb then c = c + p end
        a, b, p = (a - ra) / 2, (b - rb) / 2, p * 2
    end
    if a < b then a = b end
    while a > 0 do
        local ra = a % 2
        if ra > 0 then c = c + p end
        a, p = (a - ra) / 2, (p * 2)
    end
    return c
end

local GB_POS = 1;
local function GB_BITS32()
    local w, x, y, z = GB_BYTE(DC_BSTR, GB_POS, GB_POS + 3);
    GB_POS = GB_POS + 4;
    local word = (z * 16777216) + (y * 65536) + (x * 256) + w;
    return GB_BITXOR(word, XOR_KEY);
end

local XKEY_LO = (XOR_KEY) % 256;
local function GS_STR(len)
    len = len or GB_BITS32();
    if len == 0 then return '' end;
    local raw = GB_SUB(DC_BSTR, GB_POS, GB_POS + len - 1);
    GB_POS = GB_POS + len;
    local buf = {};
    for i = 1, len do
        buf[i] = GB_CHAR(GB_BITXOR(GB_BYTE(raw, i), XKEY_LO));
    end
    return GB_CONCAT(buf);
end

local function GF_FLOAT()
    local l, r = GB_BITS32(), GB_BITS32();
    local sign = (r > 2147483647) and -1 or 1;
    local exp = (r / 1048576) % 2048;
    local mant = (r % 1048576) * 4294967296 + l;
    if exp == 0 then
        if mant == 0 then return sign * 0 end;
        exp = 1; mant = mant / 2^52;
    elseif exp == 2047 then
        return (mant == 0) and (sign * (1/0)) or (sign * (0/0));
    else
        mant = 1 + (mant / 2^52);
    end
    return GB_LDEXP(sign * mant, exp - 1023);
end
local GB_INT = GB_BITS32;
local function GB_BITS8()
    local b = GB_BYTE(DC_BSTR, GB_POS);
    GB_POS = GB_POS + 1;
    return b;
end
local function GB_GBIT(v, from, to)
    return math.floor(v / 2^(from - 1)) % 2^(to - from + 1);
end
local function DC_R(...) return {...}, GB_SEL('#', ...) end
local function DC_DESER() 
    local DC_INSTRS = {}; 
    local DC_FUNCS = {}; 
    local DC_LINES = {}; 
    local DC_CHUNK = {DC_INSTRS, nil, DC_FUNCS, nil, DC_LINES};
";

        public static string VMP2 = @"
local function WR_WRAP(DC_CHUNK,WR_UPVALS,WR_ENV)
    local WR_INSTR=DC_CHUNK[1];local WR_CONST=DC_CHUNK[2];local WR_PROTO=DC_CHUNK[3];local WR_PARAMS=DC_CHUNK[4];
    return function(...)
        local WR_INSTR=WR_INSTR;local WR_CONST=WR_CONST;local WR_PROTO=WR_PROTO;local WR_PARAMS=WR_PARAMS;
        local DC_R=DC_R local VM_IP=1;local VM_TOP=-1;
        local VM_VARG={};local VM_ARGS={...};
        local VM_PC=GB_SEL('#',...)-1;
        local VM_UPV={};local VM_STK={};
        for VM_IDX=0,VM_PC do 
            if(VM_IDX>=WR_PARAMS)then VM_VARG[VM_IDX-WR_PARAMS]=VM_ARGS[VM_IDX+1];
            else VM_STK[VM_IDX]=VM_ARGS[VM_IDX+1];end;
        end;
        local VM_VSZ=VM_PC-WR_PARAMS+1
        local VM_INST;local VM_ENUM;
        while true do
            VM_INST=WR_INSTR[VM_IP];VM_ENUM=VM_INST[OP_ENUM];";

        public static string VMP3 = @"
            VM_IP=VM_IP+1;
        end;
    end;
end;
return WR_WRAP(DC_DESER(),{},GB_FENV())();
end)();
";

        public static string VMP2_LI = @"
local WR_PCALL=pcall
local function WR_WRAP(DC_CHUNK,WR_UPVALS,WR_ENV)
    local WR_INSTR=DC_CHUNK[1];local WR_CONST=DC_CHUNK[2];local WR_PROTO=DC_CHUNK[3];local WR_PARAMS=DC_CHUNK[4];
    return function(...)
        local VM_IP=1;local VM_TOP=-1;
        local VM_ARGS={...};local VM_PC=GB_SEL('#',...)-1;
        local function LI_LOOP()
            local WR_INSTR=WR_INSTR;local WR_CONST=WR_CONST;local WR_PROTO=WR_PROTO;local WR_PARAMS=WR_PARAMS;
            local DC_R=DC_R local VM_VARG={};
            local VM_UPV={};local VM_STK={};
            for VM_IDX=0,VM_PC do 
                if(VM_IDX>=WR_PARAMS)then VM_VARG[VM_IDX-WR_PARAMS]=VM_ARGS[VM_IDX+1];
                else VM_STK[VM_IDX]=VM_ARGS[VM_IDX+1];end;
            end;
            local VM_VSZ=VM_PC-WR_PARAMS+1
            local VM_INST;local VM_ENUM;
            while true do 
                VM_INST=WR_INSTR[VM_IP];VM_ENUM=VM_INST[OP_ENUM];";

        public static string VMP3_LI = @"
                VM_IP=VM_IP+1;
            end;
        end;
        local LI_A,LI_B=DC_R(WR_PCALL(LI_LOOP))
        if not LI_A[1] then 
            local LI_LINE=DC_CHUNK[7][VM_IP] or '?'
            error('[IB] error at line '..LI_LINE..': '..tostring(LI_A[2]), 0)
        else 
            return GB_UNPACK(LI_A,2,LI_B)
        end;
    end;
end;
return WR_WRAP(DC_DESER(),{},GB_FENV())();
end)();
";
    }
}