@echo off
echo   zukv2 CLI - Build Script
echo.

where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: dotnet not found. Install .NET 8 SDK from:
    echo   https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

echo [*] Building zukv2 CLI...
echo.

dotnet publish zukv2.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o bin\publish

if %errorlevel% neq 0 (
    echo.
    echo BUILD FAILED. Check errors above.
    pause
    exit /b 1
)

echo [*] Copying runtime dependencies...

:: Copy luac and luajit executables next to the built exe
copy /Y ..\luac.exe      bin\publish\luac.exe
copy /Y ..\luac5.1.exe   bin\publish\luac5.1.exe
copy /Y ..\luajit.exe    bin\publish\luajit.exe
copy /Y ..\lua5.1.dll    bin\publish\lua5.1.dll
copy /Y ..\lua51.dll     bin\publish\lua51.dll

:: Copy the Lua minifier scripts that luajit needs
xcopy /E /Y /I ..\Lua bin\publish\Lua

echo.
echo ============================================
echo  BUILD SUCCESS!
echo  Output: bin\publish\zukv2.exe
echo ============================================
pause