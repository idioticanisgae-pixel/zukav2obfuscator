﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using zukv2.Bytecode_Library.Bytecode;
using zukv2.Bytecode_Library.IR;
using zukv2.Obfuscator;
using zukv2.Obfuscator.Control_Flow;
using zukv2.Obfuscator.Encryption;
using zukv2.Obfuscator.VM_Generation;

namespace zukv2
{
	public static class ObfuscatorRunner
	{
		public static Random Random = new Random();
		private static Encoding _fuckingLua = Encoding.GetEncoding(28591);

		public static bool Obfuscate(string path, string input, ObfuscationSettings settings, out string error)
		{
			try
			{
				error = "";

				string appDir = AppContext.BaseDirectory;
				bool isUnix = Environment.OSVersion.Platform == PlatformID.Unix;
				string luacExe   = isUnix ? "/usr/bin/luac"   : Path.Combine(appDir, "luac.exe");
				string luajitExe = Path.Combine(appDir, "..\\..\\..\\..", "luajit.exe");
				string dietScript = Path.Combine(appDir, "..\\..\\..\\..", "Lua", "Minifier", "luasrcdiet.lua");

				string l = Path.Combine(path, "luac.out");

				if (!File.Exists(input))
					throw new Exception("Invalid input file.");

				Console.WriteLine("Checking file...");
				Console.WriteLine(luacExe);

				string err = "";

				Process proc = new Process
				{
					StartInfo =
					{
						FileName               = luacExe,
						Arguments              = "-o \"" + l + "\" \"" + input + "\"",
						UseShellExecute        = false,
						RedirectStandardError  = true,
						RedirectStandardOutput = true
					}
				};

				proc.OutputDataReceived += (sender, args) => { err += args.Data; };
				proc.ErrorDataReceived  += (sender, args) => { err += args.Data; };
				proc.Start();
				proc.BeginOutputReadLine();
				proc.BeginErrorReadLine();
				proc.WaitForExit();
				error = err;

				if (!File.Exists(l))
					return false;

				File.Delete(l);
				string t0 = Path.Combine(path, "t0.lua");

				// Skip luasrcdiet - just copy input directly to t0
				Console.WriteLine("Copying source...");
				File.Copy(input, t0, true);

				string t1 = Path.Combine(path, "t1.lua");

				Console.WriteLine("Compiling...");

				File.WriteAllText(t1, new ConstantEncryption(settings, File.ReadAllText(t0, _fuckingLua)).EncryptStrings());

				proc = new Process
				{
					StartInfo =
					{
						FileName               = luacExe,
						Arguments              = "-o \"" + l + "\" \"" + t1 + "\"",
						UseShellExecute        = false,
						RedirectStandardError  = true,
						RedirectStandardOutput = true
					}
				};

				proc.OutputDataReceived += (sender, args) => { err += args.Data; };
				proc.ErrorDataReceived  += (sender, args) => { err += args.Data; };
				proc.Start();
				proc.BeginOutputReadLine();
				proc.BeginErrorReadLine();
				proc.WaitForExit();
				error = err;

				if (!File.Exists(l))
					return false;

				Console.WriteLine("Obfuscating...");

				Deserializer des = new Deserializer(File.ReadAllBytes(l));
				Chunk lChunk = des.DecodeFile();

				if (settings.ControlFlow)
				{
					CFContext cf = new CFContext(lChunk);
					cf.DoChunks();
				}

				Console.WriteLine("Serializing...");

				ObfuscationContext context = new ObfuscationContext(lChunk);

				string t2 = Path.Combine(path, "t2.lua");
				string c  = new Generator(context).GenerateVM(settings);
				File.WriteAllText(t2, c, _fuckingLua);

				string t3 = Path.Combine(path, "t3.lua");

				File.WriteAllText(Path.Combine(path, "out.lua"), c.Replace("\n", " "), _fuckingLua);
return true;
			}
			catch (Exception e)
			{
				Console.WriteLine("ERROR");
				Console.WriteLine(e);
				error = e.ToString();
				return false;
			}
		}
	}
}