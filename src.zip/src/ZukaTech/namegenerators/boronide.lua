-- namegenerators/boronide.lua
-- Boronide -- by Zuka
--
-- Variable names that look like chemical compound formulae.
-- Built from a curated set of element-symbol lookalike glyphs drawn from
-- Letterlike Symbols, Latin Extended, and Enclosed Alphanumerics, mixed
-- with Unicode subscript and superscript digits.
--
-- Visually: ℬₑ₃ℜₐ  ℭₙ⁴ℌₒ  ℱₑ²ℳₛ
--
-- Why it works:
--   - Reads exactly like a chemistry textbook at a glance (CaO₂, NaBr)
--   - Every glyph is a multi-byte UTF-8 sequence -- Ctrl+F finds nothing
--   - Subscript and superscript numerals are NOT the ASCII digits 0-9,
--     so regex patterns that look for identifiers break completely
--   - Decompilers that display it at all render it as indistinguishable
--     walls of "element" tokens -- no two look meaningfully different
--   - Still valid Lua 5.1 identifiers (all bytes >= 0x80)
--   - The mix of uppercase-style and lowercase-style glyphs mirrors the
--     real capitalisation conventions of element symbols (Fe, Na, Mg)

local util = require("ZukaTech.util")

-- ── GLYPH POOLS ───────────────────────────────────────────────────────────────

-- "Uppercase" element-head glyphs (Letterlike / Math Alphanumerics)
-- Used as the first character of each "element token" in the name
local UPPER = {
    "xAC", -- ℬ SCRIPT CAPITAL B    (Boron)
    "xAD", -- ℭ BLACK-LETTER CAPITAL C (Carbon)
    "xB0", -- ℰ SCRIPT CAPITAL E    (Einsteinium)
    "xB1", -- ℱ SCRIPT CAPITAL F    (Fluorine)
    "x8B", -- ℋ SCRIPT CAPITAL H    (Hydrogen)
    "x8C", -- ℌ BLACK-LETTER CAPITAL H (Hafnium)
    "x90", -- ℐ SCRIPT CAPITAL I    (Iodine)
    "x91", -- ℑ BLACK-LETTER CAPITAL I (Iridium)
    "xB3", -- ℳ SCRIPT CAPITAL M    (Magnesium)
    "x9C", -- ℜ BLACK-LETTER CAPITAL R (Radium)
    "x9D", -- ℝ DOUBLE-STRUCK CAPITAL R (Rutherford)
    "xAF", -- ℯ SCRIPT SMALL E      (electron, also Europium)
    "x93", -- ℓ SCRIPT SMALL L      (Lithium)
    "xB4", -- ℴ SCRIPT SMALL O      (Oxygen)
    "x95", -- ℕ DOUBLE-STRUCK CAPITAL N (Nitrogen)
    "x99", -- ℙ DOUBLE-STRUCK CAPITAL P (Phosphorus)
    "x9A", -- ℚ DOUBLE-STRUCK CAPITAL Q (placeholder)
    "x82", -- ℂ DOUBLE-STRUCK CAPITAL C (Calcium)
    "xA4", -- ℤ DOUBLE-STRUCK CAPITAL Z (Zinc)
    "xA6", -- Ω OHM SIGN            (Oganesson)
    "xB5", -- ℵ ALEF SYMBOL         (Aluminium lookalike)
    "xB6", -- ℶ BET SYMBOL          (Barium lookalike)
    "xB7", -- ℷ GIMEL SYMBOL        (Germanium lookalike)
    "x8F", -- ℏ PLANCK CONSTANT     (Helium)
}

-- "Lowercase" element-tail glyphs (look like the 2nd char of a symbol: Fe, Na)
-- Drawn from Modifier Letters and Latin Extended-B which are valid ident bytes
local LOWER = {
    "xA2", -- ᵢ LATIN SUBSCRIPT SMALL I
    "xA3", -- ᵣ LATIN SUBSCRIPT SMALL R
    "xA4", -- ᵤ LATIN SUBSCRIPT SMALL U
    "xA5", -- ᵥ LATIN SUBSCRIPT SMALL V
    "xA6", -- ᵦ GREEK SUBSCRIPT SMALL BETA (looks like b)
    "xA7", -- ᵧ GREEK SUBSCRIPT SMALL GAMMA (looks like y)
    "xB8", -- ᵨ GREEK SUBSCRIPT SMALL RHO (looks like p)
    "xA9", -- ᵩ GREEK SUBSCRIPT SMALL PHI
    "xAA", -- ᵪ GREEK SUBSCRIPT SMALL CHI
    "xB0",     -- ʰ MODIFIER LETTER SMALL H
    "xB2",     -- ʲ MODIFIER LETTER SMALL J
    "xB3",     -- ʳ MODIFIER LETTER SMALL R  (wait, same as ᵣ visually)
    "xB7",     -- ʷ MODIFIER LETTER SMALL W
    "xB8",     -- ʸ MODIFIER LETTER SMALL Y
    "xB4", -- ᴴ MODIFIER LETTER CAPITAL H
    "xB5", -- ᴵ MODIFIER LETTER CAPITAL I
    "xB6", -- ᴶ MODIFIER LETTER CAPITAL J
    "xB7", -- ᴷ MODIFIER LETTER CAPITAL K
    "xB8", -- ᴸ MODIFIER LETTER CAPITAL L
    "xBA", -- ᴺ MODIFIER LETTER CAPITAL N
    "xBC", -- ᴼ MODIFIER LETTER CAPITAL O
    "xBE", -- ᴾ MODIFIER LETTER CAPITAL P
    "xBF", -- ᴿ MODIFIER LETTER CAPITAL R
    "x80", -- ᵀ MODIFIER LETTER CAPITAL T
    "x81", -- ᵁ MODIFIER LETTER CAPITAL U
    "x82", -- ᵂ MODIFIER LETTER CAPITAL W
}

-- Subscript digits (U+2080–U+2089) — look like the stoichiometric numbers
-- in a chemical formula: H₂O, CO₂, Fe₃O₄
local SUBSCRIPT = {
    "x80",
    "x81",
    "x82",
    "x83",
    "x84",
    "x85", 
    "x86",
    "x87",
    "x88",
    "x89",
}

-- Superscript digits (U+00B9, U+00B2, U+00B3, U+2074–U+2079)
-- Appear as charge indicators in ionic formulae: Ca²⁺, Fe³⁺
local SUPERSCRIPT = {
    "\xC2\xB9",     -- ¹ U+00B9
    "\xC2\xB2",     -- ² U+00B2
    "\xC2\xB3",     -- ³ U+00B3
    "\xE2\x81\xB4", -- ⁴ U+2074
    "\xE2\x81\xB5", -- ⁵ U+2075
    "\xE2\x81\xB6", -- ⁶ U+2076
    "\xE2\x81\xB7", -- ⁷ U+2077
    "\xE2\x81\xB8", -- ⁸ U+2078
    "\xE2\x81\xB9", -- ⁹ U+2079
}

-- ── CONFIG ────────────────────────────────────────────────────────────────────

-- How many "element tokens" make up each name (each token = UPPER + 0-1 LOWER)
local MIN_TOKENS = 2
local MAX_TOKENS = 4

-- Probability knobs (expressed as modulo thresholds against the prng output)
-- Lower = less likely
local LOWER_CHANCE     = 3  -- add a lowercase tail: prng % LOWER_CHANCE == 0  => ~33%
local SUBSCRIPT_CHANCE = 2  -- add subscript digit after token: prng % 2 == 0  => 50%
local SUPER_CHANCE     = 5  -- add superscript digit: prng % SUPER_CHANCE == 0 => 20%

-- ── STATE (shuffled in prepare) ───────────────────────────────────────────────

local upperOrder = {}
local lowerOrder = {}
local subOrder   = {}
local supOrder   = {}
local seed       = 0

-- ── PRNG (Lua 5.1 safe, no bitwise ops) ──────────────────────────────────────

local function prng(n)
    -- Wang hash variant seeded per-build
    n = (n * 2654435761 + seed) % 0x100000000
    -- manual xor with shift-16 equivalent
    local hi     = math.floor(n / 65536)
    local result = 0
    local bit    = 1
    local x, y   = n, hi
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then result = result + bit end
        x   = math.floor(x / 2)
        y   = math.floor(y / 2)
        bit = bit * 2
    end
    return result
end

-- ── GENERATOR ─────────────────────────────────────────────────────────────────

local function generateName(id, scope)
    local tokenCount = MIN_TOKENS + (prng(id) % (MAX_TOKENS - MIN_TOKENS + 1))
    local name       = ""

    for t = 0, tokenCount - 1 do
        local base = t * 100  -- unique offset per token so prng calls don't collide

        -- Uppercase head glyph (always present)
        local ui   = (prng(id * 7 + base) % #upperOrder) + 1
        name       = name .. UPPER[upperOrder[ui]]

        -- Optional lowercase tail glyph (~33% of tokens)
        if prng(id * 3 + base + 1) % LOWER_CHANCE == 0 then
            local li = (prng(id * 11 + base + 2) % #lowerOrder) + 1
            name     = name .. LOWER[lowerOrder[li]]
        end

        -- Optional subscript digit after this token (~50%)
        if prng(id * 5 + base + 3) % SUBSCRIPT_CHANCE == 0 then
            local si = (prng(id * 13 + base + 4) % #subOrder) + 1
            name     = name .. SUBSCRIPT[subOrder[si]]
        end

        -- Optional superscript digit (~20%, only if no subscript on this token
        -- to avoid the double-numeral look being too busy)
        if prng(id * 17 + base + 5) % SUPER_CHANCE == 0 and
           prng(id * 5 + base + 3) % SUBSCRIPT_CHANCE ~= 0 then
            local si = (prng(id * 19 + base + 6) % #supOrder) + 1
            name     = name .. SUPERSCRIPT[supOrder[si]]
        end
    end

    -- Names must start with a letter/underscore byte >= 0x80 — all our UPPER
    -- glyphs satisfy this (first byte is always 0xE2 or 0xC2), so no underscore
    -- prefix needed. But the pipeline may expect one; add it to be safe.
    return "_" .. name
end

-- ── PREPARE ───────────────────────────────────────────────────────────────────

local function prepare(ast)
    seed = math.random(0, 0xFFFFFF)

    upperOrder = {}
    lowerOrder = {}
    subOrder   = {}
    supOrder   = {}

    for i = 1, #UPPER       do upperOrder[i] = i end
    for i = 1, #LOWER       do lowerOrder[i] = i end
    for i = 1, #SUBSCRIPT   do subOrder[i]   = i end
    for i = 1, #SUPERSCRIPT do supOrder[i]   = i end

    util.shuffle(upperOrder)
    util.shuffle(lowerOrder)
    util.shuffle(subOrder)
    util.shuffle(supOrder)
end

-- ── EXPORT ────────────────────────────────────────────────────────────────────

return {
    generateName = generateName,
    prepare      = prepare,
}
