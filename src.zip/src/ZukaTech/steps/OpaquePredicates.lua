-- Obfuscation Step: Opaque Predicates & Control-Flow Junk
--
-- Tier 1 Upgrade #3: Injects opaque predicates — conditions that are ALWAYS
-- true (or false) but are computationally difficult for a static analyser to
-- prove, forcing any analyst to symbolically evaluate complex math.
--
-- Predicate catalogue (always-true examples):
--   • sin(x)^2 + cos(x)^2 > 0.5          (Pythagorean identity ≡ 1)
--   • (n*(n+1)) % 2 == 0                  (product of consecutive ints)
--   • floor(sqrt(n*n)) == n               (perfect square)
--   • (a^3 + b^3) ~= (a+b)^3 - 3*a*b*(a+b)  (always FALSE for a,b≠0 → negated)
--   • (x % p) * (p - (x % p)) >= 0        (non-negative by def)
--
-- Each predicate is wrapped around dead blocks so decompilers see legitimate
-- if/else branches but can never simplify the tree without solving the math.

local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Scope    = require("ZukaTech.scope")
local visitast = require("ZukaTech.visitast")
local Parser   = require("ZukaTech.parser")
local Enums    = require("ZukaTech.enums")

local AstKind    = Ast.AstKind
local LuaVersion = Enums.LuaVersion

local OpaquePredicates       = Step:extend()
OpaquePredicates.Description = "Injects always-true/false opaque predicates (trig identities, number theory) to prevent static control-flow analysis."
OpaquePredicates.Name        = "Opaque Predicates"

OpaquePredicates.SettingsDescriptor = {
    Treshold = {
        name    = "Treshold",
        description = "Probability that each function block gets a predicate injection",
        type    = "number",
        default = 0.75,
        min     = 0,
        max     = 1,
    },
    InjectionsPerBlock = {
        name    = "InjectionsPerBlock",
        description = "Max predicates injected per block",
        type    = "number",
        default = 2,
        min     = 1,
        max     = 6,
    },
}

function OpaquePredicates:init(settings) end

-- ── predicate generators ─────────────────────────────────────────────────────
--
-- FIX: All original predicates used only compile-time constants, making them
-- trivially foldable by any deobfuscator that runs constant propagation.
--
-- New predicates use runtime values (os.clock, tick, math.random, select('#',...))
-- that are unknowable at static analysis time, forcing a full symbolic executor
-- to evaluate them. All predicates still evaluate to TRUE at runtime.

-- ── predicate generator ──────────────────────────────────────────────────────
-- Instead of a fixed list of template strings (fingerprintable after one
-- analysis pass), predicates are COMPOSED procedurally each call from a set
-- of primitive building blocks. Every compilation and every injection site
-- produces structurally different source, so no two obfuscated outputs share
-- a recognisable predicate pattern.
--
-- All composed predicates evaluate to TRUE at runtime.

-- Primitive: an expression that always evaluates to a known integer N at
-- runtime but is opaque to static analysis.
local function opaqueInt(n)
    local kind = math.random(1, 6)
    if kind == 1 then
        -- tick()*0 + n  (tick/os.clock is a runtime-only value)
        return string.format(
            "(math.floor((tick and tick() or (os and os.clock and os.clock()) or 0) * 0) + %d)", n)
    elseif kind == 2 then
        -- math.floor(math.random()*0) + n
        return string.format("(math.floor(math.random() * 0) + %d)", n)
    elseif kind == 3 then
        -- select('#', n, n, n) returns 3; so select('#',...)*0 + n == n
        local rep = math.random(2, 5)
        local args = {}
        for _ = 1, rep do args[#args+1] = tostring(math.random(1,999)) end
        return string.format(
            "(select('#', %s) * 0 + %d)", table.concat(args, ","), n)
    elseif kind == 4 then
        -- #tostring(n) > 0 → always; use as multiplier: (#tostring(n)>0 and n or 0)
        -- Wrap so result is n: (n + math.floor(math.random()*0))
        return string.format("(%d + math.floor(math.random() * 0))", n)
    elseif kind == 5 then
        -- pcall always returns true for an empty function; true→1 in numeric ctx
        -- (pcall(function()end) and n or 0) == n
        return string.format("(pcall(function()end) and %d or 0)", n)
    else
        -- rawlen on a table with exactly n entries
        -- building the table inline is too slow; fall back to simple tick form
        return string.format(
            "(math.floor((tick and tick() or 0) * 0) + %d)", n)
    end
end

-- Compose a full boolean predicate that is always TRUE.
local function generatePredicate()
    local style = math.random(1, 7)

    if style == 1 then
        -- opaqueInt(a) == a
        local a = math.random(100, 99999)
        return string.format("%s == %d", opaqueInt(a), a)

    elseif style == 2 then
        -- opaqueInt(a) + opaqueInt(b) == a + b
        local a = math.random(10, 9999)
        local b = math.random(10, 9999)
        return string.format("%s + %s == %d",
            opaqueInt(a), opaqueInt(b), a + b)

    elseif style == 3 then
        -- opaqueInt(a) * opaqueInt(1) == a   (multiply by opaque 1)
        local a = math.random(2, 9999)
        return string.format("%s * %s == %d",
            opaqueInt(a), opaqueInt(1), a)

    elseif style == 4 then
        -- type(opaqueInt(n)) == "number"  — type() is a runtime call
        local n = math.random(1, 9999)
        return string.format('type(%s) == "number"', opaqueInt(n))

    elseif style == 5 then
        -- opaqueInt(a) >= opaqueInt(b) where a > b always
        local b = math.random(1, 5000)
        local a = b + math.random(1, 5000)
        return string.format("%s >= %s", opaqueInt(a), opaqueInt(b))

    elseif style == 6 then
        -- math.max(opaqueInt(a), opaqueInt(a-1)) == a
        local a = math.random(50, 9999)
        return string.format("math.max(%s, %s) == %d",
            opaqueInt(a), opaqueInt(a - 1), a)

    else
        -- (function(...) return select('#',...) >= 0 end)(opaqueInt(n))
        -- The IIFE wrapper makes the analyser track a new scope.
        local n = math.random(1, 500)
        return string.format(
            "(function(...) return select('#',...) >= 0 end)(%s)", opaqueInt(n))
    end
end

-- ── dead block content (realistic-looking but unreachable) ───────────────────

local function deadBlock(scope)
    -- A block that looks like it does work but is inside an always-false branch
    local innerScope = Scope:new(scope)
    local stmts = {}

    -- local _dX = random_number
    local dVar = innerScope:addVariable()
    table.insert(stmts, Ast.LocalVariableDeclaration(innerScope, {dVar},
        {Ast.NumberExpression(math.random(1, 65535))}))

    -- _dX = _dX * random + random
    table.insert(stmts, Ast.AssignmentStatement(
        {Ast.AssignmentVariable(innerScope, dVar)},
        {Ast.AddExpression(
            Ast.MulExpression(
                Ast.VariableExpression(innerScope, dVar),
                Ast.NumberExpression(math.random(2, 127))
            ),
            Ast.NumberExpression(math.random(1, 255))
        )}
    ))

    -- _dX = nil
    table.insert(stmts, Ast.AssignmentStatement(
        {Ast.AssignmentVariable(innerScope, dVar)},
        {Ast.NilExpression()}
    ))

    return Ast.Block(stmts, innerScope)
end

-- ── build an if statement with opaque predicate ──────────────────────────────

local function buildPredicateStatement(parentScope, parser)
    local pred = generatePredicate()

    -- Wrap: if <pred> then <real empty block> else <dead block> end
    -- The "real" branch is empty; the dead branch has junk.
    -- Analyst sees an if/else and must evaluate pred to know which runs.
    local code = string.format("if %s then end", pred)
    local ok, parsed = pcall(function()
        return parser:parse(code)
    end)
    if not ok then return nil end

    local ifStat = parsed.body.statements[1]
    if ifStat then
        ifStat.elseBody = deadBlock(parentScope)
        if ifStat.body then
            ifStat.body.scope:setParent(parentScope)
        end
    end
    return ifStat
end

-- ── apply ────────────────────────────────────────────────────────────────────

function OpaquePredicates:apply(ast, pipeline)
    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })

    visitast(ast, nil, function(node, data)
        if node.kind ~= AstKind.Block then return end
        if not node.isFunctionBlock then return end
        if math.random() > self.Treshold then return end
        if #node.statements == 0 then return end

        local count = math.random(1, self.InjectionsPerBlock)
        for _ = 1, count do
            local stat = buildPredicateStatement(node.scope, parser)
            if stat then
                -- Insert at a random position that isn't after return/break
                local insertPos = math.random(1, #node.statements)
                -- Don't insert after a return
                local last = node.statements[#node.statements]
                if last and (last.kind == AstKind.ReturnStatement
                          or last.kind == AstKind.BreakStatement) then
                    insertPos = math.max(1, #node.statements - 1)
                end
                table.insert(node.statements, insertPos, stat)
            end
        end
    end)

    return ast
end

return OpaquePredicates
