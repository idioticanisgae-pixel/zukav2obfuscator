-- Obfuscation Step: Encrypt Strings
local Step = require("ZukaTech.step")
local Ast = require("ZukaTech.ast")
local Scope = require("ZukaTech.scope")
local RandomStrings = require("ZukaTech.randomStrings")
local Parser = require("ZukaTech.parser")
local Enums = require("ZukaTech.enums")
local logger = require("logger")
local visitast = require("ZukaTech.visitast");
local util     = require("ZukaTech.util")
local AstKind = Ast.AstKind;

local EncryptStrings = Step:extend()
EncryptStrings.Description = "This Step will encrypt strings within your Program."
EncryptStrings.Name = "Encrypt Strings"

EncryptStrings.SettingsDescriptor = {}

function EncryptStrings:init(settings) end


function EncryptStrings:CreateEncrypionService()
	local usedSeeds = {};

	local key_a = math.random(1, 255)
	local key_b = math.random(0, 511)
	local key_c = math.random(0, 8191)
	local key_d = math.random(0, 65535)

	local floor = math.floor

	local function bxor(a, b)
		local r, m = 0, 1
		while a > 0 or b > 0 do
			local ra = a % 2
			local rb = b % 2
			if ra ~= rb then r = r + m end
			a = floor(a / 2)
			b = floor(b / 2)
			m = m * 2
		end
		return r
	end

	-- Per-compile random multiplier drawn from a curated list of LCG multipliers
	-- with good spectral properties. Avoids the fingerprint of always emitting 1664525.
	local LCG_MUL_POOL = {
		1664525, 1103515245, 214013, 6364136223846793005 % 2^32,
		1140671485, 22695477, 1664525 + math.random(0,512)*2,
		134775813, 1284865837, 4294967118
	}
	local lcg_mul = LCG_MUL_POOL[math.random(#LCG_MUL_POOL)]
	local lcg_add = key_d * 2 + 1
	local lcg_mod = 2^32

	local state_lcg = 0
	local rot_state = 1

	local prev_bytes = {}

	-- NOTE: set_seed and next_rand_32 use the same ROT constants that will be
	-- emitted into the runtime decryptor (ROT_MOD/ROT_MUL/ROT_ADD/MIX_FACTOR).
	-- These are defined later in this function after the pool selections.
	-- We forward-declare them as upvalues and fill after the pool picks below.
	local _ROT_MOD, _ROT_MUL, _ROT_ADD, _MIX_FACTOR

	local function set_seed(seed)
		state_lcg = seed % lcg_mod
		rot_state  = (seed % _ROT_MOD) + 1
		prev_bytes = {}
	end

	local function gen_seed()
		local seed
		repeat
			seed = math.random(0, 2147483647)
		until not usedSeeds[seed]
		usedSeeds[seed] = true
		return seed
	end

	local function next_rand_32()
		state_lcg = (state_lcg * lcg_mul + lcg_add) % lcg_mod
		rot_state = (rot_state * _ROT_MUL + _ROT_ADD) % _ROT_MOD + 1
		local mixed = (state_lcg + rot_state * _MIX_FACTOR) % lcg_mod
		return floor(mixed)
	end

	local function get_next_byte()
		if #prev_bytes == 0 then
			local r   = next_rand_32()
			local b1  = r % 256
			local b2  = floor(r / 256) % 256
			local b3  = floor(r / 65536) % 256
			local b4  = floor(r / 16777216) % 256
			prev_bytes = { b1, b2, b3, b4 }
		end
		return table.remove(prev_bytes)
	end

	-- ROLL_CONST is randomized per compilation so the feedback byte never
	-- produces the same keystream signature across two obfuscation runs.
	-- Must be odd and in a range that keeps the feedback well-distributed mod 256.
	local _roll_pool = {17,23,29,37,41,47,53,59,67,71,79,83,89,97,101,107,
	                    113,127,131,137,149,157,163,167,173,179,191,197,211,223,229,233,239,251}
	local ROLL_CONST = _roll_pool[math.random(#_roll_pool)]

	local function encrypt(str)
		local seed = gen_seed()
		set_seed(seed)
		local len = #str
		local out = {}
		local roll = key_a
		for i = 1, len do
			local b = string.byte(str, i)
			local kb = get_next_byte()
			out[i] = string.char(bxor(b, bxor(kb, roll)) % 256)
			roll = (roll + b + ROLL_CONST) % 256
		end
		return table.concat(out), seed
	end

	-- FIX: factored the bxor and PRNG source strings so all 3 shapes share
	-- the same generated constants without copy-paste drift risk.
	-- All PRNG mixer constants are now randomized per-compile so the emitted
	-- bytecode never carries static fingerprints.
	local lcg_mul_s  = tostring(lcg_mul)
	local lcg_add_s  = tostring(lcg_add)
	local key_a_s    = tostring(key_a)
	local roll_s     = tostring(ROLL_CONST)

	-- rot_state mixer: (rot * ROT_MUL + ROT_ADD) % ROT_MOD + 1
	-- ROT_MOD must be prime and < 256 for byte-safety. ROT_MUL must be coprime to ROT_MOD.
	local ROT_MOD_POOL = {251, 241, 239, 233, 229, 227}
	local ROT_MOD  = ROT_MOD_POOL[math.random(#ROT_MOD_POOL)]
	local ROT_MUL_POOL = {37, 41, 43, 47, 53, 59, 61, 67}
	local ROT_MUL  = ROT_MUL_POOL[math.random(#ROT_MUL_POOL)]
	local ROT_ADD_POOL = {7, 11, 13, 17, 19, 23}
	local ROT_ADD  = ROT_ADD_POOL[math.random(#ROT_ADD_POOL)]
	-- mixed = (lcg + rot * MIX_FACTOR) % lcg_mod — MIX_FACTOR replaces hardcoded 65537
	local MIX_FACTOR_POOL = {65537, 65539, 65543, 65551, 65557, 65563}
	local MIX_FACTOR = MIX_FACTOR_POOL[math.random(#MIX_FACTOR_POOL)]

	-- Wire the forward-declared upvalues so the obfuscation-time PRNG
	-- (encrypt) uses EXACTLY the same constants that will be emitted into
	-- the runtime decryptor.  Without this the keystreams diverge → corrupt output.
	_ROT_MOD    = ROT_MOD
	_ROT_MUL    = ROT_MUL
	_ROT_ADD    = ROT_ADD
	_MIX_FACTOR = MIX_FACTOR

	local rot_mod_s    = tostring(ROT_MOD)
	local rot_mul_s    = tostring(ROT_MUL)
	local rot_add_s    = tostring(ROT_ADD)
	local mix_factor_s = tostring(MIX_FACTOR)

	-- Shared bxor source (injected into each shape, variable names differ per shape
	-- so they don't produce identical token sequences)
	local function makeBxor(a, b)
		return string.format([[
	local function %s(%s,%s)
		local r,m=0,1
		while %s>0 or %s>0 do
			local ra=%s%%2 local rb=%s%%2
			if ra~=rb then r=r+m end
			%s=_F(%s/2) %s=_F(%s/2) m=m*2
		end
		return r
	end]], a, a, b, a, b, a, b, a, a, b, b)
	end

	local function genCode()
		local shape = math.random(1, 3)

		if shape == 1 then
		local code = [[
do
	local floor = math.floor
	local random = math.random
	local remove = table.remove
	local char   = string.char
	local byte   = string.byte
	local len    = string.len
	local _F     = math.floor

	local lcg_mul  = ]] .. lcg_mul_s .. [[

	local lcg_add  = ]] .. lcg_add_s .. [[

	local lcg_mod  = 2^32
	local key_a    = ]] .. key_a_s .. [[

	]] .. makeBxor("bxor", "b") .. [[

	local state_lcg = 0
	local rot_state  = 1
	local prev_bytes = {}

	local charmap = {}
	local nums = {}
	for i = 1, 256 do nums[i] = i end
	repeat
		local idx = random(1, #nums)
		local n   = remove(nums, idx)
		charmap[n] = char(n - 1)
	until #nums == 0

	local function next_rand_32()
		state_lcg = (state_lcg * lcg_mul + lcg_add) % lcg_mod
		rot_state  = (rot_state * ]] .. rot_mul_s .. [[ + ]] .. rot_add_s .. [[) % ]] .. rot_mod_s .. [[ + 1
		return floor((state_lcg + rot_state * ]] .. mix_factor_s .. [[) % lcg_mod)
	end

	local function get_next_byte()
		if #prev_bytes == 0 then
			local r  = next_rand_32()
			local b1 = r % 256
			local b2 = floor(r / 256) % 256
			local b3 = floor(r / 65536) % 256
			local b4 = floor(r / 16777216) % 256
			prev_bytes = { b1, b2, b3, b4 }
		end
		return remove(prev_bytes)
	end

	local realStrings = {}
	STRINGS = setmetatable({}, {
		__index = realStrings,
		__metatable = nil,
	})

	function DECRYPT(str, seed)
		local cache = realStrings
		if not cache[seed] then
			prev_bytes  = {}
			state_lcg   = seed % lcg_mod
			rot_state   = (seed % ]] .. rot_mod_s .. [[) + 1
			local slen  = len(str)
			local roll  = key_a
			local parts = {}
			local cm    = charmap
			for i = 1, slen do
				local enc = byte(str, i)
				local kb  = get_next_byte()
				local dec = bxor(enc, bxor(kb, roll)) % 256
				parts[i]  = cm[dec + 1]
				roll       = (roll + dec + ]] .. roll_s .. [[) % 256
			end
			cache[seed] = table.concat(parts)
		end
		return seed
	end
end]]
		return code

		elseif shape == 2 then
		local code = [[
do
	local _f = math.floor
	local _r = math.random
	local _rm = table.remove
	local _ch = string.char
	local _by = string.byte
	local _ln = string.len
	local _F  = math.floor

	local _lm  = ]] .. lcg_mul_s .. [[

	local _la  = ]] .. lcg_add_s .. [[

	local _lmod = 2^32
	local _ka   = ]] .. key_a_s .. [[

	]] .. makeBxor("_bx", "_b") .. [[

	local _sl,_rs,_pb=0,1,{}
	local _cm={}
	local _ns={}
	for i=1,256 do _ns[i]=i end
	repeat
		local idx=_r(1,#_ns)
		local n=_rm(_ns,idx)
		_cm[n]=_ch(n-1)
	until #_ns==0

	local function _nr()
		_sl=(_sl*_lm+_la)%_lmod
		_rs=(_rs*]] .. rot_mul_s .. [[+]] .. rot_add_s .. [[)%]] .. rot_mod_s .. [[+1
		return _f((_sl+_rs*]] .. mix_factor_s .. [[)%_lmod)
	end
	local function _nb()
		if #_pb==0 then
			local rv=_nr()
			_pb={rv%256,_f(rv/256)%256,_f(rv/65536)%256,_f(rv/16777216)%256}
		end
		return _rm(_pb)
	end

	local _cache={}
	local function _dec(str,seed)
		if not _cache[seed] then
			_pb={} _sl=seed%_lmod _rs=(seed%]] .. rot_mod_s .. [[)+1
			local slen=_ln(str) local roll=_ka local parts={}
			for i=1,slen do
				local enc=_by(str,i) local kb=_nb()
				local dec=_bx(enc,_bx(kb,roll))%256
				parts[i]=_cm[dec+1]
				roll=(roll+dec+]] .. roll_s .. [[)%256
			end
			_cache[seed]=table.concat(parts)
		end
		return seed
	end

	STRINGS = setmetatable({}, {
		__index = function(_, k) return _cache[k] end,
		__metatable = nil,
	})
	function DECRYPT(s,k) return _dec(s,k) end
end]]
		return code

		else
		local code = [[
do
	local _M={}
	local _F=math.floor
	local _R=math.random
	local _RM=table.remove
	local _C=string.char
	local _B=string.byte
	local _L=string.len

	local _MUL=]] .. lcg_mul_s .. [[

	local _ADD=]] .. lcg_add_s .. [[

	local _MOD=2^32
	local _KA=]] .. key_a_s .. [[

	]] .. makeBxor("_XR", "_XV") .. [[

	local _SL,_RT,_PB=0,1,{}
	local _MAP={}
	local _TMP={}
	for i=1,256 do _TMP[i]=i end
	repeat
		local i=_R(1,#_TMP) local n=_RM(_TMP,i) _MAP[n]=_C(n-1)
	until #_TMP==0

	local function _NX()
		_SL=(_SL*_MUL+_ADD)%_MOD
		_RT=(_RT*]] .. rot_mul_s .. [[+]] .. rot_add_s .. [[)%]] .. rot_mod_s .. [[+1
		return _F((_SL+_RT*]] .. mix_factor_s .. [[)%_MOD)
	end
	local function _NB()
		if #_PB==0 then
			local v=_NX()
			_PB={v%256,_F(v/256)%256,_F(v/65536)%256,_F(v/16777216)%256}
		end
		return _RM(_PB)
	end

	_M._cache={}
	_M.dec=function(str,seed)
		if not _M._cache[seed] then
			_PB={} _SL=seed%_MOD _RT=(seed%]] .. rot_mod_s .. [[)+1
			local n=_L(str) local roll=_KA local p={}
			for i=1,n do
				local e=_B(str,i) local k=_NB()
				local d=_XR(e,_XR(k,roll))%256
				p[i]=_MAP[d+1] roll=(roll+d+]] .. roll_s .. [[)%256
			end
			_M._cache[seed]=table.concat(p)
		end
		return seed
	end

	STRINGS=setmetatable({},{
		__index=function(_,k) return _M._cache[k] end,
		__metatable=nil,
	})
	function DECRYPT(s,k) return _M.dec(s,k) end
end]]
		return code
		end
	end

	return {
		encrypt  = encrypt,
		genCode  = genCode,
		key_a    = key_a,
		lcg_mul  = lcg_mul,
		lcg_add  = lcg_add,
	}
end

function EncryptStrings:apply(ast, pipeline)
	local Encryptor = self:CreateEncrypionService()

	local code   = Encryptor.genCode()
	local newAst = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code)
	local doStat = newAst.body.statements[1]

	local scope      = ast.body.scope
	local decryptVar = scope:addVariable()
	local stringsVar = scope:addVariable()

	doStat.body.scope:setParent(ast.body.scope)

	visitast(newAst, nil, function(node, data)
		if node.kind == AstKind.FunctionDeclaration then
			if node.scope:getVariableName(node.id) == "DECRYPT" then
				data.scope:removeReferenceToHigherScope(node.scope, node.id)
				data.scope:addReferenceToHigherScope(scope, decryptVar)
				node.scope = scope
				node.id    = decryptVar
			end
		end
		if node.kind == AstKind.AssignmentVariable or node.kind == AstKind.VariableExpression then
			if node.scope:getVariableName(node.id) == "STRINGS" then
				data.scope:removeReferenceToHigherScope(node.scope, node.id)
				data.scope:addReferenceToHigherScope(scope, stringsVar)
				node.scope = scope
				node.id    = stringsVar
			end
		end
	end)

visitast(ast, nil, function(node, data)
    if node.kind == AstKind.StringExpression then
        data.scope:addReferenceToHigherScope(scope, stringsVar)
        data.scope:addReferenceToHigherScope(scope, decryptVar)
        local encrypted, seed = Encryptor.encrypt(node.value)
        return Ast.IndexExpression(
            Ast.VariableExpression(scope, stringsVar),
            Ast.FunctionCallExpression(Ast.VariableExpression(scope, decryptVar), {
                Ast.StringExpression(encrypted),
                Ast.NumberExpression(seed),
            })
        )
    end
end)

	table.insert(ast.body.statements, 1, doStat)
	table.insert(ast.body.statements, 1, Ast.LocalVariableDeclaration(scope, util.shuffle{ decryptVar, stringsVar }, {}))
	return ast
end

return EncryptStrings