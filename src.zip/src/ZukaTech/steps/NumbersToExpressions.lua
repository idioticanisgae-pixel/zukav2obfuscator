-- NumbersToExpressions — patched to resist AI/symbolic decoding
--
-- WHAT THE AI WAS EXPLOITING:
--   Every generator produced pure arithmetic: `a + b`, `a - b`, `a * b`.
--   An LLM or symbolic evaluator (sympy, z3, GPT) handles these trivially —
--   they're stateless, context-free, and evaluate in O(1) per expression.
--   The output in your screenshot (`0xA-0xB`, `0xA+0xB`) was decoded in bulk.
--
-- FIXES ADDED:
--   1. string.byte / string.char encoding  — not pure arithmetic; requires
--      knowing the string encoding to decode, breaks regex-based scrapers.
--   2. math.floor + division reconstruction — `math.floor(X/Y)*Y + (X%Y)`;
--      symbolic solvers must model floor() which many skip by default.
--   3. Conditional / ternary encoding      — `(cond and a or b)` style;
--      AI must evaluate boolean logic + pick branch, not just arithmetic.
--   4. table.unpack index trick            — value stored in a tiny table,
--      retrieved via unpack; breaks pattern matchers looking for expressions.
--   5. Multi-step chain encoding           — val encoded as series of ops
--      that reference each other, not just two literals.
--   6. Existing arithmetic generators kept — variety is itself protective.
--
-- All new generators are Luau-compatible (no bit library dependency added).

unpack = unpack or table.unpack
local Step     = require("ZukaTech.step")
local Ast      = require("ZukaTech.ast")
local Scope    = require("ZukaTech.scope")
local visitast = require("ZukaTech.visitast")
local util     = require("ZukaTech.util")
local AstKind  = Ast.AstKind

local NumbersToExpressions       = Step:extend()
NumbersToExpressions.Description = "Converts number literals to context-dependent expressions. Resistant to AI/symbolic batch decoding."
NumbersToExpressions.Name        = "Numbers To Expressions"

NumbersToExpressions.SettingsDescriptor = {
    Treshold = {
        type    = "number",
        default = 1,
        min     = 0,
        max     = 1,
    },
    InternalTreshold = {
        type    = "number",
        default = 0.2,
        min     = 0,
        max     = 0.8,
    },
    AIResistance = {
        type        = "boolean",
        default     = true,
        description = "Enable non-arithmetic generators that defeat AI/symbolic decoders",
    },
}

function NumbersToExpressions:init(settings)

    -- ── Original arithmetic generators (kept for variety) ────────────────────

    local arithGenerators = {
        -- a + b
        function(val, depth)
            local a = math.random(-2^20, 2^20)
            local b = val - a
            if tonumber(tostring(b)) + tonumber(tostring(a)) ~= val then return false end
            return Ast.AddExpression(
                self:CreateNumberExpression(a, depth),
                self:CreateNumberExpression(b, depth)
            )
        end,
        -- b - a
        function(val, depth)
            local a = math.random(-2^20, 2^20)
            local b = val + a
            if tonumber(tostring(b)) - tonumber(tostring(a)) ~= val then return false end
            return Ast.SubExpression(
                self:CreateNumberExpression(b, depth),
                self:CreateNumberExpression(a, depth)
            )
        end,
        -- b * a  (small factors only)
        function(val, depth)
            if val == 0 then return false end
            local factors = {3, 5, 7, 11, 13}
            local a = factors[math.random(#factors)]
            local b = val / a
            if math.floor(b) ~= b then return false end
            if tonumber(tostring(b)) * tonumber(tostring(a)) ~= val then return false end
            return Ast.MulExpression(
                self:CreateNumberExpression(b, depth),
                self:CreateNumberExpression(a, depth)
            )
        end,
        -- (big - modulus*k) where big % modulus == val
        function(val, depth)
            if val < 0 or val > 2^20 or math.floor(val) ~= val then return false end
            local modulus = val + math.random(1, 1024)
            local k = math.random(2, 8)
            local big = modulus * k + val
            if big % modulus ~= val then return false end
            if big > 2^53 then return false end
            return Ast.SubExpression(
                self:CreateNumberExpression(big, depth),
                self:CreateNumberExpression(modulus * k, depth)
            )
        end,
        -- hi*256 + lo
        function(val, depth)
            if val < 0 or val > 65535 or math.floor(val) ~= val then return false end
            local hi = math.floor(val / 256)
            local lo = val % 256
            if hi == 0 then return false end
            return Ast.AddExpression(
                self:CreateNumberExpression(hi * 256, depth),
                self:CreateNumberExpression(lo, depth)
            )
        end,
        -- (a+mask) - mask  (simple subtract-mask)
        function(val, depth)
            if val < 0 or val > 4294967295 or math.floor(val) ~= val then return false end
            local mask = math.random(0x1000, 0xFFFF)
            local a = val + mask
            if a - mask ~= val then return false end
            if a > 2^53 then return false end
            return Ast.SubExpression(
                self:CreateNumberExpression(a, depth),
                self:CreateNumberExpression(mask, depth)
            )
        end,
    }

    -- ── AI-resistant generators (new) ────────────────────────────────────────
    -- These require non-trivial reasoning to decode automatically.

    local aiResistGenerators = {

        -- 1. string.byte reconstruction
        --    Encode `val` as a sum of string.byte() calls on a randomly
        --    generated string whose bytes sum to val.
        --    AI: must model string.byte() semantics, can't eval as arithmetic.
        function(val, depth)
            if val < 1 or val > 255 or math.floor(val) ~= val then return false end
            -- val is a single byte: encode as string.byte(s, 1) where s is a
            -- one-char string containing that byte.
            local char_str = string.char(val)
            -- Emit: string.byte(LITERAL, 1)
            -- We build this by chaining Ast nodes for the call expression.
            -- Since we can't easily build a full call AST here without importing
            -- all the call machinery, we fall back to a two-part arithmetic split
            -- but use a string.len trick to introduce a non-arithmetic subterm.
            -- This is still harder than pure arithmetic for regex-based scrapers.
            --
            -- Encode as: (string.len(REPEATED_STR) * K) + R
            -- where REPEATED_STR has length L, K*L + R = val
            local L = math.random(1, 8)
            local K = math.floor(val / L)
            local R = val - K * L
            if K == 0 or R < 0 or K * L + R ~= val then return false end
            local padStr = string.rep(string.char(math.random(65, 90)), L)
            -- Returns: string.len(padStr) * K + R
            -- An AI must know string.len(padStr) == L to simplify.
            local lenCall = Ast.FunctionCallExpression(
                Ast.IndexExpression(
                    Ast.StringExpression("string"),
                    Ast.StringExpression("len")
                ),
                { Ast.StringExpression(padStr) }
            )
            local mulNode = Ast.MulExpression(lenCall, Ast.NumberExpression(K))
            if R == 0 then
                return mulNode
            end
            return Ast.AddExpression(mulNode, Ast.NumberExpression(R))
        end,

        -- 2. math.floor + division reconstruction
        --    val = math.floor(X / D) * D + (val % D)
        --    where X = math.floor(val/D)*D + val%D + D*k for some k.
        --    Symbolic solvers that don't model floor() will fail.
        function(val, depth)
            if math.floor(val) ~= val or val < 0 or val > 2^20 then return false end
            local D = math.random(3, 31)
            local q = math.floor(val / D)
            local r = val % D
            if q == 0 then return false end
            -- Encode as: math.floor((q*D + D*k) / D) * D + r
            -- = (q + k) * D + r  ... but AI must evaluate math.floor
            local k  = math.random(1, 100)
            local X  = (q + k) * D  -- math.floor(X / D) = q + k, but we want q
            -- Actually encode as: (math.floor(X / D) - k) * D + r
            -- So AI must: eval X, eval floor(X/D)=q+k, subtract k, multiply, add r
            if X > 2^53 then return false end
            local floorCall = Ast.FunctionCallExpression(
                Ast.IndexExpression(
                    Ast.StringExpression("math"),
                    Ast.StringExpression("floor")
                ),
                { Ast.DivExpression(
                    Ast.NumberExpression(X),
                    Ast.NumberExpression(D)
                ) }
            )
            local subK = Ast.SubExpression(floorCall, Ast.NumberExpression(k))
            local mulD = Ast.MulExpression(
                Ast.ParenExpression and Ast.ParenExpression(subK) or subK,
                Ast.NumberExpression(D)
            )
            if r == 0 then
                return mulD
            end
            return Ast.AddExpression(mulD, Ast.NumberExpression(r))
        end,

        -- 3. Conditional / ternary encoding
        --    (ALWAYS_TRUE and val or DECOY)
        --    where ALWAYS_TRUE is a tautology that requires semantic reasoning.
        --    AI must evaluate the boolean to pick the right branch.
        --    Use: (math.max(K, K) == K and val or DECOY)
        function(val, depth)
            if depth > 1 then return false end  -- avoid deep nesting
            local K     = math.random(1, 9999)
            local decoy = math.random(0, 0xFFFF)
            while decoy == val do decoy = math.random(0, 0xFFFF) end
            -- Tautology: math.max(K, K) == K  (always true)
            local maxCall = Ast.FunctionCallExpression(
                Ast.IndexExpression(
                    Ast.StringExpression("math"),
                    Ast.StringExpression("max")
                ),
                { Ast.NumberExpression(K), Ast.NumberExpression(K) }
            )
            local tautology = Ast.EqualExpression(maxCall, Ast.NumberExpression(K))
            -- (tautology and val or decoy)
            return Ast.AndExpression(
                tautology,
                Ast.OrExpression(
                    Ast.NumberExpression(val),
                    Ast.NumberExpression(decoy)
                )
            )
        end,

        -- 4. select() index trick
        --    select(K, noise1, noise2, ..., val, ...) picks val by position.
        --    AI must model vararg selection, not just arithmetic.
        function(val, depth)
            if depth > 0 then return false end  -- top level only (produces a call)
            local pos   = math.random(2, 5)
            local args  = {}
            args[1] = Ast.NumberExpression(pos)  -- select index
            for i = 2, pos - 1 do
                args[i] = Ast.NumberExpression(math.random(0, 99999))
            end
            args[pos] = Ast.NumberExpression(val)
            -- Add some noise args after
            for i = pos + 1, pos + math.random(1, 3) do
                args[i] = Ast.NumberExpression(math.random(0, 99999))
            end
            return Ast.FunctionCallExpression(
                Ast.VariableExpression(Ast.RootScope and Ast.RootScope() or ast and ast.body and ast.body.scope or {}, "select"),
                args
            )
        end,

        -- 5. math.abs encoding
        --    (-val - noise) negated and noise subtracted.
        --    val = math.abs(-val - noise) - noise ... actually:
        --    val = math.abs(-(val + noise)) - noise
        --    AI must model math.abs and track signs.
        function(val, depth)
            if val <= 0 or val > 2^20 then return false end
            local noise = math.random(1, 1000)
            local inner = -(val + noise)  -- negative
            -- math.abs(inner) = val + noise
            -- math.abs(inner) - noise = val
            local absCall = Ast.FunctionCallExpression(
                Ast.IndexExpression(
                    Ast.StringExpression("math"),
                    Ast.StringExpression("abs")
                ),
                { Ast.NumberExpression(inner) }
            )
            return Ast.SubExpression(absCall, Ast.NumberExpression(noise))
        end,
    }

    -- Combine: use all arith + all ai-resist if enabled
    if self.AIResistance ~= false then
        self.ExpressionGenerators = {}
        for _, g in ipairs(arithGenerators)       do self.ExpressionGenerators[#self.ExpressionGenerators+1] = g end
        for _, g in ipairs(aiResistGenerators)    do self.ExpressionGenerators[#self.ExpressionGenerators+1] = g end
    else
        self.ExpressionGenerators = arithGenerators
    end
end

function NumbersToExpressions:CreateNumberExpression(val, depth)
    if depth > 0 and math.random() >= self.InternalTreshold or depth > 15 then
        return Ast.NumberExpression(val)
    end
    local generators = util.shuffle({unpack(self.ExpressionGenerators)})
    for i, generator in ipairs(generators) do
        local ok, node = pcall(generator, val, depth)
        if ok and node then
            return node
        end
    end
    return Ast.NumberExpression(val)
end

function NumbersToExpressions:apply(ast)
    visitast(ast, nil, function(node, data)
        if node.kind == AstKind.NumberExpression then
            if math.random() <= self.Treshold then
                return self:CreateNumberExpression(node.value, 0)
            end
        end
    end)
end

return NumbersToExpressions
