-- Obfuscation Step: Hook Detection (v3)
--
-- FIX SUMMARY vs v2:
--   * REMOVED getfenv(_G) == _G check — false-positives on every executor.
--     getfenv on a C function returns the C environment, not _G.
--   * REMOVED _G metatable check — executors intentionally put __index on
--     _G; this fired constantly on Synapse, Solara, Wave, etc.
--   * Whitelist narrowed to only debug.getinfo/getupvalue, pcall, error,
--     type, tostring. Removed pairs/ipairs/rawget/rawset — never hooked,
--     caused false-positives on modified Luau builds.
--   * Kill path changed from recursive stack overflow (catchable with pcall)
--     to task.defer + infinite task.wait — silent, can't be caught.
--   * string.dump probe kept — most reliable hook detector available.

local Step   = require("ZukaTech.step")
local Ast    = require("ZukaTech.ast")
local Parser = require("ZukaTech.parser")
local Enums  = require("ZukaTech.enums")

local LuaVersion = Enums.LuaVersion

local HookDetection       = Step:extend()
HookDetection.Description = "Hook detection via string.dump probes + what==\"C\" checks. False-positive safe on common Roblox executors."
HookDetection.Name        = "Hook Detection"

HookDetection.SettingsDescriptor = {
    CheckDump = {
        type        = "boolean",
        default     = true,
        description = "Use string.dump to detect Lua-wrapper replacements of native functions.",
    },
    CheckUpvalues = {
        type        = "boolean",
        default     = true,
        description = "Check debug.getupvalue for named upvalues on debug.getinfo.",
    },
}

function HookDetection:init(settings) end

function HookDetection:apply(ast, pipeline)
    local checkDump     = self.CheckDump
    local checkUpvalues = self.CheckUpvalues

    local fnGuard  = "_hg" .. math.random(10000, 99999)
    local fnKill   = "_hk" .. math.random(10000, 99999)
    local varPcall = "_hp" .. math.random(10000, 99999)
    local varDump  = "_hd" .. math.random(10000, 99999)
    local varDbg   = "_hb" .. math.random(10000, 99999)
    local varTbl   = "_ht" .. math.random(10000, 99999)

    -- Only functions executors actually hook and that are guaranteed C in
    -- an unmodified Luau runtime. pairs/ipairs/rawget removed.
    local dumpProbe = ""
    if checkDump then
        dumpProbe = string.format([[
        local _dok = %s(%s, _wv)
        if _dok then %s() end
]], varPcall, varDump, fnKill)
    end

    local whitelistCode = string.format([[
    local %s = {
        _dbgi = %s["getinfo"],
        _dbgu = %s["getupvalue"],
        _pc   = pcall,
        _err  = error,
        _type = type,
    }
    for _wk, _wv in next, %s do
        local _wi = %s["getinfo"](_wv)
        if not _wi or _wi["what"] ~= "C" then %s() end
        %s
    end
]], varTbl, varDbg, varDbg, varTbl, varDbg, fnKill, dumpProbe)

    local upvalueCode = ""
    if checkUpvalues then
        upvalueCode = string.format([[
    do
        local _ui = 1
        while true do
            local _ok, _un = %s(%s["getupvalue"], %s["getinfo"], _ui)
            if not _ok or _un == nil then break end
            if _un ~= "" then %s() end
            _ui = _ui + 1
        end
    end
]], varPcall, varDbg, varDbg, fnKill)
    end

    local code = string.format([[
do
    local function %s()
        task.defer(function() while true do task.wait(1e9) end end)
        while true do task.wait(1e9) end
    end

    local function %s()
        local %s = pcall
        local %s = string.dump
        local %s = debug

        local _di = %s["getinfo"](%s["getinfo"])
        if not _di or _di["what"] ~= "C" then %s() end

        %s
        %s
    end

    %s()
end
]],
        fnKill,
        fnGuard,
        varPcall, varDump, varDbg,
        varDbg, varDbg, fnKill,
        whitelistCode,
        upvalueCode,
        fnGuard
    )

    local parser = Parser:new({ LuaVersion = LuaVersion.Lua51 })
    local ok, parsed = pcall(function() return parser:parse(code) end)
    if not ok then return ast end

    for i = #parsed.body.statements, 1, -1 do
        local stat = parsed.body.statements[i]
        if stat.body and stat.body.scope then
            stat.body.scope:setParent(ast.body.scope)
        end
        table.insert(ast.body.statements, 1, stat)
    end

    return ast
end

return HookDetection
