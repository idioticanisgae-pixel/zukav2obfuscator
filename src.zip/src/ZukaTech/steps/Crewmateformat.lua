-- steps/CrewmateFormat.lua
-- ZukaTech Obfuscation Step: CrewmateFormat
--
-- Post-unparse formatting pass.
-- Reshapes the entire obfuscated output so that when viewed in a monospaced
-- text editor, the indentation traces the silhouette of an Among Us crewmate.
--
-- The code executes IDENTICALLY — all changes are pure leading whitespace.
-- Lua ignores leading spaces completely. The shape is cosmetic only.
--
-- How it works:
--   1. Strip all existing leading/trailing whitespace from every line.
--   2. Drop empty lines. If input is too dense (few newlines), split on
--      semicolons so the formatter has enough lines to fill the shape.
--   3. BODY bands: each source line gets left-padded to the crewmate profile.
--   4. LEG bands: pairs of source lines are placed into left and right
--      leg columns with a gap between them.
--   5. Overflow lines cycle through a taper so they don't fall off a cliff.
--
-- Placement in preset: LAST step, after BlobCompress, before ZukaZalgo.
--   { Name = "CrewmateFormat", Settings = { Scale = 1 } }

local Step   = require("ZukaTech.step")
local logger = require("logger")

-- ── Crewmate silhouette profile ───────────────────────────────────────────────
-- BODY_BANDS: { left_pad, content_width }  (Scale=1, 72-char canvas)
--
--           canvas: |<---------72 chars---------->|
local BODY_BANDS = {
    -- HEAD dome
    { 22, 28 },  -- |                      ############################|
    { 16, 40 },  -- |                ########################################|
    { 12, 48 },  -- |            ################################################|
    { 10, 52 },  -- |          ####################################################|
    { 10, 52 },  -- |          ####################################################|
    -- VISOR
    { 10, 52 },  -- |          ####################################################|
    { 10, 52 },  -- |          ####################################################|
    -- BODY upper + backpack bump (right edge widens)
    {  8, 56 },  -- |        ########################################################|
    {  8, 60 },  -- |        ############################################################|
    {  8, 60 },  -- |        ############################################################|
    {  8, 60 },  -- |        ############################################################|
    -- BODY mid
    {  8, 56 },  -- |        ########################################################|
    {  8, 56 },  -- |        ########################################################|
    {  8, 56 },  -- |        ########################################################|
    -- LOWER taper
    {  8, 54 },  -- |        ######################################################|
    { 10, 50 },  -- |          ##################################################|
    { 12, 44 },  -- |            ############################################|
}

-- LEG_BANDS: { left_leg_pad, left_leg_width, right_leg_pad, right_leg_width }
local LEG_BANDS = {
    { 10, 18, 36, 18 },  -- |          ##################        ##################|
    { 10, 18, 36, 18 },
    { 10, 18, 36, 18 },
    { 10, 18, 36, 18 },
    -- FEET (slightly flared)
    {  8, 20, 34, 20 },  -- |        ####################      ####################|
    {  8, 20, 34, 20 },
}

local DEFAULT_SCALE  = 1
local DEFAULT_STRICT = false

-- ── Helpers ───────────────────────────────────────────────────────────────────

local function spaces(n)
    if n <= 0 then return "" end
    return string.rep(" ", n)
end

-- Split source into non-empty trimmed lines.
-- If there are fewer than 30 newlines (dense single-line output from
-- BlobCompress/Compressor), also split on semicolons so we have enough
-- lines to fill the crewmate silhouette.
local function getLines(source)
    local lines = {}

    local function pushLine(s)
        local trimmed = s:match("^%s*(.-)%s*$")
        if trimmed and #trimmed > 0 then
            lines[#lines + 1] = trimmed
        end
    end

    local _, newlineCount = source:gsub("\n", "")

    if newlineCount < 30 then
        -- Dense output: split on newlines then semicolons inside each chunk
        for chunk in (source .. "\n"):gmatch("([^\n]*)\n") do
            local buf     = ""
            local inStr   = false
            local strChar = ""
            local i       = 1
            while i <= #chunk do
                local c = chunk:sub(i, i)
                if inStr then
                    buf = buf .. c
                    if c == "\\" then
                        i = i + 1
                        if i <= #chunk then buf = buf .. chunk:sub(i, i) end
                    elseif c == strChar then
                        inStr = false
                    end
                else
                    if c == '"' or c == "'" then
                        inStr   = true
                        strChar = c
                        buf     = buf .. c
                    elseif c == ";" then
                        pushLine(buf)
                        buf = ""
                    else
                        buf = buf .. c
                    end
                end
                i = i + 1
            end
            if #buf > 0 then pushLine(buf) end
        end
    else
        for line in (source .. "\n"):gmatch("([^\n]*)\n") do
            pushLine(line)
        end
    end

    return lines
end

-- ── Core formatter ────────────────────────────────────────────────────────────

local function processSource(source, scale, strict)
    scale  = math.max(1, math.floor(scale  or DEFAULT_SCALE))
    strict = strict or DEFAULT_STRICT

    local lines      = getLines(source)
    local result     = {}
    local lineIdx    = 1
    local totalLines = #lines

    if totalLines == 0 then
        logger:warn("[CrewmateFormat] No lines to format — returning source unchanged.")
        return source
    end

    -- Scale the profiles
    local bodyBands = {}
    for _, b in ipairs(BODY_BANDS) do
        bodyBands[#bodyBands + 1] = {
            math.floor(b[1] * scale),
            math.floor(b[2] * scale),
        }
    end

    local legBands = {}
    for _, b in ipairs(LEG_BANDS) do
        legBands[#legBands + 1] = {
            math.floor(b[1] * scale),
            math.floor(b[2] * scale),
            math.floor(b[3] * scale),
            math.floor(b[4] * scale),
        }
    end

    -- BODY section: one source line per band row
    for _, band in ipairs(bodyBands) do
        if lineIdx > totalLines then break end
        local lpad  = band[1]
        local width = band[2]
        local code  = lines[lineIdx]
        lineIdx     = lineIdx + 1
        if strict and #code > width then
            code = code:sub(1, width)
        end
        result[#result + 1] = spaces(lpad) .. code
    end

    -- LEG section: two source lines per band row, split into L/R columns
    for _, band in ipairs(legBands) do
        if lineIdx > totalLines then break end
        local ll_pad   = band[1]
        local ll_width = band[2]
        local rl_pad   = band[3]
        local rl_width = band[4]

        local lineA = lines[lineIdx] or ""
        lineIdx     = lineIdx + 1
        local lineB = lines[lineIdx] or ""
        lineIdx     = lineIdx + 1

        if strict then
            if #lineA > ll_width then lineA = lineA:sub(1, ll_width) end
            if #lineB > rl_width then lineB = lineB:sub(1, rl_width) end
        end

        -- Gap between the end of left leg and start of right leg
        local gap = rl_pad - (ll_pad + #lineA)
        if gap < 1 then gap = 1 end

        result[#result + 1] = spaces(ll_pad) .. lineA .. spaces(gap) .. lineB
    end

    -- OVERFLOW: remaining lines cycle through a taper so they trail naturally
    local taperIndents = { 8, 9, 10, 11, 12, 13, 14, 16, 18, 20 }
    local taperIdx     = 1
    while lineIdx <= totalLines do
        local indent = taperIndents[taperIdx] or 20
        taperIdx     = (taperIdx % #taperIndents) + 1
        result[#result + 1] = spaces(indent) .. lines[lineIdx]
        lineIdx = lineIdx + 1
    end

    return table.concat(result, "\n")
end

-- ── Step interface ────────────────────────────────────────────────────────────

local CrewmateFormat = Step:extend()
CrewmateFormat.Name        = "CrewmateFormat"
CrewmateFormat.Description =
    "Post-unparse pass: reshapes the entire output into the Among Us crewmate " ..
    "silhouette using pure indentation. Code executes identically."

CrewmateFormat.SettingsDescriptor = {
    Scale = {
        name        = "Scale",
        description = "Multiply all indent/width values. 1 = normal, 2 = giant crewmate.",
        type        = "number",
        default     = DEFAULT_SCALE,
        min         = 1,
        max         = 4,
    },
    Strict = {
        name        = "Strict",
        description = "Hard-truncate lines that exceed band width (breaks code — debug only).",
        type        = "boolean",
        default     = DEFAULT_STRICT,
    },
}

function CrewmateFormat:init()
    self.Scale  = self.Scale  or DEFAULT_SCALE
    self.Strict = self.Strict or DEFAULT_STRICT
end

-- Registers itself on the pipeline so the post-unparse hook can call process().
function CrewmateFormat:apply(ast, pipeline)
    if pipeline._crewmateFormatStep then
        logger:warn("[CrewmateFormat] Multiple CrewmateFormat steps detected — last one wins.")
    end
    pipeline._crewmateFormatStep = self
    logger:info("[CrewmateFormat] Registered for post-unparse pass. Scale=" .. tostring(self.Scale))
    return ast
end

-- Called by pipeline.lua after all compression passes.
function CrewmateFormat:process(source)
    local inputLines = select(2, source:gsub("\n", "")) + 1
    logger:info("[CrewmateFormat] Shaping " .. inputLines .. " lines into crewmate silhouette...")
    local result = processSource(source, self.Scale, self.Strict)
    local outputLines = select(2, result:gsub("\n", "")) + 1
    logger:info("[CrewmateFormat] Done. " .. outputLines .. " lines output. sus.")
    return result
end

return CrewmateFormat
