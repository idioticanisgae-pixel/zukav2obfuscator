-- Obfuscation Step: CFF Integrity (v2)
--
-- FIX SUMMARY vs v1:
--   * Kill path changed from `while true do` infinite loop (hangs the
--     Roblox thread visibly, trivially detectable) to task.defer +
--     task.wait(1e9) — silent, doesn't freeze the calling thread,
--     harder to identify in a script dump.
--   * Logic otherwise unchanged — the CFF magic-constant hash check
--     was correct and Luau-compatible.

local Step          = require("ZukaTech.step")
local Ast           = require("ZukaTech.ast")
local Parser        = require("ZukaTech.parser")
local Enums         = require("ZukaTech.enums")
local RandomStrings = require("ZukaTech.randomStrings")

local CffIntegrity       = Step:extend()
CffIntegrity.Description = "CFF magic-constant integrity table. Silent task.wait kill path (was while-true freeze)."
CffIntegrity.Name        = "CFF Integrity"

CffIntegrity.SettingsDescriptor = {
    TableSize = {
        name        = "TableSize",
        description = "Number of constants in the integrity table (4-16)",
        type        = "number",
        default     = 9,
        min         = 4,
        max         = 16,
    },
    TrapIndex = {
        name        = "TrapIndex",
        description = "Which table index (1-based) is the trap constant. 0 = pick randomly.",
        type        = "number",
        default     = 0,
        min         = 0,
        max         = 16,
    },
}

function CffIntegrity:init(settings) end

local function bxor(a, b)
    local r, m = 0, 1
    while a > 0 or b > 0 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then r = r + m end
        a = math.floor(a / 2)
        b = math.floor(b / 2)
        m = m * 2
    end
    return r
end

local function safeMulMod(a, b, M)
    a = a % M
    b = b % M
    local a_hi = math.floor(a / 65536)
    local a_lo = a % 65536
    return ((a_hi * b % M) * 65536 + a_lo * b) % M
end

local function hashMix(v, salt)
    local p   = 2654435761
    local MOD = 2147483647
    local h   = (safeMulMod(v, p, MOD) + salt % MOD) % MOD
    h = bxor(h, math.floor(h / 65536))
    return h % MOD
end

local function buildTable(tableSize, trapIdxSetting)
    local constants = {}
    for i = 1, tableSize do
        constants[i] = math.random(1, 2147483646)
    end
    local trapIdx = trapIdxSetting
    if trapIdx < 1 or trapIdx > tableSize then
        trapIdx = math.random(1, tableSize)
    end
    local acc  = constants[1]
    local salt = math.random(1, 65535)
    for i = 2, tableSize do
        acc = hashMix(acc, constants[i] + salt)
    end
    local expected = acc % 2147483647
    return constants, trapIdx, expected, salt
end

local function buildValidationCode(constants, trapIdx, expected, salt, tableSize)
    local parts = {}
    for i, v in ipairs(constants) do parts[i] = tostring(v) end
    local tableLiteral = "{ " .. table.concat(parts, ", ") .. " }"

    local varTbl  = "_cff_" .. RandomStrings.randomString(6)
    local varSalt = "_cs_"  .. RandomStrings.randomString(4)
    local varMOD  = "_cm_"  .. RandomStrings.randomString(4)
    local varBxor = "_bx_"  .. RandomStrings.randomString(4)
    local varMul  = "_sm_"  .. RandomStrings.randomString(4)
    local varMix  = "_hm_"  .. RandomStrings.randomString(4)
    local varOk   = "_ck_"  .. RandomStrings.randomString(4)
    local varAcc  = "_ca_"  .. RandomStrings.randomString(4)
    local varI    = "_ci_"  .. RandomStrings.randomString(3)
    local varTrap = "_ct_"  .. RandomStrings.randomString(4)

    local trapExpected = hashMix(constants[trapIdx], salt + trapIdx) % 2147483647

    local code = "do\n"
    code = code .. "    local " .. varTbl  .. " = " .. tableLiteral .. "\n"
    code = code .. "    local " .. varSalt .. " = " .. tostring(salt) .. "\n"
    code = code .. "    local " .. varMOD  .. " = 2147483647\n"

    code = code .. "    local function " .. varBxor .. "(a, b)\n"
    code = code .. "        local r, m = 0, 1\n"
    code = code .. "        while a > 0 or b > 0 do\n"
    code = code .. "            local ra = a % 2\n"
    code = code .. "            local rb = b % 2\n"
    code = code .. "            if ra ~= rb then r = r + m end\n"
    code = code .. "            a = math.floor(a / 2)\n"
    code = code .. "            b = math.floor(b / 2)\n"
    code = code .. "            m = m * 2\n"
    code = code .. "        end\n"
    code = code .. "        return r\n"
    code = code .. "    end\n"

    code = code .. "    local function " .. varMul .. "(a, b, M)\n"
    code = code .. "        a = a % M\n"
    code = code .. "        b = b % M\n"
    code = code .. "        local hi = math.floor(a / 65536)\n"
    code = code .. "        local lo = a % 65536\n"
    code = code .. "        return ((hi * b % M) * 65536 + lo * b) % M\n"
    code = code .. "    end\n"

    code = code .. "    local function " .. varMix .. "(v, s)\n"
    code = code .. "        local h = (" .. varMul .. "(v, 2654435761, " .. varMOD .. ") + s % " .. varMOD .. ") % " .. varMOD .. "\n"
    code = code .. "        h = " .. varBxor .. "(h, math.floor(h / 65536))\n"
    code = code .. "        return h % " .. varMOD .. "\n"
    code = code .. "    end\n"

    code = code .. "    local " .. varOk .. " = true\n"
    code = code .. "    local " .. varTrap .. " = " .. varMix .. "(" .. varTbl .. "[" .. tostring(trapIdx) .. "], " .. tostring(salt + trapIdx) .. ")\n"
    code = code .. "    if " .. varTrap .. " ~= " .. tostring(trapExpected) .. " then\n"
    code = code .. "        " .. varOk .. " = false\n"
    code = code .. "    end\n"

    code = code .. "    local " .. varAcc .. " = " .. varTbl .. "[1]\n"
    code = code .. "    for " .. varI .. " = 2, " .. tostring(tableSize) .. " do\n"
    code = code .. "        " .. varAcc .. " = " .. varMix .. "(" .. varAcc .. ", " .. varTbl .. "[" .. varI .. "] + " .. varSalt .. ")\n"
    code = code .. "    end\n"
    code = code .. "    " .. varAcc .. " = " .. varAcc .. " % " .. varMOD .. "\n"

    -- FIX: replaced `while true do` freeze with silent task.wait kill
    code = code .. "    if not " .. varOk .. " or " .. varAcc .. " ~= " .. tostring(expected) .. " then\n"
    code = code .. "        task.defer(function() while true do task.wait(1e9) end end)\n"
    code = code .. "        while true do task.wait(1e9) end\n"
    code = code .. "    end\n"
    code = code .. "end\n"

    return code
end

function CffIntegrity:apply(ast, pipeline)
    local tableSize      = math.max(4, math.min(16, math.floor(self.TableSize or 9)))
    local trapIdxSetting = math.floor(self.TrapIndex or 0)

    local constants, trapIdx, expected, salt = buildTable(tableSize, trapIdxSetting)
    local code   = buildValidationCode(constants, trapIdx, expected, salt, tableSize)
    local parser = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 })
    local parsed = parser:parse(code)

    local doStat = parsed.body.statements[1]
    doStat.body.scope:setParent(ast.body.scope)
    table.insert(ast.body.statements, 1, doStat)

    return ast
end

return CffIntegrity
