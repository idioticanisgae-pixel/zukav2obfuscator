return (function(...) (function() return('Stop reversing!!') end)();
local __warn=(function()
    local _ok,_f=pcall(function()return warn end)
    return(_ok and type(_f)=="function")and _f or print
end)()
local Sub,Byte,Char,Find,Floor,Pairs,Insert,Pcall,ToNumber=string.sub,string.byte,string.char,string.find,math.floor,pairs,table.insert,pcall,tonumber;
local encrypted_table={[6]=print,[7]=__warn,[8]=error,[10]=function()end};
local decropress,decrypt,ARR,key1,key2,temp,key3,key4,GetPsewdo,key5,chars = nil,nil,nil,460.8,720,nil,633.6,331.2,nil,590.4,"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
if key1 then
if key2 then
if key3 then
if key4 then
local GlobalTable = {
  [460.8] = function()
	  decropress = function(str)
    	local result = ""
	for i = 1, #str, 2 do
		local c1 = Find(chars, Sub(str,i, i)) - 1
        local c2 = Find(chars, Sub(str,i + 1, i + 1)) - 1
		local byte = c1 * 4 + Floor(c2 / 16)
		result = result .. Char(byte)
	end
	return result
     end;
  end,
    [720] = function()
	 decrypt = function(str)
	local result = {}
	for i =1,#str do
		local char = Sub(str,i,i)
		local byte = Byte(char)
		local keys = GetPsewdo()
		local encrypted_byte = (byte -  85 - keys[1]-keys[2]- keys[3] - (i + 3)) % 256
		result[i] = Char(encrypted_byte)
	end
	return result
end
  end,
     [633.6] = function()
	if decropress then 
		if decrypt then
     temp = decropress('XwYwWAVwYwGAXwbwaQXwcQZwbgbgIQaASQUQZgeQbgdgggWAUgNAdQiAdgiQZQVwiwZAYQgQbAfQQgJAOwPAPQPgkQhQlQlwlQkgRQTgjwogkAowfwcQpQfgewmwhglwUwcgcgVgawcAWQmwqQoAXQpguQpwuglgiAvAlQkgsgnQrgaghwiQbQgwhgeQcQwQxQdAfQvg0Qvw0grgoA1ArQqgygtQxgggoQoQhQnAnAiAyg2AzwjA1Q6A1g6QxQtw6wxAwQ4QzA3QmQtguAnAtgrgqAoA8A9AowrA7QAA7gAQ3QzwAw3A2Q+Q5A9QsQ0A0AtAzgzQtw+QBw/guwBAFwBQGA9A5gGg8w8AEA+wDAyA5Q5wyw3Q3w4A2AugFgIAFwvgvwIgJgGwGgJg2wIgMgLAIgNAKgMQMQ5ALAHAQQDAPQEgNAGgNARQRgMw+QRwSgKgKQRgOASQHwBg+wIQIwWATwTwJgKAKQPgMgDw8QCACQCgCwWAXAUQUAXAEQYwVAZANgPARwcQQgRgUwHAOgHgegfQCwIgIwJAJQbAdgegKQcwKwSQLQPwOwMANAhwigagaQhgeAiQXwOgfwiwJwPgPwQAQQQgQwRARQkglgiwiglgSwlApwlQqAhAdgqggwgAoAiwnAWAdgWgsAswkwkgrwoQsgiAfQpgvgugrAcAsgcwVQbAbQbgbwcAcQcgcwvQuwdgvQngpguwzgwwyw1wrQpwiQyg3Qyw3gugrA4AuQtg1gwQ0glwjw5A2Q1w4QfglQlglwmAmQmgmwnAnQngnwoA7Q8Q5g5Q8Qpg9Q3A9w+A7w4Q+Q9Q4w8wsQsgswtAtQtgtwuAuQuguwvABgBAvwCAGwCQHA+A6gHg9w9AFA/wEAzA6w6wzw5A6Q0gFAIgGQ1gHwMgIAMwDwAQNQDgCwKwFgJw4wAAAg5g/A/w6QPgMwMQOw2A7w8A8Q8g8w9A9Q9g9w+A+Q+g+w/A/Q/gTQNATwUARwOQUQTQOwSwCQJwCwFAFQVgaQVwagRgOAbARQQgYgTQXgGgKAHAMQNgHwLQIQRwSQfgdQdQTATgTwZAWALAOALgQAQAOgMgOANARgRgQAOARAOgTwVAJwPgPwQAQQQgQwRARQRgRwSASQjwlwnwkglwlQUAmQrAmgrQiQewrwiAhQpQkAoQXQfAfAYAdwdwYwpQswqgZwsAwwsQxAoAkgxgnwnAvApwuAdAkQkwdwkQiQegzwxAwgzAaQgAgQgggwhAhQhghwiAiQigiwjAjQjgjw3gxQ4A4Q2Ayg4g3gzA3AmguAnApQpg5w+g6A+w1wyQ/Q1g0w8w3g7wqwuQrQxAxAsAvgsg2A2gDwBgBg3Q3w4A9Q6QvQyQvw0g1wywwwyQxQ2A3Q0QyQ1Qyw4g4guAzw0A0Q0g0w1A1Q1g1w2A2Q2gIAKAMAIwKAJg4QKgPQKwPgGgDAQAGQFgNgIQMg7gDQDQ8QCwCg9ANgRAOw+AQQVAQgVQMQIwVwMALQTQOASQBQIgJACAGgHAHQDAYQVgVAXg+wEgEwFAFQFgFwGAGQGgGwHAHQHgHwIAIQcAVwcgcwagXAdAcAXgbgLASgLgNwOAeQjAegjQaQWwjwaAZQhQcAgQPQSwPwWQWAQgUARAagbAoQmAmAbwcQcghwewTwWwUQZAaQXQVQWwVwagbwYwWwZwXQdwdgSgYQYgYwZAZQZgZwaAaQagawbAsgvAswWgcQcgcwdAdQdgdweAeQegewfA0QvwwQzAxgkAzA0g2Ayw2Q3AkQ2wzA3ArgtAvw6QugvgywoAlQ6Q6w6g4g6A4gqg4A5g4A8gqQ8A1w8g8w6g3A9A8A3g7gtQtgmArwsAsQsgswtAtQtg/ABADA/wpQvAvQvgvwwAwQwgwwxAxQxgxwHACgDAFwEQ2wFwHQIwFgJAJw3AJgFwJw+Q/wCgNABQCQFg6w4ANANgNQLQMwLQ9QKwMQKwPQ9ANQSANgSQJQFwSwJAIQQQLAPQAgAw5Q/A/Q/g/wAAAQAgAwSQUwSg8QCACQCgCwUQWwUg+QEAEQEgEwZgWgagbAagZwGgbwXQXwagZALgZAcQcQZwZgegLweQagegTAUgXQhwWAXAaQOwHQeQgwegIQIghQiQfgfQiQPgiwjwbQiQawkAawcQbgkwogggnQNgmQnQewlweQngeQfwfAoQsAkAqwWgeAXArQsAqArgtQfQTQsAtAkgrgkAtQkAlgkwuAxwpwwgeQuQqQzgmQygnwwQpwwQ0g0wwAhggQzQyw0w1A2AhQyA2w3w2g0wjQmAjQowmAmQ');
		end;
	end;
  end,
  [331.2] = function()
	if decrypt then
	if decropress then 
     ARR = decrypt(temp);
	 end;
	end;
  end,
  [590.4] = function()
     GetPsewdo = function()
		local t1 = 361 * 2
	    local t2 = t1 + 41
	    local t3 = t1 + t2
	    return {t1,t2,t3}
	 end
  end,
};
if key1 then
GlobalTable[key5]();
if key2 then
GlobalTable[key1]();
if key3 then
GlobalTable[key2]();
if key4 then
if key5 then
GlobalTable[key3]();
end;
end;
end;
GlobalTable[key4]();
end;
end;
end;
end;
end;
end;
if ARR then
    local _src=table.concat(ARR)
    local _fn,_err=(loadstring or load)(_src)
    if _fn then _fn() else error("ZukaTech decrypt error: "..tostring(_err)) end
end
 end)(...)