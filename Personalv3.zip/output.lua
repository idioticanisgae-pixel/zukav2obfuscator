return (function(...) local __warn=(function()
    local _ok,_f=pcall(function()return warn end)
    return(_ok and type(_f)=="function")and _f or print
end)()
local Sub,Byte,Char,Find,Floor,Pairs,Insert,Pcall,ToNumber=string.sub,string.byte,string.char,string.find,math.floor,pairs,table.insert,pcall,tonumber;
local encrypted_table={[6]=print,[7]=__warn,[8]=error,[10]=function()end};
local decropress,decrypt,ARR,key1,key2,temp,key3,key4,GetPsewdo,key5,chars = nil,nil,nil,563.2,880,nil,774.4,404.8,nil,721.6,"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
if key1 then
if key2 then
if key3 then
if key4 then
local GlobalTable = {
  [563.2] = function()
	  decropress = function(str)
    	local result = ""
	for i = 1, #str, 2 do
		local c1 = Find(chars, Sub(str,i, i)) - 1
        local c2 = Find(chars, Sub(str,i + 1, i + 1)) - 1
		local byte = c1 * 4 + Floor(c2 / 16)
		result = result .. Char(byte)
	end
	return result
     end;
  end,
    [880] = function()
	 decrypt = function(str)
	local result = {}
	for i =1,#str do
		local char = Sub(str,i,i)
		local byte = Byte(char)
		local keys = GetPsewdo()
		local encrypted_byte = (byte -  77 - keys[1]-keys[2]- keys[3] - (i + 6)) % 256
		result[i] = Char(encrypted_byte)
	end
	return result
end
  end,
     [774.4] = function()
	if decropress then 
		if decrypt then
     temp = decropress('CgDgAwAgDgwwCgGgFACgHAEgGQGQzAHwBQIQKQGAGw/wGgLw3gIwBwJgHgDwBAKAJwCwBAOA6wzQ5A5Q5g5wOgLgPgQAPgOw7g9wPAIAPwNwKAHQQQQAJAHQUQ+wGgGg/gEwGAAQQwUQSABQUgNgVQTQPgMwVwVgOgMwZwEQLgMAFAKgLQIAGAaAbAGwJAaQTQbAZAVQSgbgbQUQSgfgKARwRwKwQgQgLgcAfgdQMgfwYwggegawYAhAgwZwYAlAPgWwXQQQWwUwTQRQlQmQSAUQlgegmQkQggdwmwmgfgdwqwVQdAdAWAcgcQWwnQqwogXwrAkArwpwmAjQsQsAlAjQwQawiAigbggAgggwewXQuQwwugYQYgxQyQvgvQyQfgxQ1QzwxQ1wzQ1A1AhwzwqgvQ1AwQxQ4wyQ6gvAmg2w6g7AugvgvgwgwA5A8Q5Aqgnw5g8Q4w+g9A7QzgygsQkwqgqwrArQ+g/g8w8g/gswBA+A5QDACg/wFACw6QBAvg3AwAHAHwrQxAxQxgxwDgGAHAywFQzQ6wzw4Q3Q0g1gHAKwLQ+w/w/wAwAQJQMgJQ3wJAMAzA4w5A5Q5g5w6A6Q6gNwOwMALwOw8APQIQQAOAKQHgQgQQJQHgUg/AGg/gRwVgWAJgKgKgLgLAUAXQUAJATQZQYQUwFwWQGg/AEwFAFQFgFwGAGQGgZAYgHQcAVgcgegaQbAUAawgALwdAWAdwbwYAVQeQeAXAVQiQPANAiQfgfAhgIwOgOwPAPQPgPwQAQQQgQwRARQkglgiwiglgSwoAmAfwmQqQdgdwhAhwgAgQVwWAWQWgWwXAXQXgXwYAYQYgrAqgZQsglgtQrQngkwtwtgmgkwxwcQkAkAdAiQjgdwuQxwvgewyArAywwwtAqQzQzAsAqQ3QhwpApgigoAowjQ4g1w1Q3wfAkwlAlQlglwmAmQmgmwnAnQngnwoAoQog9w7w1g8AAAzQzg2w3g1w2ArgzAsAuQug/w4wAg+g6w4ABAAw5w4AFAvgzAwA1Q2gww0QxQDAFwCQIAGgEw9A8Azg2g0A4g4g3A1A2g1g6A6A4g2g5g3A8Q9gyQ4A4Q4g4w5A5Q5g5w6A6Q6g6wMQOQQQNAOQNw8gPwIwQgOgKwIARAQwJwIAVA/gHQHQAQGAGABARgVASwCAVQOQWAUAQQNgWgWQPQNgagFAMQMwFwMQKQGgbwZAYgbACQIAIQIgIwJAJQJgJwKAKQKgKwLALQLgLwhAfAYwfQjQWgWwaAawZAZQOwWQPQRgRwjAcAjwhweAbQkQkAdAbQoQSwWQTQZAZAUAXgUgmQpAlgrQpwoAgQfQWwZwXQcAdQaQYQZwYwdgewbwZwcwaQgAgAVgbQbgbwcAcQcgcwdAdQdgdweAvgxgzgwQxgxAfwzAsAzwxwuArQ0Q0AtArQ4QiwqgqgjgqApwkQ0w4Q2AlQ4gxg5Q3Qzgww5w5gygww9woQvgwApAtguAuQqA/Q8g8A+glwrgrwsAsQsgswtAtQtgtwuAuQuguwvAvQEgCg8QCwGw6A6Q9g+Q8g8wyQ5wyw1A1QGg/gHQFQBg+wHwHgAg+wLw2Q5w2w9Q9A3g7A4AJwMgJAOwNQLgDwCw6Q9Q6w/gAw9w7w9Q8QBACQ/Q9QAQ9wEQEA5A+w/A/Q/g/wAAAQAgAwBABQBgTAVgTQ9ACwDADQDgDwEAEQEgEwFAFQFgawWQWwZgYAKgZgbAcgZQcwdgKwdAaAVQfAegbwhAewWQdAOgLwgwhQhAfAggfARAeggAegjAQwkAiAbwiQmQZgZwdAdwcAcQUAUQMwSgSwTATQTgTwUAUQlwnwpwmgQAVwWAWQWgWwXAXQXgXwYAYQYgtwpQpwsgrAdgsguAvgsQvwwgdwwAtAoQyAxguw0AxwpQwAhgewzw0Q0AyAzgyAkAxgzAxg2Ajw1AuA1wzwwAtQ2Q2AvAtQ6QnAnQfwlglwmAmQmgmwnAnQ4w7Q5AiwogowpApQ6w9Q7AkwqgqwrArQAA9ABABgBAAQtACQ9w+QBA/gyA/gCwCwAQAAFAyQEgBg8wGgGADQIgGQ9wEg1QtwEwHQFAuwvAHwIwGAFwIw2AEwJQAALANgCAFwMQNAEwGQDAzwIAMgDQOQQwFQJAPgQQIAJgGQ8gEA9ARQSAQARgTQFQ5QNgSAIwTwWQKwOgVAVwNgPALwEAUAKwPgVQQgRgZASgawPQGwFgZAYgagawbwGgXwcgdgcQagIgLQIgOgLQLg');
		end;
	end;
  end,
  [404.8] = function()
	if decrypt then
	if decropress then 
     ARR = decrypt(temp);
	 end;
	end;
  end,
  [721.6] = function()
     GetPsewdo = function()
		local t1 = 159 * 2
	    local t2 = t1 + 41
	    local t3 = t1 + t2
	    return {t1,t2,t3}
	 end
  end,
};
if key1 then
GlobalTable[key5]();
if key2 then
GlobalTable[key1]();
if key3 then
GlobalTable[key2]();
if key4 then
if key5 then
GlobalTable[key3]();
end;
end;
end;
GlobalTable[key4]();
end;
end;
end;
end;
end;
end;
if ARR then
    local _src=table.concat(ARR)
    local _fn,_err=(loadstring or load)(_src)
    if _fn then _fn() else error("ZukaTech decrypt error: "..tostring(_err)) end
end
 end)(...)